/**
 ** Multi-tasking Optimization
 ** Using Transfer Learning Approach
 ** Use Jaya as an optimization tool
 ** Use Tabu Search to find the global best and global worst population.
 ** USe Reward system
 * ****Data: UMP Staff Expertise DataSet collected by Prof. Dr. Kamal
 **/
package mto_tl_jaya;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;



/**
 *
 * @author badal
 */
public class MTO_TL_jaya {
    static ArrayList<String> memory_list = new ArrayList<String>(); //memory list for data loading
    static ArrayList<String> skills_list = new ArrayList<String>(); //unique skills list in dataset
    static ArrayList<String> persons_list = new ArrayList<String>(); //unique person list in dataset
    static ArrayList<String> unprocess_skills_connections = new ArrayList<String>();
    static ArrayList<String> unprocess_costs_connections = new ArrayList<String>();
    
    static int        total_persons; //total no of person in dataset
    static int        total_skills; //total no of unique skill in dataset
    static int        population_size=100; //population size for optimization algo
    static double     Global_Best;
    
    static int [][]   skills_connections; // skills connection array for all people
    static double[][] costs_connections;  //cost connection array between everyone
    static int []     skills_to_find;     // skills that we have to be looking
    static int []     clone_skills_to_find; //for data handlinf dummy variable
    
    //task related variables
      
    static ArrayList<String> Task_path = new ArrayList< String>();
    static ArrayList<int []> Task_list = new ArrayList< int []>();
    static int total_task=4;
    
    static int[]    obj_value1_array_task1;        
    static double[] obj_value2_array_task1;                       
    static String[] population_short_seq_list_task1;
    
    static int[]    obj_value1_array_task2;        
    static double[] obj_value2_array_task2;                       
    static String[] population_short_seq_list_task2;
    
    static int[]obj_value1_array_task3;        
    static double[] obj_value2_array_task3;                       
    static String[] population_short_seq_list_task3;
    
    static int[]    obj_value1_array_task4;        
    static double[] obj_value2_array_task4;                       
    static String[] population_short_seq_list_task4;
    
    // Population array
    static int[][]   population; //store population long sequence  
    //store population of person of interest/nshort sequence
    static String[]  population_short_seq_list;   
    
    //store no of person of interest
    static int []    obj_value1_array;    
    //store cost connection between person of interest
    static double []   obj_value2_array;  
    
    //transfer learning variable
    static int task1_rank[]= new int[population_size];
    static int task2_rank[]= new int[population_size];
    static int task3_rank[]= new int[population_size];
    static int task4_rank[]= new int[population_size];
    
    static double scala_fitness[]= new double[population_size];
    
    
    static ArrayList<Integer> Tabu_List_Best = new ArrayList<Integer>(population_size);
    static ArrayList<Integer> Tabu_List_worst = new ArrayList<Integer>(population_size);
    
    
    
    static int no_change=0;    
    static boolean best_found=false;
    static int[] reward_List_Best_Index=new int[population_size];
    static int[] reward_List_Worst_Index=new int[population_size];
    static int Force=0;
    
    private static double[]  Task1_Local_Best_Cost;
    private static String [] Task1_Best_scores_Teams;
    private static int []    Task1_Best_scores_Teams_No;

    
    private static double[]  Task2_Local_Best_Cost;
    private static String [] Task2_Best_scores_Teams;
    private static int []    Task2_Best_scores_Teams_No;
    
    private static double[]  Task3_Local_Best_Cost;
    private static String [] Task3_Best_scores_Teams;
    private static int []    Task3_Best_scores_Teams_No;
    
    private static double[]  Task4_Local_Best_Cost;
    private static String [] Task4_Best_scores_Teams;
    private static int []    Task4_Best_scores_Teams_No;
    
    
    
    static int[] Best_team_No;
    static boolean Best_Team;
    static String Best_Team_Formation;
    static double Best_Cost;
    static int Person_Number;
    
    
    

    
    
    
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args)throws IOException {
       program_Initialization();
       /*
       initialize_population();
       double start_T1=System.currentTimeMillis();
       Jaya_Task1(400*61);
       double end_timeT1=System.currentTimeMillis();
       Jaya_Task2(400*61);
       double end_timeT2=System.currentTimeMillis();
       Jaya_Task3(400*61);
       double end_timeT3=System.currentTimeMillis();
       Jaya_Task4(400*61);
       double end_timeT4=System.currentTimeMillis();
       jaya_MTO(200);
       double end_timeMT0=System.currentTimeMillis();
       System.out.println("SOO Task 1 time "+ (end_timeT1-start_T1)*.001 );
       System.out.println("SOO Task 2 time "+ (end_timeT2-end_timeT1)*.001 );
       System.out.println("SOO Task 3 time "+ (end_timeT3-end_timeT2)*.001 );
       System.out.println("SOO Task 2 time "+ (end_timeT4-end_timeT3)*.001 );
       System.out.println("MTO Tasks time "+ (end_timeMT0-end_timeT4)*.001 );
       */
        initialize_population();
        jaya_MTO(200);
        //******get_index_best has some problem
        //********I have to write a method who can find greatest value from positive, zero and negative
    }
    
    
    
    public static void program_Initialization()throws IOException{
        String basic_path= "data\\ConnectionCost_ExtractedSkill_Staff_Expertise_DataSet\\";
        //load data into system and initialize systems
        load_skills_in_memory(basic_path+"ExtractedSkill_Staff_Expertise_Data.txt"); 
        
        process_skills();
        initialize_skills_connections();
        load_costs_in_memory(basic_path+"ConnectionCost_Staff_Expertise_Data.txt");
        process_costs();
        initialize_costs_connections();
        
        //load task path into the system
        load_tasks_path(basic_path); 
        load_tasks(4);
        
    }
    /*
    ***Load task path into the system
    */
    public static void load_tasks_path(String basic_path){
        // 5 skills set
        //String path1 = basic_path + "Required skills 5_1.txt";
        //String path2 = basic_path + "Required skills 5_2.txt";
        //String path3 = basic_path + "Required skills 5_3.txt";
        //String path4 = basic_path + "Required skills 5_4.txt";
        //String path5 = basic_path + "Required skills 5_5.txt";
        
        //10 Skills set
        //String path6  = basic_path+"Required skills 10_1.txt";
        //String path7  = basic_path+"Required skills 10_2.txt";
        //String path8  = basic_path+"Required skills 10_3.txt";
        //String path9  = basic_path+"Required skills 10_4.txt";
        //String path10 = basic_path+"Required skills 10_5.txt";  
        
          //15 skills set
        //String path11=basic_path+"Required skills 15_1.txt";
        //String path12=basic_path+"Required skills 15_2.txt";
        //String path13=basic_path+"Required skills 15_3.txt";
        //String path14=basic_path+"Required skills 15_4.txt";
 
        //20 skills set
        String path15=basic_path+"Required skills 20_1.txt";
        String path16=basic_path+"Required skills 20_2.txt";
        String path17=basic_path+"Required skills 20_3.txt";
        String path18=basic_path+"Required skills 20_4.txt";
        
        //80 skills set
        //String path19=basic_path+"Required skills 80.txt";
        
        
        //Task_path.add(path1);
        //Task_path.add(path2);
        //Task_path.add(path3);
        //Task_path.add(path4);
        //Task_path.add(path5);
        
        //Task_path.add(path6);
        //Task_path.add(path7);
        //Task_path.add(path8);
        //Task_path.add(path9);
        //Task_path.add(path10);
        
        //Task_path.add(path11);
        //Task_path.add(path12);
        //Task_path.add(path13);
        //Task_path.add(path14);
        
        Task_path.add(path15);
        Task_path.add(path16);
        Task_path.add(path17);
        Task_path.add(path18);
        
        //Task_path.add(path19);
    }
    
    /*
    ***Load task list into the system as an arraylist
    */
    public static void load_tasks(int number_of_task)throws IOException{
        for(int i=0;i<number_of_task;i++){
            int [] task =load_skills_to_find(Task_path.get(i));
            System.out.println("#################TASK = "+ i+ "   Added");
            System.out.println("file name"+Task_path.get(i) );
            System.out.println("skills task 1: "+ Arrays.toString(task));
            Task_list.add(task);     
        }      
    }
    /*
    * load the skills file into memory for processing
    */
    public static void load_skills_in_memory (String skills_file) throws FileNotFoundException, IOException{
        try (RandomAccessFile f = new RandomAccessFile(skills_file,"r")) {
            long length = f.length();
            long position = 0;
            String content;
            int count=0;
            System.out.println ("Loading skills file in memory => ");
            // rewind file to position 0
            f.seek(0);
            memory_list.clear();
            //System.out.println("File Length"+ length);
            //System.out.println();
            
            while (position < length){
                //System.out.println("while loop");
                if (count%5==0){
                   // System.out.println ("Count = ["+count+"] Loading skills to memory ...please wait");
                }
                count++;
                content = f.readLine();
                memory_list.add(content);
                //System.out.println("text"+ content);
                position = f.getFilePointer();
            }
        } 
        System.out.println("Load Skills in Memory Done");
	}
    
    /*
    *Process the skill file and extract 
                # no of total_persons
                # no of total_skills
                # persons_list
                # skills_list
                # unprocess_skills_connections

    *
    */
    public static void process_skills () {
	String content;
	System.out.println ("Processing Skills ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
		String string_val = results[i];
                if (string_val.trim().equals("Total Persons".trim())){  
                    total_persons=Integer.parseInt(results[1]);
                    
                    process_already=true;
		}
		else if (string_val.trim().equals("Total Skills".trim())){  
                    total_skills=Integer.parseInt(results[1]);
                    process_already=true;
		}
		else if (string_val.trim().equals("Persons Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                        persons_list.add(results2[j]);
                        //System.out.println ("Adding person => "+results2[j]);
                    }
                    process_already=true;		
                }      
		else if (string_val.trim().equals("Skills Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                            skills_list.add(results2[j]); 
                            //System.out.println ("Adding skill => "+results2[j]);
                    }
                            process_already=true;
                } 
		else{ // store unprocess skills connections 
                    if (!unprocess_skills_connections.contains(content)&& process_already==false){
                        unprocess_skills_connections.add(content);
                    }
                }
            }	
        }
        /* For debugning 
        System.out.println("Total Persons = " + total_persons+"****************" );
        for(int i=0;i<persons_list.size();i++){
          System.out.println(i+" "+persons_list.get(i));  
        }
        */
        //System.out.println("Total Skills " + total_skills +"********************");
         for(int i=0;i<skills_list.size();i++){
          //System.out.println(i+" "+skills_list.get(i));  
        }
        
        System.out.println("Process Skill Processing Done.");
    }
    
    /*
    *Initialize skills connection or create skills connection Matrix into 2D array
    */
    public static void initialize_skills_connections(){	  
	skills_connections = new int [total_persons][total_skills];
	// initialize initial connections
	//System.out.println ("Initializing Skills Connection Metrics..");
        for (int row=0;row<total_persons;row++){
            for (int col=0;col<total_skills;col++){
                skills_connections[row][col]=0; 
            }
        }
        //System.out.println ("Unprocess connections from skills file => "+unprocess_skills_connections.size()); 
        for (int i=0;i<unprocess_skills_connections.size();i++){
            String s = unprocess_skills_connections.get(i).trim();
            String result[] = s.split("=");
            String val[] = result[1].split(":");
            for (int j=0;j<val.length;j++){
                skills_connections[i][j]= (int)Integer.parseInt(val[j]);
                //System.out.println("Skill connection matric"+ skills_connections[i][j]);
            }   
        }
             
        
        //System.out.println("Skill Connection Matrix Size(Total person X Total unique skills) = "+skills_connections.length+"x"+skills_connections[0].length );
        //System.out.println ("Initialize Skills Connection Metrics Done.");
		   
    }
    
    /*
    * load the skills file into memory for processing
    */
    public static void load_costs_in_memory (String costs_file)throws IOException{
        //System.out.println("Loading Costs File in Memory");
	RandomAccessFile f = new RandomAccessFile(costs_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	int count=0;
	//System.out.println ("Loading costs file in memory => ");
        // rewind file to position 0
        f.seek(0);
	memory_list.clear();
        while (position < length){
            if (count%5==0)
            //System.out.println ("Count = ["+count+"] Loading costs to memory ...please wait");
            count++;
            content = f.readLine();
            memory_list.add(content);
            //System.out.println("data"+ content);
            position = f.getFilePointer();
        }	
        f.close(); 
        
        System.out.println("Loading Costs File in Memory Done");
        
    }
        
    /*
    *Process the costs file and extract 
                # unprocess_skills_connections    
    */
    
    public static void process_costs (){
        String content;
        //System.out.println ("Processing costs ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
                String string_val = results[i];
                if (string_val.trim().equals("Persons Mapping".trim())){
                    process_already=true;
                    continue;	
                }       
                else{ // store unprocess costs connections 
                    if (!unprocess_costs_connections.contains(content)&& process_already==false)
                        unprocess_costs_connections.add(content);
                }
            }
        }
        System.out.println ("Processing costs Done");
    }
    
    /* 
    * Initialize the cost connection matrix to form cost matrix
    
    */   
    public static void initialize_costs_connections(){
	costs_connections = new double [total_persons][total_persons];
	// initialize initial connections
	//System.out.println ("Initializing costs connection metrics..");
        
        for (int i=0;i<unprocess_costs_connections.size();i++){
            String s = unprocess_costs_connections.get(i).trim();
            String result[] = s.split("=");
            String val[] = result[1].split(":");
            for (int j=0;j<val.length;j++){
                costs_connections[i][j]= (double)Double.parseDouble(val[j]);
                //System.out.print( costs_connections[i][j]+" ");
            } 
            //System.out.println(" ");
        }
        //System.out.println("Cost Matrix Size(Total Person X Total Person) = "+ costs_connections.length+" X "+ costs_connections[0].length);
        System.out.println ("Initializing costs connection metrics Done");
   }

    /*
    Load the text file which contails the team skills set
    */
    public static int[] load_skills_to_find (String values_file) throws IOException{
        //System.out.println("load_skills_to_find .....processing");
        RandomAccessFile f = new RandomAccessFile(values_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	f.seek(0);
        ArrayList<Integer> match_idx = new ArrayList<Integer>();
	while (position < length){
            content = f.readLine();
            String results[] = content.split("=");
            String val[] = results[1].split(",");
            for (int i=0;i<val.length;i++){			
                int index = skills_list.indexOf(val[i].trim());
                //System.out.println ("Skills to search for ==> "+val[i]);
                if (index==-1){
                    //System.out.println ("One of the skills requested does not exist...");
                    System.exit(0);
                } 				  
                else{
                    match_idx.add(index);
                    }
  
            }	 
	    position = f.getFilePointer();
		  
        }
        f.close();		 		
        Collections.sort(match_idx); 
        skills_to_find= new int[total_skills];
        Arrays.fill(skills_to_find, 0); //put zero into all spaces
        for (int i=0;i<total_skills;i++){
            if (match_idx.contains(i)){// if match put 1 into that space
                skills_to_find[i]=1;
            }
        }
        System.out.println("Load Skills to Find Done");
        return skills_to_find;
    }
    
    /*
    *objective Function]
    * input: random person sequence
    * output: persons who has skills/ skill
    
    */
   public static int [] objective_function_ (int arr [], int [] skills_to_find ){
        boolean consist_skills_value=false;
        int update_answer[] = new int[total_skills];
        Arrays.fill(update_answer, 0); //fill the int array by zero.

        ArrayList<Integer> trim_seq = new ArrayList<Integer>();
        String value_skills = array_sequence_to_string (skills_to_find);  //converte arr into string
        //System.out.println("I am in objective function");
        clone_skills_to_find = skills_to_find.clone();
        for (int i=0;i<arr.length;i++){ 
            consist_skills_value=false;
            if (i==0){ // for first iteration
                for (int j=0;j<total_skills;j++){
                    update_answer[j]=skills_connections[arr[i]][j];// get the skill sets of a person     
                }
                //System.out.println ("Current seq value in zero = "+arr[i]);
                //String s =array_sequence_to_string (update_answer);
                //System.out.println ("sill sets of current person " +arr[i]+"  = " +s); 
                //System.out.println ("Skills to find                =   "+value_skills);
                consist_skills_value=contain_skills_to_find(update_answer,clone_skills_to_find);//check the person has that specific skills set
                if (consist_skills_value){   
                    trim_seq.add(arr[i]);// if has the skill, add that person into person of interest
                }
            }
            else{ //for all iteration
                int tmp_answer[] = new int[total_skills];
                Arrays.fill(tmp_answer, 0);
                for (int j=0;j<total_skills;j++){
                          tmp_answer[j]=skills_connections[arr[i]][j];
                }
                //System.out.println ("Current seq value non zero= "+arr[i]);
                //String s =array_sequence_to_string (tmp_answer);
                //System.out.println ("Update s       = "+s); 
                //System.out.println ("Skills to find = "+value_skills); 
                consist_skills_value=contain_skills_to_find(tmp_answer,clone_skills_to_find);
                if (consist_skills_value){
                    trim_seq.add(arr[i]);
                    //System.out.println("added person*****************************************");
                    update_answer= merge_elements_(update_answer,tmp_answer);	   
                    if (complete_merge_sequence_(update_answer,skills_to_find)){
                        //System.out.println("found all################################################yah");
                        break;	 //if all skills are covered
                    }                    
                }
                //s =array_sequence_to_string (update_answer);
                //System.out.println ("Skills so far  = "+s);
            }
        } 	
        int trim_result[] = new int [trim_seq.size()];
        for (int i=0;i<trim_seq.size();i++){
            trim_result[i]=trim_seq.get(i);
        } 
        return trim_result; //return the persons sequences who have required skill or skills
    }
    /*
    ******** convert array sequence into string value
    */
    public static String array_sequence_to_string (int array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Integer.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Integer.toString(array[i]);
        }
        return (sequence);
    }
    /*
    ******** convert double type array sequence into string value
    */
    public static String double_array_sequence_to_string (double array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Double.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Double.toString(array[i]);
        }
        return (sequence);
    }
    //////////////////////////////////////////////////////////
    //  Check if the given sequence has at least 1 skills 
    //  that we are looking for
    //////////////////////////////////////////////////////////
    //######need to change the mecanism##############
    public static boolean contain_skills_to_find (int arr[], int clone_skills_to_find[]){
        boolean outcome = false;
        for (int x=0; x<clone_skills_to_find.length; x++){
            if (clone_skills_to_find[x]==1 && arr[x]==1){
		outcome=true;
		clone_skills_to_find[x]=0;  // to signify already covered skill
		//break;
            }
        }
        return outcome;
    }
    
    ////////////////////////////////////////////////////////////
   //    Merge elements
   ///////////////////////////////////////////////////////////
   public static int [] merge_elements_ (int arr1[],int arr2[]){ 
        int merge_array[] = new int[total_skills];
        Arrays.fill(merge_array, 0); 
        for (int x=0; x<arr1.length; x++){
            if (arr1[x]==arr2[x])
                merge_array[x]=arr1[x];
            else if (arr1[x]==0 && arr2[x]==1)
                merge_array[x]=1;//remove zero person
            else if (arr1[x]==1 && arr2[x]==0)
                merge_array[x]=1; //remove zero person
        }
        
        return merge_array;
    }
    
    //////////////////////////////////////////////////////////
    //  Check for complete merge against skills to find
    //////////////////////////////////////////////////////////
    public static boolean complete_merge_sequence_ (int arr[], int skills_to_find[]){
        boolean outcome = true;
        for (int x=0; x<skills_to_find.length; x++){
          if (skills_to_find[x]==1 && arr[x]==0){
              outcome=false;//if there are some/one skill needed
              break;
            }
        }
        return outcome;
    }
        //////////////////////////////////////////////////////////////
    //   Create ranks or skill factors
    //////////////////////////////////////////////////////////////
    public static int [] create_rank_fitness(double fitness[]){
        double delta=0.0001;
        double clone_fitness[] = fitness.clone();
        int rank[] = new int[population_size];
        Arrays.sort(clone_fitness);
        int idx=0;
        for (int i=0;i<fitness.length;i++){
            for (int j=0;j<fitness.length;j++){
                if (Math.abs(fitness[i]-clone_fitness[j])<delta){
                    rank[idx]=j+1;
                    clone_fitness[j]=Integer.MAX_VALUE;
                    idx++;
                    break;			
                }		  
            }	  
        }		
        return rank; 
     }
    
    //////////////////////////////////////////////////////////////
    //   Initialize population 
    //////////////////////////////////////////////////////////////	
    public static void initialize_population(){
	int arr[];
        population = new int [population_size][total_persons];
        int task_1_fitness[];
        obj_value1_array_task1 = new int [population_size];        
        obj_value2_array_task1 = new double [population_size];                       
        population_short_seq_list_task1 = new String [population_size];
        int task_2_fitness[];
        obj_value1_array_task2 = new int [population_size];        
        obj_value2_array_task2 = new double [population_size];                       
        population_short_seq_list_task2 = new String [population_size];
        int task_3_fitness[];
        obj_value1_array_task3 = new int [population_size];        
        obj_value2_array_task3 = new double [population_size];                       
        population_short_seq_list_task3 = new String [population_size];
        int task_4_fitness[];
        obj_value1_array_task4 = new int [population_size];        
        obj_value2_array_task4 = new double [population_size];                       
        population_short_seq_list_task4 = new String [population_size];
        
        for (int row=0;row<population_size;row++){
            //generate long sequence
            arr=generate_random_sequence(total_persons); //generate random sequence with random numbers between 1 to total no of person
            
            for (int col=0;col<total_persons;col++){
                population[row][col]= arr[col]; //put all the random long sequence into population   
            }
            
            //get the required person who has skill/skills
            task_1_fitness = objective_function_(arr, Task_list.get(0)); //output population short sequence
            population_short_seq_list_task1[row]=array_sequence_to_string(task_1_fitness);
            int task1_obj_person=objective_value1_(task_1_fitness);
            obj_value1_array_task1[row]=task1_obj_person;
            double task1_obj_costs=objective_value2_(task_1_fitness);
            obj_value2_array_task1[row]=task1_obj_costs;  // total connection cost
                            
            task_2_fitness = objective_function_(arr, Task_list.get(1)); //output population short sequence
            population_short_seq_list_task2[row]=array_sequence_to_string(task_1_fitness);
            int task2_obj_person=objective_value1_(task_2_fitness);
            obj_value1_array_task2[row]=task2_obj_person;
            double task2_obj_costs=objective_value2_(task_2_fitness);
            obj_value2_array_task2[row]=task2_obj_costs;  // total connection cos
            
            task_3_fitness = objective_function_(arr, Task_list.get(2)); //output population short sequence
            population_short_seq_list_task3[row]=array_sequence_to_string(task_3_fitness);
            int task3_obj_person=objective_value1_(task_3_fitness);
            obj_value1_array_task3[row]=task3_obj_person;
            double task3_obj_costs=objective_value2_(task_3_fitness);
            obj_value2_array_task3[row]=task3_obj_costs;  // total connection cost
                            
            task_4_fitness = objective_function_(arr, Task_list.get(3)); //output population short sequence
            population_short_seq_list_task4[row]=array_sequence_to_string(task_4_fitness);
            int task4_obj_person=objective_value1_(task_4_fitness);
            obj_value2_array_task4[row]=task4_obj_person;
            double task4_obj_costs=objective_value2_(task_4_fitness);
            obj_value2_array_task2[row]=task4_obj_costs;  // total connection cos
                
                /*//debuging
                System.out.println ("---------------------Task1-----------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task1 = "+population_short_seq_list[row]);
                System.out.println ("No of person task1 = "+task1_obj_person);
                System.out.println ("Costs task1 = "+task1_obj_costs);
            
                */ 
                //System.out.println("Task 4 cost "+ obj_value2_array_task2[row]);
        }
        //creating rank1
        task1_rank = create_rank_fitness(obj_value2_array_task1);
        
        //creating rank2
        task2_rank = create_rank_fitness(obj_value2_array_task2);
        
        //creating rank3
        task3_rank = create_rank_fitness(obj_value2_array_task3);
        
        //creating rank4
        task4_rank = create_rank_fitness(obj_value2_array_task4);
 
        //creating scala fitness
        scala_fitness = create_scala_fitness_matrix(task1_rank,task2_rank,task3_rank,task4_rank);
        
        
        //System.out.println("costs task 1 "+ Arrays.toString(obj_value2_array_task1));
        System.out.println("rank 1 "+ Arrays.toString(task1_rank));
        //System.out.println("costs task 2 "+ Arrays.toString(obj_value2_array_task2));
        System.out.println("rank 2 "+ Arrays.toString(task2_rank));
        //System.out.println("costs task 3 "+ Arrays.toString(obj_value2_array_task3));
        System.out.println("rank 3 "+ Arrays.toString(task3_rank));
        //System.out.println("costs task 4 "+ Arrays.toString(obj_value2_array_task4));
        System.out.println("rank 4 "+ Arrays.toString(task4_rank));        
        System.out.println("scala fitness "+ Arrays.toString(scala_fitness));               
        System.out.println("Initialization completed");
        
        
    }
    
    
    ///////////////////////////////////////////////////////////
    //   Generate random sequence 
    ////////////////////////////////////////////////////////////
    public static int [] generate_random_sequence (int dim){
        int[] ar = new int[dim];
        int d, tmp;
        Random generator = new Random();
        int[] dummy_solution_array = new int[dim];
        for (int counter=0; counter<dim;counter++){  
            dummy_solution_array [counter] = counter;// fill the array with some sequential no;
            
        }    
        // copy array from seq_arr
        ar = dummy_solution_array.clone();
        // swap with new ar with random index
        // the first index and last index must not change
        for (int i=0;i<dim-1;i++){
            d=i+(generator.nextInt()&(dim-1-i)); //generate random number between i and (dim-1-i)
            //System.out.print("generator "+ d);
            tmp=ar[i];
            ar[i]=ar[d];
            ar[d]=tmp;
        }
        //System.out.println("Random sequence completed  "+ array_sequence_to_string(ar));
        return ar;
    }
    
    
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the number of persons
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static int objective_value1_ (int seq[]){
        return (seq.length);
    }
	
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the connection costs
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static double objective_value2_ (int seq[]){
        double cost=0.0;	 
        for (int i=0;i<seq.length;i++){
            int row = seq[i];
            for (int j=i+1;j<seq.length;j++){
                int col =seq[j];
                cost = cost+costs_connections[row][col];
            }
	}	   
	return(cost); 
    }
    
    public static double [] create_scala_fitness_matrix(int[] rank1, int[] rank2,int[] rank3, int[] rank4){
        double[] SF = new double[population_size];

        // creating list.
        ArrayList<Integer> rankValue = new ArrayList<>();

        for (int i=0;i<population_size;i++){
            rankValue.add(rank1[i]);
            rankValue.add(rank2[i]);
            rankValue.add(rank3[i]);
            rankValue.add(rank4[i]);
            Integer min = Collections.min(rankValue);
            //System.out.println("Minimum value "+ min);
            SF[i]=(double) 1.0/(min);
            rankValue.clear();
        }
        
        return SF;
    }
    
    /*
    **Jaya algorithum implimentation for task1
    */
    public static void Jaya_Task1(int generation){
        Task1_Local_Best_Cost   = new double[generation];
        Task1_Best_scores_Teams = new String[generation];
        Task1_Best_scores_Teams_No = new int[generation];
        int arr[];
        int task_1_fitness[];
        int updated_long_seq[]=new int[total_persons];
        Random r = new Random();
        int gen=0;
        while(gen < generation){
            //System.out.println("");
            //System.out.println("");
            //System.out.println("Generation "+ gen );
            //get the best value
            int best_index=get_index_best_cost(obj_value2_array_task1);
            int[] best_long_seq=get_population_long_sequence(best_index);
            //get the worst value
            int worst_index=get_index_worst_cost(obj_value2_array_task1);
            int[] worst_long_seq=get_population_long_sequence(worst_index);
            int current_seq[];
            
            //System.out.println("Population printing");
            for(int row=0;row<population_size;row++){

                //System.out.println("######Initial long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));

                current_seq= get_population_long_sequence(row);//get the current sequence
                //System.out.println("long sequence size= "+ current_seq.length);
                //System.out.println("total person= "+ total_persons);
                //System.out.println(row+" "+" "+ array_sequence_to_string(current_seq));
                //System.out.println("size= "+current_seq.length);
                //population update equation
                for (int col=0;col<total_persons;col++){
                    //update equation of jawa
                    updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                        - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));
                    //System.out.println("######Generated by equation long sequence ##############");

                    //System.out.println(j+" = "+ updated_long_seq[j] );

                    //boundary condtion or boundary managing
                    if (updated_long_seq[col]>total_persons-1){
                        updated_long_seq[col]=updated_long_seq[col]-total_persons;
                    }
                    if (updated_long_seq[col]<0){
                        updated_long_seq[col]=total_persons+updated_long_seq[col];
                    }								 

                    //System.out.println(j+" = "+ updated_long_seq[j] );
                    population[row][col]= updated_long_seq[col];//update population
                }//end col
                //System.out.println("######updated long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));
                
                //update everything
                arr= get_population_long_sequence(row);
                
                //System.out.println(row+" "+" "+ array_sequence_to_string(arr));
                //System.out.println("size  "+ arr.length);
                
                task_1_fitness = objective_function_(arr,Task_list.get(0));
                population_short_seq_list_task1[row]=array_sequence_to_string(task_1_fitness);
                int task1_obj_person=objective_value1_(task_1_fitness);
                obj_value1_array_task1[row]=task1_obj_person;
                double task1_obj_costs=objective_value2_(task_1_fitness);
                obj_value2_array_task1[row]=task1_obj_costs;  // total connection cost
                /*
                System.out.println ("--------------------------------------------------");
                System.out.println ("Population no = "+row);
                //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
                System.out.println ("No of person = "+obj_person);
                System.out.println ("Costs = "+obj_costs);

                obj_value1_array[row]=obj_person; 	//no of persons
                obj_value2_array[row]=obj_costs;  // total connection cost
                */
            }
            
            //update local best cost, team members, member number  
            int task1_local_best_index=get_index_best_cost(obj_value2_array_task1);
            Task1_Local_Best_Cost[gen]  = obj_value2_array_task1[task1_local_best_index];
            Task1_Best_scores_Teams[gen]= population_short_seq_list_task1[task1_local_best_index];
            Task1_Best_scores_Teams_No[gen]  = obj_value1_array_task1[task1_local_best_index];
            /*
            System.out.println("**********************************************");
            System.out.println("Local result");
            System.out.println("Generation = "+ gen);
            System.out.println(" Best Score = "+ Best_Scores[gen]);
            System.out.println(" Global Best Score = "+ Global_Best_Scores[gen]);
            System.out.println("Best Team = "+Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Best_team_No[gen]);
            System.out.println(" ");
            System.out.println(" ");
            */
            gen++;
        }
        int     Task1_Global_Best_Gen   = get_index_best_cost(Task1_Local_Best_Cost);
        double  Task1_Global_Best_Cost  = Task1_Local_Best_Cost[Task1_Global_Best_Gen];
        String  Task1_Global_Best_scores_Teams = Task1_Best_scores_Teams[Task1_Global_Best_Gen];
        int     Task1_Global_Best_scores_Teams_No =Task1_Best_scores_Teams_No[Task1_Global_Best_Gen];
        //printing final result
        System.out.println("##################################################");
        System.out.println("                Final Result: Single task Task 1                   ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task1_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task1_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task1_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task1_Global_Best_Cost);
        System.out.println("Found in "+ Task1_Global_Best_Gen+ " Generation");
    }
    
    public static void Jaya_Task2(int generation){
        Task2_Local_Best_Cost   = new double[generation];
        Task2_Best_scores_Teams = new String[generation];
        Task2_Best_scores_Teams_No = new int[generation];
        int arr[];
        int task_2_fitness[];
        int updated_long_seq[]=new int[total_persons];
        Random r = new Random();
        int gen=0;
        while(gen < generation){
            //System.out.println("");
            //System.out.println("");
            //System.out.println("Generation "+ gen );
            //get the best value
            int best_index=get_index_best_cost(obj_value2_array_task2);
            int[] best_long_seq=get_population_long_sequence(best_index);
            //get the worst value
            int worst_index=get_index_worst_cost(obj_value2_array_task2);
            int[] worst_long_seq=get_population_long_sequence(worst_index);
            int current_seq[];
            
            //System.out.println("Population printing");
            for(int row=0;row<population_size;row++){

                //System.out.println("######Initial long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));

                current_seq= get_population_long_sequence(row);//get the current sequence
                //System.out.println("long sequence size= "+ current_seq.length);
                //System.out.println("total person= "+ total_persons);
                //System.out.println(row+" "+" "+ array_sequence_to_string(current_seq));
                //System.out.println("size= "+current_seq.length);
                //population update equation
                for (int col=0;col<total_persons;col++){
                    //update equation of jawa
                    updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                        - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));
                    //System.out.println("######Generated by equation long sequence ##############");

                    //System.out.println(j+" = "+ updated_long_seq[j] );

                    //boundary condtion or boundary managing
                    if (updated_long_seq[col]>total_persons-1){
                        updated_long_seq[col]=updated_long_seq[col]-total_persons;
                    }
                    if (updated_long_seq[col]<0){
                        updated_long_seq[col]=total_persons+updated_long_seq[col];
                    }								 

                    //System.out.println(j+" = "+ updated_long_seq[j] );
                    population[row][col]= updated_long_seq[col];//update population
                }//end col
                //System.out.println("######updated long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));
                
                //update everything
                arr= get_population_long_sequence(row);
                
                //System.out.println(row+" "+" "+ array_sequence_to_string(arr));
                //System.out.println("size  "+ arr.length);
                
                task_2_fitness = objective_function_(arr,Task_list.get(1));
                population_short_seq_list_task2[row]=array_sequence_to_string(task_2_fitness);
                int task2_obj_person=objective_value1_(task_2_fitness);
                obj_value1_array_task2[row]=task2_obj_person;
                double task2_obj_costs=objective_value2_(task_2_fitness);
                obj_value2_array_task2[row]=task2_obj_costs;  // total connection cost
                /*
                System.out.println ("--------------------------------------------------");
                System.out.println ("Population no = "+row);
                //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
                System.out.println ("No of person = "+obj_person);
                System.out.println ("Costs = "+obj_costs);

                obj_value1_array[row]=obj_person; 	//no of persons
                obj_value2_array[row]=obj_costs;  // total connection cost
                */
            }
            
            //update local best cost, team members, member number  
            int task2_local_best_index=get_index_best_cost(obj_value2_array_task2);
            Task2_Local_Best_Cost[gen]  = obj_value2_array_task2[task2_local_best_index];
            Task2_Best_scores_Teams[gen]= population_short_seq_list_task2[task2_local_best_index];
            Task2_Best_scores_Teams_No[gen]  = obj_value1_array_task2[task2_local_best_index];
            /*
            System.out.println("**********************************************");
            System.out.println("Local result");
            System.out.println("Generation = "+ gen);
            System.out.println(" Best Score = "+ Best_Scores[gen]);
            System.out.println(" Global Best Score = "+ Global_Best_Scores[gen]);
            System.out.println("Best Team = "+Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Best_team_No[gen]);
            System.out.println(" ");
            System.out.println(" ");
            */
            gen++;
        }
        int     Task2_Global_Best_Gen   = get_index_best_cost(Task2_Local_Best_Cost);
        double  Task2_Global_Best_Cost  = Task2_Local_Best_Cost[Task2_Global_Best_Gen];
        String  Task2_Global_Best_scores_Teams = Task2_Best_scores_Teams[Task2_Global_Best_Gen];
        int     Task2_Global_Best_scores_Teams_No =Task2_Best_scores_Teams_No[Task2_Global_Best_Gen];
        //printing final result
        System.out.println("##################################################");
        System.out.println("                Final Result: Single task Task 2                   ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task2_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task2_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task2_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task2_Global_Best_Cost);
        System.out.println("Found in "+ Task2_Global_Best_Gen+ " Generation");
    }
    
    public static void Jaya_Task3(int generation){
        Task3_Local_Best_Cost   = new double[generation];
        Task3_Best_scores_Teams = new String[generation];
        Task3_Best_scores_Teams_No = new int[generation];
        int arr[];
        int task_3_fitness[];
        int updated_long_seq[]=new int[total_persons];
        Random r = new Random();
        int gen=0;
        while(gen < generation){
            //System.out.println("");
            //System.out.println("");
            //System.out.println("Generation "+ gen );
            //get the best value
            int best_index=get_index_best_cost(obj_value2_array_task3);
            int[] best_long_seq=get_population_long_sequence(best_index);
            //get the worst value
            int worst_index=get_index_worst_cost(obj_value2_array_task3);
            int[] worst_long_seq=get_population_long_sequence(worst_index);
            int current_seq[];
            
            //System.out.println("Population printing");
            for(int row=0;row<population_size;row++){

                //System.out.println("######Initial long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));

                current_seq= get_population_long_sequence(row);//get the current sequence
                //System.out.println("long sequence size= "+ current_seq.length);
                //System.out.println("total person= "+ total_persons);
                //System.out.println(row+" "+" "+ array_sequence_to_string(current_seq));
                //System.out.println("size= "+current_seq.length);
                //population update equation
                for (int col=0;col<total_persons;col++){
                    //update equation of jawa
                    updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                        - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));
                    //System.out.println("######Generated by equation long sequence ##############");

                    //System.out.println(j+" = "+ updated_long_seq[j] );

                    //boundary condtion or boundary managing
                    if (updated_long_seq[col]>total_persons-1){
                        updated_long_seq[col]=updated_long_seq[col]-total_persons;
                    }
                    if (updated_long_seq[col]<0){
                        updated_long_seq[col]=total_persons+updated_long_seq[col];
                    }								 

                    //System.out.println(j+" = "+ updated_long_seq[j] );
                    population[row][col]= updated_long_seq[col];//update population
                }//end col
                //System.out.println("######updated long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));
                
                //update everything
                arr= get_population_long_sequence(row);
                
                //System.out.println(row+" "+" "+ array_sequence_to_string(arr));
                //System.out.println("size  "+ arr.length);
                
                task_3_fitness = objective_function_(arr,Task_list.get(2));
                population_short_seq_list_task3[row]=array_sequence_to_string(task_3_fitness);
                int task3_obj_person=objective_value1_(task_3_fitness);
                obj_value1_array_task3[row]=task3_obj_person;
                double task3_obj_costs=objective_value2_(task_3_fitness);
                obj_value2_array_task3[row]=task3_obj_costs;  // total connection cost
                /*
                System.out.println ("--------------------------------------------------");
                System.out.println ("Population no = "+row);
                //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
                System.out.println ("No of person = "+obj_person);
                System.out.println ("Costs = "+obj_costs);

                obj_value1_array[row]=obj_person; 	//no of persons
                obj_value2_array[row]=obj_costs;  // total connection cost
                */
            }
            
            //update local best cost, team members, member number  
            int task3_local_best_index=get_index_best_cost(obj_value2_array_task3);
            Task3_Local_Best_Cost[gen]  = obj_value2_array_task3[task3_local_best_index];
            Task3_Best_scores_Teams[gen]= population_short_seq_list_task3[task3_local_best_index];
            Task3_Best_scores_Teams_No[gen]  = obj_value1_array_task3[task3_local_best_index];
            /*
            System.out.println("**********************************************");
            System.out.println("Local result");
            System.out.println("Generation = "+ gen);
            System.out.println(" Best Score = "+ Best_Scores[gen]);
            System.out.println(" Global Best Score = "+ Global_Best_Scores[gen]);
            System.out.println("Best Team = "+Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Best_team_No[gen]);
            System.out.println(" ");
            System.out.println(" ");
            */
            gen++;
        }
        int     Task3_Global_Best_Gen   = get_index_best_cost(Task3_Local_Best_Cost);
        double  Task3_Global_Best_Cost  = Task3_Local_Best_Cost[Task3_Global_Best_Gen];
        String  Task3_Global_Best_scores_Teams = Task3_Best_scores_Teams[Task3_Global_Best_Gen];
        int     Task3_Global_Best_scores_Teams_No =Task3_Best_scores_Teams_No[Task3_Global_Best_Gen];
        //printing final result
        System.out.println("##################################################");
        System.out.println("                Final Result: Single task Task 3                   ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task3_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task3_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task3_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task3_Global_Best_Cost);
        System.out.println("Found in "+ Task3_Global_Best_Gen+ " Generation");
    }
    
    public static void Jaya_Task4(int generation){
        Task4_Local_Best_Cost   = new double[generation];
        Task4_Best_scores_Teams = new String[generation];
        Task4_Best_scores_Teams_No = new int[generation];
        int arr[];
        int task_4_fitness[];
        int updated_long_seq[]=new int[total_persons];
        Random r = new Random();
        int gen=0;
        while(gen < generation){
            //System.out.println("");
            //System.out.println("");
            //System.out.println("Generation "+ gen );
            //get the best value
            int best_index=get_index_best_cost(obj_value2_array_task4);
            int[] best_long_seq=get_population_long_sequence(best_index);
            //get the worst value
            int worst_index=get_index_worst_cost(obj_value2_array_task4);
            int[] worst_long_seq=get_population_long_sequence(worst_index);
            int current_seq[];
            
            //System.out.println("Population printing");
            for(int row=0;row<population_size;row++){

                //System.out.println("######Initial long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));

                current_seq= get_population_long_sequence(row);//get the current sequence
                //System.out.println("long sequence size= "+ current_seq.length);
                //System.out.println("total person= "+ total_persons);
                //System.out.println(row+" "+" "+ array_sequence_to_string(current_seq));
                //System.out.println("size= "+current_seq.length);
                //population update equation
                for (int col=0;col<total_persons;col++){
                    //update equation of jawa
                    updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                        - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));
                    //System.out.println("######Generated by equation long sequence ##############");

                    //System.out.println(j+" = "+ updated_long_seq[j] );

                    //boundary condtion or boundary managing
                    if (updated_long_seq[col]>total_persons-1){
                        updated_long_seq[col]=updated_long_seq[col]-total_persons;
                    }
                    if (updated_long_seq[col]<0){
                        updated_long_seq[col]=total_persons+updated_long_seq[col];
                    }								 

                    //System.out.println(j+" = "+ updated_long_seq[j] );
                    population[row][col]= updated_long_seq[col];//update population
                }//end col
                //System.out.println("######updated long sequence ##############");
                //System.out.println(row+" "+" "+ array_sequence_to_string(get_population_long_sequence(row)));
                
                //update everything
                arr= get_population_long_sequence(row);
                
                //System.out.println(row+" "+" "+ array_sequence_to_string(arr));
                //System.out.println("size  "+ arr.length);
                
                task_4_fitness = objective_function_(arr,Task_list.get(3));
                population_short_seq_list_task4[row]=array_sequence_to_string(task_4_fitness);
                int task4_obj_person=objective_value1_(task_4_fitness);
                obj_value1_array_task4[row]=task4_obj_person;
                double task4_obj_costs=objective_value2_(task_4_fitness);
                obj_value2_array_task4[row]=task4_obj_costs;  // total connection cost
                /*
                System.out.println ("--------------------------------------------------");
                System.out.println ("Population no = "+row);
                //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
                System.out.println ("No of person = "+obj_person);
                System.out.println ("Costs = "+obj_costs);

                obj_value1_array[row]=obj_person; 	//no of persons
                obj_value2_array[row]=obj_costs;  // total connection cost
                */
            }
            
            //update local best cost, team members, member number  
            int task4_local_best_index=get_index_best_cost(obj_value2_array_task3);
            Task4_Local_Best_Cost[gen]  = obj_value2_array_task4[task4_local_best_index];
            Task4_Best_scores_Teams[gen]= population_short_seq_list_task4[task4_local_best_index];
            Task4_Best_scores_Teams_No[gen]  = obj_value1_array_task4[task4_local_best_index];
            /*
            System.out.println("**********************************************");
            System.out.println("Local result");
            System.out.println("Generation = "+ gen);
            System.out.println(" Best Score = "+ Best_Scores[gen]);
            System.out.println(" Global Best Score = "+ Global_Best_Scores[gen]);
            System.out.println("Best Team = "+Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Best_team_No[gen]);
            System.out.println(" ");
            System.out.println(" ");
            */
            gen++;
        }
        int     Task4_Global_Best_Gen   = get_index_best_cost(Task4_Local_Best_Cost);
        double  Task4_Global_Best_Cost  = Task4_Local_Best_Cost[Task4_Global_Best_Gen];
        String  Task4_Global_Best_scores_Teams = Task4_Best_scores_Teams[Task4_Global_Best_Gen];
        int     Task4_Global_Best_scores_Teams_No =Task4_Best_scores_Teams_No[Task4_Global_Best_Gen];
        //printing final result
        System.out.println("##################################################");
        System.out.println("                Final Result: Single task Task 4                 ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task3_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task4_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task4_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task4_Global_Best_Cost);
        System.out.println("Found in "+ Task4_Global_Best_Gen+ " Generation");
    }
    
    
    
    
    /*
    **Jaya algorithum implimentation for MTO
    */
    public static void jaya_MTO(int generation){
        
        Task1_Local_Best_Cost   = new double[generation];
        Task1_Best_scores_Teams = new String[generation];
        Task1_Best_scores_Teams_No = new int[generation];
        
        Task2_Local_Best_Cost =new double[generation];
        Task2_Best_scores_Teams = new String[generation];
        Task2_Best_scores_Teams_No = new int[generation];
        
        Task3_Local_Best_Cost =new double[generation];
        Task3_Best_scores_Teams = new String[generation];
        Task3_Best_scores_Teams_No = new int[generation];
        
        Task4_Local_Best_Cost =new double[generation];
        Task4_Best_scores_Teams = new String[generation];
        Task4_Best_scores_Teams_No = new int[generation];
        long end_gen=0;
        long start_gen=0;
        
        //initialize_population();
        //System.out.println("#############################JAYA Algorithm#####################");
        int gen=0;
        Random R= new Random();
        //best calculation
        //****clone the previous population/old population
        //****somehow new population get selected so i have to overcome this problem
        //for first iteration use the random index of best and worst solution.
        int best_index=R.nextInt(population_size);
        int worst_index=R.nextInt(population_size);
        int best_long_seq[]=get_population_long_sequence(best_index);
        int worst_long_seq[]=get_population_long_sequence(worst_index);
        //System.out.println("best index cost "+ obj_value2_array_task1[best_index]);
        //System.out.println("best index cost "+ obj_value2_array_task2[best_index]);
        //System.out.println("Population printing"); 
        
        while(gen < generation){ 
           for(int i=0;i<population_size;i++){ //put zero in all index
                reward_List_Best_Index[i]=0;
                reward_List_Worst_Index[i]=0;
           }
        
            int[][] old_population=population.clone();
            //System.out.println("");
            //System.out.println("");
            System.out.println("****************Generation ***********"+ gen+"************" );                        
            Random r = new Random();  
            //start_gen = System.currentTimeMillis();
            for(int row=0;row<population_size;row++){  //iterate the population
                System.out.println("####################Population no "+ row);
                best_found=false;
                no_change=0;
                Force=0;
                while(best_found==false){ //looking until the best found
                    //System.out.println("i am in while loop");
                    int current_seq[]= get_population_long_sequence(row);//get the current sequence
                    int updated_long_seq[]=new int[total_persons];
                    for (int col=0;col<total_persons;col++){
                        updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                    - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));
                        //boundary condtion or boundary managing
                        if (updated_long_seq[col]>total_persons-1){
                            updated_long_seq[col]=updated_long_seq[col]-total_persons;
                        }
                        if (updated_long_seq[col]<0){
                            updated_long_seq[col]=total_persons+updated_long_seq[col];
                        }								 
                    }

                    //1. check fitness task 1
                    int [] task_1_objective_value = objective_function_(updated_long_seq, Task_list.get(0)); //output population short sequence
                    double new_objective_cost_T1= objective_value2_(task_1_objective_value);                    
                    double[] temp_objective_cost_task1 = obj_value2_array_task1.clone();
                    temp_objective_cost_task1[row]=new_objective_cost_T1;
                    int [] temp_rank_task1=task1_rank.clone();
                    
                    //2. rank task 1 fitness
                    temp_rank_task1=create_rank_fitness(temp_objective_cost_task1);

                    //3. check fitness task 2
                    int [] task_2_objective_value = objective_function_(updated_long_seq, Task_list.get(1)); //output population short sequence
                    double new_objective_cost_T2= objective_value2_(task_2_objective_value); 
                    double[] temp_objective_cost_task2 = obj_value2_array_task2.clone();
                    temp_objective_cost_task2[row]=new_objective_cost_T2;
                    
                    //4. rank task 2 fitness
                    int [] temp_rank_task2=task2_rank.clone();
                    temp_rank_task2=create_rank_fitness(temp_objective_cost_task2);

                    //5. check fitness task 3
                    int [] task_3_objective_value = objective_function_(updated_long_seq, Task_list.get(2)); //output population short sequence
                    double new_objective_cost_T3= objective_value2_(task_3_objective_value);
                    double[] temp_objective_cost_task3 = obj_value2_array_task3.clone();
                    temp_objective_cost_task3[row]=new_objective_cost_T3;
                    
                    //6. rank task 3 fitness
                    int [] temp_rank_task3=task3_rank.clone();
                    temp_rank_task3=create_rank_fitness(temp_objective_cost_task3);
                   

                    //7. check fitness task 4
                    int [] task_4_objective_value = objective_function_(updated_long_seq, Task_list.get(3)); //output population short sequence
                    double new_objective_cost_T4= objective_value2_(task_4_objective_value);  
                    //System.out.println("Task 4 cost "+ new_objective_cost_T4);
                    double[] temp_objective_cost_task4 = obj_value2_array_task4.clone();
                    temp_objective_cost_task4[row]=new_objective_cost_T4;
                    
                    //8. rank task 4 fitness
                    int [] temp_rank_task4=task4_rank.clone();
                    temp_rank_task4=create_rank_fitness(temp_objective_cost_task4);
                    
                    /* //for debuging
                    System.out.println("Current objective cost task 1 "+ obj_value2_array_task1[row] );
                    System.out.println("new onjective cost task 1 "+ new_objective_cost_T1 );
                    System.out.println("Current Rank "+ task1_rank[row]);
                    System.out.println("New Rank "+ temp_rank_task1[row]);
                    
                    System.out.println("Current objective cost task 2 "+ obj_value2_array_task2[row] );
                    System.out.println("new onjective cost task 2 "+ new_objective_cost_T2 );
                    System.out.println("Current Rank "+ task2_rank[row]);
                    System.out.println("New Rank "+ temp_rank_task2[row]);
                    
                    System.out.println("Current objective cost task 3 "+ obj_value2_array_task3[row] );
                    System.out.println("new onjective cost task 3 "+ new_objective_cost_T3 );
                    System.out.println("Current Rank "+ task3_rank[row]);
                    System.out.println("New Rank "+ temp_rank_task3[row]);
                    
                    System.out.println("Current objective cost task 4 "+ obj_value2_array_task4[row] );
                    System.out.println("new onjective cost task 4 "+ new_objective_cost_T4 );
                    System.out.println("Current Rank "+ task4_rank[row]);
                    System.out.println("New Rank "+ temp_rank_task4[row]);
                    */

                    //9. scala fitness calculaiton
                    double[] temp_scala_fitness=create_scala_fitness_matrix(temp_rank_task1, temp_rank_task2,temp_rank_task3, temp_rank_task4);
                    //System.out.println("current scala fitness "+ scala_fitness[row]);
                    //System.out.println("New scala fitness "+ temp_scala_fitness[row]);

                    //10. check if the condition apply for change
                    if(temp_scala_fitness[row]>scala_fitness[row] || Force==1){ //solution improve
                        best_found=true;
                        Force=0;                                                
                        // clear the tabu lists
                        Tabu_List_Best.clear();
                        Tabu_List_worst.clear();
                        no_change=0;
                        reward_List_Best_Index[best_index]=reward_List_Best_Index[best_index]+1;//rewards the best index
                        reward_List_Worst_Index[worst_index]=reward_List_Worst_Index[worst_index]+1;//rewards the worst index
                        //System.out.println(" ***************##########Some change *****************************************************************************#############");
                        for (int col=0;col<total_persons;col++){//update population
                            population[row][col]= updated_long_seq[col];
                        }
                        //update task-1 variables
                        population_short_seq_list_task1[row]=array_sequence_to_string(task_1_objective_value);//put the person of interest into short population	            
                        int obj_person=objective_value1_(task_1_objective_value);// get number of the person of interest
                        obj_value1_array_task1[row]=obj_person; 	//no of persons
                        obj_value2_array_task1[row]=new_objective_cost_T1;  // total connection cost
                        task1_rank=temp_rank_task1.clone();
                        
                        //update task-2 variables
                        population_short_seq_list_task2[row]=array_sequence_to_string(task_2_objective_value);//put the person of interest into short population	            
                        obj_person=objective_value1_(task_2_objective_value);// get number of the person of interest
                        obj_value1_array_task2[row]=obj_person; 	//no of persons
                        obj_value2_array_task2[row]=new_objective_cost_T2;  // total connection cost
                        task2_rank=temp_rank_task2.clone();
                        
                        //update task-3 variables
                        population_short_seq_list_task3[row]=array_sequence_to_string(task_3_objective_value);//put the person of interest into short population	            
                        obj_person=objective_value1_(task_3_objective_value);// get number of the person of interest
                        obj_value1_array_task3[row]=obj_person; 	//no of persons
                        obj_value2_array_task3[row]=new_objective_cost_T3;  // total connection cost
                        task3_rank=temp_rank_task3.clone();
                        
                        //update task-4 variables
                        population_short_seq_list_task4[row]=array_sequence_to_string(task_4_objective_value);//put the person of interest into short population	            
                        obj_person=objective_value1_(task_4_objective_value);// get number of the person of interest
                        obj_value1_array_task4[row]=obj_person; 	//no of persons
                        obj_value2_array_task4[row]=new_objective_cost_T4;  // total connection cost
                        task4_rank=temp_rank_task4.clone();
                        
                        //uodate scala fitness
                        scala_fitness= temp_scala_fitness.clone();
                        /*
                        //printing the variables
                        System.out.println("Population " + Arrays.toString(population[row]));
                        System.out.println("Team Member Task-1 "+population_short_seq_list_task1[row] );
                        System.out.println("People No Task-1 "+ obj_value1_array_task1[row]);
                        System.out.println("Connection Cost Task-1 "+ obj_value2_array_task1[row] );
                        System.out.println("*****");
                        System.out.println("Team Member Task-2 "+population_short_seq_list_task2[row] );
                        System.out.println("People No Task-2 "+ obj_value1_array_task2[row]);
                        System.out.println("Connection Cost Task-2 "+ obj_value2_array_task2[row] );
                        System.out.println("*****");
                        System.out.println("Team Member Task-3 "+population_short_seq_list_task3[row] );
                        System.out.println("People No Task-3 "+ obj_value1_array_task3[row]);
                        System.out.println("Connection Cost Task-3 "+ obj_value2_array_task3[row] );
                        System.out.println("*****");
                        System.out.println("Team Member Task-4 "+population_short_seq_list_task4[row] );
                        System.out.println("People No Task-4 "+ obj_value1_array_task4[row]);
                        System.out.println("Connection Cost Task-4 "+ obj_value2_array_task4[row] );
                        */
                    }
                    else{ //solution not improve
                        no_change++;
                        best_found=false;
                        //System.out.println("****No change***"); 
                        //System.out.println("Previous best index "+best_index);
                        best_index=manage_Punishment_method_best_index(best_index);
                        
                        //System.out.println("Previous Worst Index "+ worst_index);
                        worst_index=manage_Punishment_method_worst_index(worst_index,best_index );
                        
                        //collect the best index sequence
                        best_long_seq=get_population_long_sequence(old_population,best_index);
                        //collect the worst index sequence
                        worst_long_seq=get_population_long_sequence(old_population,worst_index);
                        
                        //System.out.println("best index cost "+ obj_value2_array_task2[best_index]);
                        //System.out.println("best index cost "+ obj_value2_array_task3[best_index]);
                        //System.out.println("best index cost "+ obj_value2_array_task4[best_index]);
                    }
                }
            }
            /*
            System.out.println("Task 1 cost "+ Arrays.toString(obj_value2_array_task1));
            System.out.println("Task 2 cost "+ Arrays.toString(obj_value2_array_task2));
            System.out.println("Task 3 cost "+ Arrays.toString(obj_value2_array_task3));
            System.out.println("Task 4 cost "+ Arrays.toString(obj_value2_array_task4)); 
            */
            //update local best cost, team members, member number  
            int task1_local_best_index=get_index_best_cost(obj_value2_array_task1);
            Task1_Local_Best_Cost[gen]  = obj_value2_array_task1[task1_local_best_index];
            Task1_Best_scores_Teams[gen]= population_short_seq_list_task1[task1_local_best_index];
            Task1_Best_scores_Teams_No[gen]  = obj_value1_array_task1[task1_local_best_index];
            
            int task2_local_best_index= get_index_best_cost(obj_value2_array_task2);
            Task2_Local_Best_Cost[gen]= obj_value2_array_task2[task2_local_best_index];
            Task2_Best_scores_Teams[gen]= population_short_seq_list_task2[task2_local_best_index];
            Task2_Best_scores_Teams_No[gen]  = obj_value1_array_task2[task2_local_best_index];
            
            int task3_local_best_index= get_index_best_cost(obj_value2_array_task3);
            Task3_Local_Best_Cost[gen]= obj_value2_array_task3[task3_local_best_index];
            Task3_Best_scores_Teams[gen]= population_short_seq_list_task3[task3_local_best_index];
            Task3_Best_scores_Teams_No[gen]  = obj_value1_array_task3[task3_local_best_index];
            
            int task4_local_best_index= get_index_best_cost(obj_value2_array_task4);
            Task4_Local_Best_Cost[gen]= obj_value2_array_task4[task4_local_best_index];
            Task4_Best_scores_Teams[gen]= population_short_seq_list_task4[task4_local_best_index];
            Task4_Best_scores_Teams_No[gen]  = obj_value1_array_task4[task4_local_best_index];
            /*
            System.out.println("***************Generation = "+ gen+"***************");
            System.out.println("***************Local result***********************");
            
            System.out.println("****************Task 1******************************");                        
            System.out.println("Best Cost = "+ Task1_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task1_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task1_Best_scores_Teams_No[gen]);
            
            System.out.println("*****************Task 2*****************************");
            System.out.println("Best Cost = "+ Task2_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task2_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task2_Best_scores_Teams_No[gen]);
            
            System.out.println("*****************Task 3*****************************");
            System.out.println("Best Cost = "+ Task3_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task3_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task3_Best_scores_Teams_No[gen]);
            
            System.out.println("*****************Task 4*****************************");
            System.out.println("Best Cost = "+ Task4_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task4_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task4_Best_scores_Teams_No[gen]);
            */
            gen++;
            //end_gen = System.currentTimeMillis();
            //long total_time=end_gen-start_gen;
            //System.out.println("Total_time "+ (total_time*.001));
        }
        
        
        ///////////get the global best of all individual task
        int     Task1_Global_Best_Gen   = get_index_best_cost(Task1_Local_Best_Cost);
        double  Task1_Global_Best_Cost  = Task1_Local_Best_Cost[Task1_Global_Best_Gen];
        String  Task1_Global_Best_scores_Teams = Task1_Best_scores_Teams[Task1_Global_Best_Gen];
        int     Task1_Global_Best_scores_Teams_No =Task1_Best_scores_Teams_No[Task1_Global_Best_Gen];
        
        int     Task2_Global_Best_Gen   = get_index_best_cost(Task2_Local_Best_Cost);
        double  Task2_Global_Best_Cost  = Task2_Local_Best_Cost[Task2_Global_Best_Gen];
        String  Task2_Global_Best_scores_Teams = Task2_Best_scores_Teams[Task2_Global_Best_Gen];
        int     Task2_Global_Best_scores_Teams_No =Task2_Best_scores_Teams_No[Task2_Global_Best_Gen];
        
        int     Task3_Global_Best_Gen   = get_index_best_cost(Task3_Local_Best_Cost);
        double  Task3_Global_Best_Cost  = Task3_Local_Best_Cost[Task3_Global_Best_Gen];
        String  Task3_Global_Best_scores_Teams = Task3_Best_scores_Teams[Task3_Global_Best_Gen];
        int     Task3_Global_Best_scores_Teams_No =Task3_Best_scores_Teams_No[Task3_Global_Best_Gen];
        
        int     Task4_Global_Best_Gen   = get_index_best_cost(Task4_Local_Best_Cost);
        double  Task4_Global_Best_Cost  = Task4_Local_Best_Cost[Task4_Global_Best_Gen];
        String  Task4_Global_Best_scores_Teams = Task4_Best_scores_Teams[Task4_Global_Best_Gen];
        int     Task4_Global_Best_scores_Teams_No =Task4_Best_scores_Teams_No[Task4_Global_Best_Gen];
        
        
        //printing final result
        System.out.println("##################################################");
        System.out.println("Final result MTO");
        System.out.println("##################################################");
        System.out.println(" ");
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 1                   ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task1_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task1_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task1_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task1_Global_Best_Cost);
        System.out.println("Found in "+ Task1_Global_Best_Gen+ " Generation");
        
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 2                   ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task2_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task2_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task2_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task2_Global_Best_Cost);
        System.out.println("Found in "+ Task2_Global_Best_Gen+ " Generation");
        
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 3                   ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task3_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task3_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task3_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task3_Global_Best_Cost);
        System.out.println("Found in "+ Task3_Global_Best_Gen+ " Generation");
        
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 4                   ");
        System.out.println("##################################################");
        System.out.println("local cost "+ Arrays.toString(Task4_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task4_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task4_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task4_Global_Best_Cost);
        System.out.println("Found in "+ Task4_Global_Best_Gen+ " Generation");
         
    }
    public static int manage_Punishment_method_best_index(int old_index){
        //System.out.println("||||||||||||||||||||||||||||||||||||||||");
        //System.out.println("I am in management section for best index");
        int new_index=0;
        //punishment
        reward_List_Best_Index[old_index]=reward_List_Best_Index[old_index]-1;//punish the best index
        //System.out.println("    Reward List for best index");
        //System.out.println(Arrays.toString(reward_List_Best_Index));
        //add into tabu list                
        Tabu_List_Best.add(old_index);
        //System.out.println("    Tabu list best index");
        //printArrayList(Tabu_List_Best);
        //sort the reward list
        sortedIndex sr=new sortedIndex();
        int[] sorted_arr_index=sr.sortedValue_Max_To_Min(reward_List_Best_Index, reward_List_Best_Index.length);
        //System.out.println("    Sorted reward best index "+ Arrays.toString(sorted_arr_index));
        boolean new_index_found=false;
        int i=0;
        while(new_index_found==false){
            new_index=sorted_arr_index[i];
            if( Tabu_List_Best.indexOf(new_index)==-1){ //not in tabu list
                new_index_found=true;
               // System.out.println("        new index found");
            }
            else{ //exist in tabu list
                new_index_found=false;
                i++;
                //System.out.println("        nothing new "+new_index);
                //printArrayList(Tabu_List_Best);
                if(i>99){
                new_index_found=true;
                Force=1;
                //System.out.println("        I am forced");
            }
            }
            
            
        }
        //System.out.println(" returning New index best "+ new_index);
        //System.out.println("||||||||||||||||||||||||||||||||||||||||");
        return new_index;
          
    }
    
    public static int manage_Punishment_method_worst_index(int old_worst_index, int new_best_index ){
        ///System.out.println("||||||||||||||||||||||||||||||||||||||||");
        //System.out.println("I am in management section for worst index");
        int new_index=0;
        //punishment
        reward_List_Worst_Index[old_worst_index]=reward_List_Worst_Index[old_worst_index]-1;//punish the best index
        //System.out.println("    Reward List for worst index");
        //System.out.println(Arrays.toString(reward_List_Worst_Index));
        //add into tabu list                
        Tabu_List_worst.add(old_worst_index);
        //System.out.println("    Tabu list worst index");
        //printArrayList(Tabu_List_worst);
        //sort the reward list
        sortedIndex sr=new sortedIndex();
        int[] sorted_arr_index=sr.sortedValue_Max_To_Min(reward_List_Worst_Index, reward_List_Worst_Index.length);
        //System.out.println("    Sorted reward worst index "+ Arrays.toString(sorted_arr_index));
        boolean new_index_found=false;
        int i=0;
        while(new_index_found==false){
            new_index=sorted_arr_index[i];
            //&& new_index!= new_best_index
            if( Tabu_List_worst.indexOf(new_index)==-1 ){ //not in tabu list
                new_index_found=true;
                //System.out.println("        new index found");
            }
            else{ //exist in tabu list
                new_index_found=false;
                /*
                if(new_index== new_best_index){
                    Random r= new Random();
                    i=r.nextInt(100);
                            
                }
                else{
                   i++; 
                   //System.out.println("        nothing new "+new_index);
                }
                */
                i++;
                if(i>99){
                Random r= new Random();
                i=r.nextInt(100);    
                new_index_found=true;
                Force=1;
                //System.out.println("        I am forced");

                }
                
            }
            
            
        }
        //System.out.println(" returning New index worst "+ new_index);
        //System.out.println("||||||||||||||||||||||||||||||||||||||||");
        return new_index;
          
    }
    
    
    
    public static void printArrayList(ArrayList arr){
        for(int i=0;i<arr.size();i++){
            System.out.print(arr.get(i));
            System.out.print(" , ");
        }
        System.out.println(" ");
    }
    
    
    /*
    * remove duplicate value from array
    */
    
    public static int[] get_best_sequence_index(){
        int index[]=new int[2];
        int best_sum=Integer.MAX_VALUE;
        int worst_sum=0;
        for(int i=0;i<task1_rank.length;i++){
            int sum = task1_rank[i]+task2_rank[i];
            if(sum<best_sum){
                index[0]=i;
                best_sum=sum;
            }
            if(sum>worst_sum){
                index[1]=i;
                worst_sum=sum;
            }
        }
     return index;   
    }
    public static int get_index_best_cost(double [] cost  ){	   
	int idx=0;
	double best_cost=Double.MAX_VALUE;	   
	for (int i=0;i<cost.length;i++){
            if (cost[i]<best_cost){
                best_cost=cost[i];
                idx=i;
            }
	}
        
	return idx;
    }
    public static int get_index_best(int [] arr  ){	   
	int idx=0;
	int best_cost=Integer.MAX_VALUE;	   
	for (int i=0;i<arr.length;i++){
            if (arr[i]<best_cost){
                best_cost=arr[i];
                idx=i;
            }
	}
        
	return idx;
    }
    //////////////////////////////////////////////////////////////
    //   Get the ith population long sequence
    //////////////////////////////////////////////////////////////	
    public static int [] get_population_long_sequence (int idx){
        int arr[]=new int[total_persons];
	   
	for (int col=0;col<total_persons;col++)
	    arr[col]=population[idx][col];
	
	return (arr);
    }
    public static int [] get_population_long_sequence (int[][] old_population, int idx){
        int arr[]=new int[total_persons];
	   
	for (int col=0;col<total_persons;col++)
	    arr[col]=old_population[idx][col];
	
	return (arr);
    }
    /*
    ****provide the best score 
    ****update the best scores
    ****update the global scores
    */
    public static int get_index_worst_cost(double [] cost){
        int idx=0;
        double worst_cost=Double.MIN_VALUE;
        for (int i=0;i<cost.length;i++){
            if (cost[i]>worst_cost){
                worst_cost=cost[i];
                idx=i;
            }
        }
        
        return idx;
    }
    
 
    
    
}

