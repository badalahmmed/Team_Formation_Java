/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mto_tl_jaya;

import java.util.Random;

/**
 *
 * @author badal
 */
public class sortedIndex {
    private int indice;
    private int value;
    
    public sortedIndex(int ind, int val){
        indice = ind;
        value = val;
        
    }
    public sortedIndex(){        
    }
    public int getIndice(){
        return indice;
    }
    public double getValue(){
        return value;
    }
    /*
    * provide the n numbers best value indices of an array
    */
    public int[] sortedValue_Max_To_Min(int[] value, int topKValues){
        int[] myArray = new int[value.length];
        sortedIndex[] pairs = new sortedIndex[topKValues];
        //System.out.println("Here are the indices and their values:");
        for(int i = 0; i < myArray.length; i++) {
            myArray[i] = value[i];
            //System.out.println(i+ ": " + myArray[i]);
            for(int j = 0; j < pairs.length; j++){
                //for the first five entries
                if(pairs[j] == null){
                    pairs[j] = new sortedIndex(i, myArray[i]);
                    break;
                }
                else if(pairs[j].getValue() < myArray[i]){ // for max to min "<" for min to max ">"
                    //inserts the new pair into its correct spot
                    for(int k = topKValues-1; k > j; k--){
                        pairs[k] = pairs [k-1];
                    }
                    pairs[j] = new sortedIndex(i, myArray[i]);
                    break;
                }
            }
        }
        int[] TopKIndices= new int[topKValues];
        //System.out.println("\n5 Max indices and their values");
        for(int i = 0; i < pairs.length; i++){
            TopKIndices[i]= pairs[i].getIndice();
            //System.out.println("index "+ pairs[i].getIndice()+ " value"+ pairs[i].getValue());
            
        }
        //System.out.println("**********************");
        return TopKIndices;
    }
    public int[] sortedValue_Min_To_Max(int[] value, int topKValues){
        int[] myArray = new int[value.length];
        sortedIndex[] pairs = new sortedIndex[topKValues];
        //System.out.println("Here are the indices and their values:");
        for(int i = 0; i < myArray.length; i++) {
            myArray[i] = value[i];
            //System.out.println(i+ ": " + myArray[i]);
            for(int j = 0; j < pairs.length; j++){
                //for the first five entries
                if(pairs[j] == null){
                    pairs[j] = new sortedIndex(i, myArray[i]);
                    break;
                }
                else if(pairs[j].getValue() > myArray[i]){ // for max to min "<" for min to max ">"
                    //inserts the new pair into its correct spot
                    for(int k = topKValues-1; k > j; k--){
                        pairs[k] = pairs [k-1];
                    }
                    pairs[j] = new sortedIndex(i, myArray[i]);
                    break;
                }
            }
        }
        int[] TopKIndices= new int[topKValues];
        //System.out.println("\n5 Max indices and their values");
        for(int i = 0; i < pairs.length; i++){
            TopKIndices[i]= pairs[i].getIndice();
            //System.out.println("index "+ pairs[i].getIndice()+ " value"+ pairs[i].getValue());
            
        }
        //System.out.println("**********************");
        return TopKIndices;
    }
}
