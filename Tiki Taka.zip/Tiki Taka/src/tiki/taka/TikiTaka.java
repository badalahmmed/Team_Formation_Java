/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiki.taka;

import java.util.Random;
import java. util. Arrays;
import java.util.Collections;

/**
 *
 * @author badal
 */
public class TikiTaka {
    
    static int population_size=100;
    static double x[] = new double[population_size];
    static double b[] = new double[population_size];
    static double obj_value[] = new double[population_size];
    static double LB=1.5;
    static double UB=10;
    static int no_of_key_players=10;
    static double key_players[] = new double[no_of_key_players];
    static int Local_Best_Player_index;
    static double Local_Best_Player;
    static double Global_best_player;
    //algo parameters
    static double Prob_loss=0.2;
    static double C1=0.5;
    static double C2=1.5;
    static double C3=0.6;
    


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println ("Algorithm: Tiki Taka"); 
        
        initialization(); // initialize players, ball position, and evaluate players
        for (int iteration = 1;iteration < 100;iteration++){    //iterate generation
            System.out.println("############Iteration no: "+ iteration+"#################");
            for (int i=0;i<population_size;i++){     // iterate the population
                System.out.println("*****Population no: "+i+"****");
                
                System.out.println("Population = "+ x[i]);
                System.out.println("Ball position = "+ b[i]);
                System.out.println("Fitness = "+obj_value[i]);
                System.out.println("  ");
                
                upate_ball_position(i);
                //System.out.println("update under condition " + b[i]);
                update_player_position(i);
                
            }
            System.out.println("**********");
            System.out.println(" ");
            //update key players
            key_players();
            Local_Best_Player = key_players[0];
            System.out.println("Local best Player = "+ Local_Best_Player);
            if( Local_Best_Player>Global_best_player){
                Global_best_player= Local_Best_Player;
            }
            System.out.println("Global best= "+ Global_best_player);
            
        }
        
    
}
    
    /**
     * Generate random population for the 1st time
    */
    public static void generate_random_population(){
        double p1 = 0.5;

        for (int i=0;i<population_size;i++){
            Random r = new Random();
            double k= r.nextDouble();
            if (k>p1)
                x[i]=LB-((UB-LB)*r.nextDouble());
            else
                x[i]=LB+((UB-LB)*r.nextDouble()); 

            if (x[i]>UB)
                x[i]=UB-(x[i]/10);

            if (x[i]<LB)
                if(x[i]<0){
                    x[i]=-(x[i]/10)+LB;
                }
                else{
                    x[i]=x[i]+LB;
                }
        }
    }
    /**
     * generate ball position for the first time
     */
     public static void generate_ball_position(){
        double p1 = 0.55;

        for (int i=0;i<population_size;i++){
            Random r = new Random();
            double l= r.nextDouble();
            if (l>p1)
                b[i]=LB-((UB-LB)*r.nextDouble());
            else
                b[i]=LB+((UB-LB)*r.nextDouble()); 
            //System.out.println(b[i]);
            if (b[i]>UB){
                b[i]=UB-(-b[i]/100);
                //System.out.println("condition1");
            }
            if (b[i]<LB){
                if(b[i]<0){
                    b[i]=-(b[i])+LB;
                    //System.out.println("condition2");
                }
                else{
                    b[i]=b[i]+LB;
                    //System.out.println("condition3");
                }
            }
        }
    }
    /*
     *initialize the tikitaka algorithm
     */
    public static void initialization(){
        //initialize the population
        generate_random_population(); 
        //initialize the ball position
        generate_ball_position();
        //fitness evaluate
        key_players();
        Local_Best_Player=key_players[0];
        Global_best_player= Local_Best_Player; 

    }
    
    /**
     * objective function of the problem
     */
    public static double ObjectiveFunction (double x){
        return ((x-2)*(6-x*x)*(x*x*x-11));
    }
    
    /*
    *update the ball position
    */
    private static void upate_ball_position(int index) {
        Random t = new Random();
        double r_p = t.nextDouble();
        int next_index;
        if(index == population_size-1){
            next_index=0;
        }
        else{
            next_index=index+1;
        }
        //System.out.println("index " + index);
        //System.out.println("ramdom "+ r_p);
        double new_ball_position=0;
        if(r_p>Prob_loss){
            //System.out.println("old ball position "+ b[index]);
            //System.out.println("pos1 "+ b[index]+"pos2 "+ b[next_index]);
            new_ball_position = randomOfTwoNumbers(b[index],b[next_index])+ b[index];
            //b[index]=new_ball_position;   
            //System.out.println("new_ball_position "+new_ball_position);
        }
        else{
            //System.out.println("old ball position "+ b[index]);
            //System.out.println("pos1 "+ b[index]+"pos2 "+ b[next_index]);
            new_ball_position = b[index]-(C1+t.nextDouble())*(b[index]-b[next_index]);
            //b[index]=new_ball_position;
            //System.out.println("new_ball_position "+new_ball_position);
        }
        if(new_ball_position>UB){
            int a1= (int) (new_ball_position/UB);
            b[index]= (new_ball_position- a1*UB) +LB;
        }
        else if(new_ball_position<LB){
            if(new_ball_position<0){
                b[index]= -new_ball_position;
            }
            else{
                b[index]= new_ball_position+LB;
            }
            
        }
        else{
            b[index]= new_ball_position;
            
        }
    }
    /*
    *provide random of two unknown double numbers
    */
    public static double randomOfTwoNumbers(double x, double y){
        Random ram= new Random();
        double output;
        //System.out.println("difference "+ (x-y));
        if(x>y){
            output=ram.nextDouble()*(x-y)+x;
            //System.out.println("1st condition");
        }
        else{
            output= ram.nextDouble()*(y-x)*y;
            //System.out.println("2nd condition");
        }
        return output;
    }
    /*
    *update players positions
    */
    public static void update_player_position(int index){
        Random Ran= new Random();
        double h = x[Ran.nextInt(no_of_key_players)];
        double newP= x[index]+ Ran.nextDouble()*C2*(b[index]-x[index])+Ran.nextDouble()*C3*(h-x[index]);
        //System.out.println("player "+ newP);
        if(newP>UB){
            int a1= (int) (newP/UB);
            if(a1<2){
               x[index]=UB-LB; 
            }
            else{
            x[index]= (UB-LB)*0.5+LB;
            }
            
        }
        else if(newP<LB){
            if(newP<0){
                if((-newP/UB)>UB){
                    x[index]= (UB-LB)*0.4+LB;
                }
                else{
                x[index]= LB;
                }
            }
            else{
                x[index]= newP+LB;
                
            }
            
        }
        else{
            x[index]= newP;
            
            
        }
        //System.out.println("Updated player Position= "+ x[index]);
    }
    /*
    *Update the key players
    */
    public static void key_players(){
        for(int i=0;i<population_size;i++){
            //get the objective value
            obj_value[i]= ObjectiveFunction(x[i]); //getting the objective values            
        }
        
        int[] Key_Players_indeces= new int[no_of_key_players];
        //get the key Players based on objective values
        sortedIndex ax= new sortedIndex();
        Key_Players_indeces = ax.sortedValue(obj_value, no_of_key_players);
        //update the key players
        for(int p=0;p<key_players.length;p++){
            key_players[p]=x[Key_Players_indeces[p]];
        }
        System.out.println("key Players indices "+ Arrays.toString(Key_Players_indeces));
        System.out.println("Key players " + Arrays.toString(key_players));
    }

}


