/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mto_tikitaka;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author badal
 */
public class MTO_TikiTaka {
    static ArrayList<String> memory_list = new ArrayList<String>(); //memory list for data loading
    static ArrayList<String> skills_list = new ArrayList<String>(); //unique skills list in dataset
    static ArrayList<String> persons_list = new ArrayList<String>(); //unique person list in dataset
    static ArrayList<String> unprocess_skills_connections = new ArrayList<String>();
    static ArrayList<String> unprocess_costs_connections = new ArrayList<String>();
    
    static int        total_persons; //total no of person in dataset
    static int        total_skills; //total no of unique skill in dataset
    static int        count_fitness_evaluation=0;
    static int        population_size_STO= 32;
    static int        population_size=population_size_STO*4; //population size for optimization algo
    static int        division = 5;
    static int        Generation;
    static double     Global_Best;
    
    
    static int [][]   skills_connections; // skills connection array for all people
    static double[][] costs_connections;  //cost connection array between everyone
    static int []     skills_to_find;     // skills that we have to be looking
    static int []     clone_skills_to_find; //for data handlinf dummy variable
    static ArrayList<String> Task_path = new ArrayList< String>();
    static ArrayList<int []> Task_list = new ArrayList< int []>();
    //task related variables
    static int total_task=4;
    static int [] task_1;
    static int [] task_2;
    static int [] task_3;
    static int [] task_4;
    static int    cluster_size = population_size/total_task;
    
    
    static int best_idx_value_in_cluster_ [] = new int [division]; // stor best index value of a cluster into system
    // Population array
    static int[][]   population; //store population long sequence
    
    //store population of person of interest/nshort sequence
    static String[]  population_short_seq_list;  
    
    
    //store no of person of interest
    static int []    obj_value1_array; 
    
    
    //store cost connection between person of interest
    static double []   obj_value2_array;  
    
    
    private static double[]  Task1_Local_Best_Cost;
    private static String [] Task1_Best_scores_Teams;
    private static int []    Task1_Best_scores_Teams_No;

    
    private static double[]  Task2_Local_Best_Cost;
    private static String [] Task2_Best_scores_Teams;
    private static int []    Task2_Best_scores_Teams_No;
    
    private static double[] Task3_Local_Best_Cost;
    private static String [] Task3_Best_scores_Teams;
    private static int []    Task3_Best_scores_Teams_No;
    
    private static double[] Task4_Local_Best_Cost;
    private static String [] Task4_Best_scores_Teams;
    private static int []    Task4_Best_scores_Teams_No;
    
    
    
    static int[] Best_team_No;
    static boolean Best_Team;
    static String Best_Team_Formation;
    static double Best_Cost;
    static int Person_Number;
    //tikitaka parameters and veraibles
    static int[][] ball_position;
    static int no_of_key_players= 2; // 10% of population size
    
    static int[] Task1_Key_Players_indeces;
    static int[] Task2_Key_Players_indeces;
    static int[] Task3_Key_Players_indeces;
    static int[] Task4_Key_Players_indeces;
    static double Prob_Loss =0.2;
    static double C1 = 1.75;
    static double C2 = 1.25;
    static double C3 = 2.50;
    
    
    //printing output results
    static ArrayList<Integer> STO_T1_Team_Size = new ArrayList<>();
    static ArrayList<Integer> STO_T2_Team_Size = new ArrayList<>();
    static ArrayList<Integer> STO_T3_Team_Size = new ArrayList<>();
    static ArrayList<Integer> STO_T4_Team_Size = new ArrayList<>();
    static ArrayList<Integer> MTO_T1_Team_Size = new ArrayList<>();
    static ArrayList<Integer> MTO_T2_Team_Size = new ArrayList<>();
    static ArrayList<Integer> MTO_T3_Team_Size = new ArrayList<>();
    static ArrayList<Integer> MTO_T4_Team_Size = new ArrayList<>();
    
    static ArrayList<Double> STO_T1_Team_Cost = new ArrayList<>();
    static ArrayList<Double> STO_T2_Team_Cost = new ArrayList<>();
    static ArrayList<Double> STO_T3_Team_Cost = new ArrayList<>();
    static ArrayList<Double> STO_T4_Team_Cost = new ArrayList<>();
    static ArrayList<Double> MTO_T1_Team_Cost = new ArrayList<>();
    static ArrayList<Double> MTO_T2_Team_Cost = new ArrayList<>();
    static ArrayList<Double> MTO_T3_Team_Cost = new ArrayList<>();
    static ArrayList<Double> MTO_T4_Team_Cost = new ArrayList<>();
    
    static ArrayList<Integer> STO_T1_Convergence = new ArrayList<>();
    static ArrayList<Integer> STO_T2_Convergence = new ArrayList<>();
    static ArrayList<Integer> STO_T3_Convergence = new ArrayList<>();
    static ArrayList<Integer> STO_T4_Convergence = new ArrayList<>();
    static ArrayList<Integer> MTO_T1_Convergence = new ArrayList<>();
    static ArrayList<Integer> MTO_T2_Convergence = new ArrayList<>();
    static ArrayList<Integer> MTO_T3_Convergence = new ArrayList<>();
    static ArrayList<Integer> MTO_T4_Convergence = new ArrayList<>();
    static ArrayList<Double> STO_T1_Time = new ArrayList<>();
    static ArrayList<Double> STO_T2_Time = new ArrayList<>();
    static ArrayList<Double> STO_T3_Time = new ArrayList<>();
    static ArrayList<Double> STO_T4_Time = new ArrayList<>();
    static ArrayList<Double> MTO_Time = new ArrayList<>();
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args)throws IOException {
        //load data into system and initialize systems
        program_Initialization();
        int tas=5;
        while(tas<100){
            task_1 = create_task(tas);
            task_2 = create_task(tas);
            task_3 = create_task(tas);
            task_4 = create_task(tas);
            int times=0;
            while(times<30){
                //System.out.println("Times : "+ times);
                
                ////////
                double startT1=System.currentTimeMillis();
                TTA_STO(100, task_1 ,1, "STO Task 1");
                double endT1 = System.currentTimeMillis();
                TTA_STO(100, task_2 ,2, "STO Task 2");
                double endT2 = System.currentTimeMillis();
                TTA_STO(100, task_3 ,3, "STO Task 3");
                double endT3 = System.currentTimeMillis();
                TTA_STO(100, task_4 ,4, "STO Task 4");  
                double endT4 = System.currentTimeMillis();
                Generation=100;
                TikiTaka(Generation);
                double endT5 = System.currentTimeMillis();
                STO_T1_Time.add(endT1-startT1);
                STO_T2_Time.add(endT2-endT1);
                STO_T3_Time.add(endT3-endT2);
                STO_T4_Time.add(endT4-endT3);
                MTO_Time.add(endT5-endT4);
                times++;
            }
        System.out.println("No of Skills looking for "+ tas);
        System.out.println("#################Overal Results##########################################");
        System.out.println("STO Task 1:, " + " Team Size ,"+average_result_int(STO_T1_Team_Size)+ ", "+average_result_int(MTO_T1_Team_Size)+ ", Team Cost, "+average_result_double(STO_T1_Team_Cost)+", "+average_result_double(MTO_T1_Team_Cost)  +", Convergence, "+ average_result_int(STO_T1_Convergence)+", "+average_result_int(MTO_T1_Convergence) );
        System.out.println("STO Task 1:, " + " Team Size ,"+average_result_int(STO_T2_Team_Size)+ ", "+average_result_int(MTO_T2_Team_Size)+ ", Team Cost, "+average_result_double(STO_T2_Team_Cost)+", "+average_result_double(MTO_T2_Team_Cost)  +", Convergence, "+ average_result_int(STO_T2_Convergence)+", "+average_result_int(MTO_T2_Convergence) );
        System.out.println("STO Task 1:, " + " Team Size ,"+average_result_int(STO_T3_Team_Size)+ ", "+average_result_int(MTO_T3_Team_Size)+ ", Team Cost, "+average_result_double(STO_T3_Team_Cost)+", "+average_result_double(MTO_T3_Team_Cost)  +", Convergence, "+ average_result_int(STO_T3_Convergence)+", "+average_result_int(MTO_T3_Convergence) );
        System.out.println("STO Task 1:, " + " Team Size ,"+average_result_int(STO_T4_Team_Size)+ ", "+average_result_int(MTO_T4_Team_Size)+ ", Team Cost, "+average_result_double(STO_T4_Team_Cost)+", "+average_result_double(MTO_T4_Team_Cost)  +", Convergence, "+ average_result_int(STO_T4_Convergence)+", "+average_result_int(MTO_T4_Convergence) );
        System.out.println("Run Times "+average_result_double(STO_T1_Time)+","+average_result_double(STO_T2_Time)+","+average_result_double(STO_T3_Time)+","+average_result_double(STO_T4_Time)+","+average_result_double(MTO_Time)/4.0 );
        tas=tas+5;
        }
              
    }
    public static int average_result_int( ArrayList<Integer> arr){
        int sum=0;
        for(int i=0;i<arr.size();i++){
            sum= sum + arr.get(i);
        }
        int result = sum / arr.size();
        return result;
    }
    public static double average_result_double( ArrayList<Double> arr){
        double sum=0;
        for(int i=0;i<arr.size();i++){
            sum= sum + arr.get(i);
        }
        double result = sum / arr.size();
        return result;
    }
    public static void program_Initialization()throws IOException{
        String basic_path= "E:\\Optimization related\\Team formation Code\\data\\ConnectionCost_ExtractedSkill_Staff_Expertise_DataSet\\";
        //load data into system and initialize systems
        load_skills_in_memory(basic_path+"ExtractedSkill_Staff_Expertise_Data.txt"); 
        
        process_skills();
        initialize_skills_connections();
        load_costs_in_memory(basic_path+"ConnectionCost_Staff_Expertise_Data.txt");
        process_costs();
        initialize_costs_connections();
        
        //load task path into the system
        load_tasks_path(basic_path); 
        load_tasks(19);
        
    }
    public static int[] create_task(int no_task){
        Random ran = new Random();
        int[] task= new int[total_skills];
        ArrayList<Integer> temp_list = new ArrayList<Integer>();
        int skill_index=0;
        int finish=0;
        while(finish==0){
            //choose skill randomly
            skill_index = ran.nextInt(total_skills);
            if (!temp_list.contains(skill_index)){
                    //System.out.println("Index "+ skill_index);
                    temp_list.add(skill_index);
                    
            }
            if(temp_list.size()==no_task){
                finish=1;
            }
        }
        //create task
        //System.out.println("size "+ temp_list.size());
        for(int j=0;j<total_skills;j++){
            if(temp_list.contains(j)){
                task[j]=1;
            }
            else{
                task[j]=0;
            }
        }
        //print the required task
        //System.out.println("created Task "+ Arrays.toString(task));
        /*
        System.out.println(":::::::::::::Expertizes We Looking for::::::::::::");
            int[] serach_skills_index= new int[total_skills];
            int q=1;
            
            for(int j=0;j<total_skills;j++){
                if(task[j]==1){
                    serach_skills_index[q]= j;
                    q++;
                }
            }
            serach_skills_index[0]=q;
            //System.out.println("skills index "+ Arrays.toString(serach_skills_index));
            for(int l=1;l<serach_skills_index[0];l++){
            System.out.println(l+" Search Skills name : "+ skills_list.get(serach_skills_index[l])+"("+serach_skills_index[l]+")");
            }    
            */
        
        
       return task;
        
    }
    
    public static void load_tasks_path(String basic_path){
        // 5 skills set
        String path1 = basic_path + "Required skills 5_1.txt";
        String path2 = basic_path + "Required skills 5_2.txt";
        String path3 = basic_path + "Required skills 5_3.txt";
        String path4 = basic_path + "Required skills 5_4.txt";
        String path5 = basic_path + "Required skills 5_5.txt";
        
        //10 Skills set
        String path6  = basic_path+"Required skills 10_1.txt";
        String path7  = basic_path+"Required skills 10_2.txt";
        String path8  = basic_path+"Required skills 10_3.txt";
        String path9  = basic_path+"Required skills 10_4.txt";
        String path10 = basic_path+"Required skills 10_5.txt";  
        
          //15 skills set
        String path11=basic_path+"Required skills 15_1.txt";
        String path12=basic_path+"Required skills 15_2.txt";
        String path13=basic_path+"Required skills 15_3.txt";
        String path14=basic_path+"Required skills 15_4.txt";
 
        //20 skills set
        String path15=basic_path+"Required skills 20_1.txt";
        String path16=basic_path+"Required skills 20_2.txt";
        String path17=basic_path+"Required skills 20_3.txt";
        String path18=basic_path+"Required skills 20_4.txt";
        String path19=basic_path+"Required skills 80.txt";
        
        Task_path.add(path1);
        Task_path.add(path2);
        Task_path.add(path3);
        Task_path.add(path4);
        Task_path.add(path5);
        
        Task_path.add(path6);
        Task_path.add(path7);
        Task_path.add(path8);
        Task_path.add(path9);
        Task_path.add(path10);
        
        Task_path.add(path11);
        Task_path.add(path12);
        Task_path.add(path13);
        Task_path.add(path14);
        
        Task_path.add(path15);
        Task_path.add(path16);
        Task_path.add(path17);
        Task_path.add(path18);
        Task_path.add(path19);
    }
    
    /*
    ***Load task list into the system as an arraylist
    */
    public static void load_tasks(int number_of_task)throws IOException{
        for(int i=0;i<number_of_task;i++){
            int [] task =load_skills_to_find(Task_path.get(i));
            //System.out.println("#################TASK = "+ i+ "   Added");
            //System.out.println("file name"+Task_path.get(i) );
            //System.out.println("skills task 1: "+ Arrays.toString(task));
            Task_list.add(task);     
        }      
    }
    /*
    * load the skills file into memory for processing
    */
    public static void load_skills_in_memory (String skills_file) throws FileNotFoundException, IOException{
        try (RandomAccessFile f = new RandomAccessFile(skills_file,"r")) {
            long length = f.length();
            long position = 0;
            String content;
            int count=0;
            //System.out.println ("Loading skills file in memory => "+skills_file);
            // rewind file to position 0
            f.seek(0);
            memory_list.clear();
            //System.out.println("File Length"+ length);
            //System.out.println();
            
            while (position < length){
                //System.out.println("while loop");
                //if (count%5==0){
                    //System.out.println ("Count = ["+count+"] Loading skills to memory ...please wait");
                //}
                count++;
                content = f.readLine();
                memory_list.add(content);
                //System.out.println("text"+ content);
                position = f.getFilePointer();
            }
        } 
        //System.out.println("Load Skills in Memory Done");
	}
    
    /*
    *Process the skill file and extract 
                # no of total_persons
                # no of total_skills
                # persons_list
                # skills_list
                # unprocess_skills_connections

    *
    */
    public static void process_skills () {
	String content;
	//System.out.println ("Processing Skills ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
		String string_val = results[i];
                if (string_val.trim().equals("Total Persons".trim())){  
                    total_persons=Integer.parseInt(results[1]);
                    
                    process_already=true;
		}
		else if (string_val.trim().equals("Total Skills".trim())){  
                    total_skills=Integer.parseInt(results[1]);
                    process_already=true;
		}
		else if (string_val.trim().equals("Persons Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                        persons_list.add(results2[j]);
                        //System.out.println ("Adding person => "+results2[j]);
                    }
                    process_already=true;		
                }      
		else if (string_val.trim().equals("Skills Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                            skills_list.add(results2[j]); 
                            //System.out.println ("Adding skill => "+results2[j]);
                    }
                            process_already=true;
                } 
		else{ // store unprocess skills connections 
                    if (!unprocess_skills_connections.contains(content)&& process_already==false){
                        unprocess_skills_connections.add(content);
                    }
                }
            }	
        }
        /* For debugning 
        System.out.println("Total Persons = " + total_persons+"****************" );
        for(int i=0;i<persons_list.size();i++){
          System.out.println(i+" "+persons_list.get(i));  
        }
        */
        //System.out.println("Total Skills " + total_skills +"********************");
         //for(int i=0;i<skills_list.size();i++){
          //System.out.println(i+" "+skills_list.get(i));  
        //}
        
        //System.out.println("Process Skill Processing Done.");
    }
    
    /*
    *Initialize skills connection or create skills connection Matrix into 2D array
    */
    public static void initialize_skills_connections(){	  
	skills_connections = new int [total_persons][total_skills];
	// initialize initial connections
	//System.out.println ("Initializing Skills Connection Metrics..");
        for (int row=0;row<total_persons;row++){
            for (int col=0;col<total_skills;col++){
                skills_connections[row][col]=0; 
                //System.out.println ("Unprocess connections from skills file => "+unprocess_skills_connections.size()); 
		for (int i=0;i<unprocess_skills_connections.size();i++){
                    String s = unprocess_skills_connections.get(i).trim();
                    String result[] = s.split("=");
                    String val[] = result[1].split(":");
                    for (int j=0;j<val.length;j++){
                        skills_connections[i][j]= (int)Integer.parseInt(val[j]);
                        //System.out.println("Skill connection matric"+ skills_connections[i][j]);
                    }   
                }
            } 
        }
        //System.out.println("Skill Connection Matrix Size(Total person X Total unique skills) = "+skills_connections.length+"x"+skills_connections[0].length );
        //System.out.println ("Initialize Skills Connection Metrics Done.");
		   
    }
    
    /*
    * load the skills file into memory for processing
    */
    public static void load_costs_in_memory (String costs_file)throws IOException{
        //System.out.println("Loading Costs File in Memory");
	RandomAccessFile f = new RandomAccessFile(costs_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	int count=0;
	//System.out.println ("Loading costs file in memory => "+costs_file);
        // rewind file to position 0
        f.seek(0);
	memory_list.clear();
        while (position < length){
            if (count%5==0)
            //System.out.println ("Count = ["+count+"] Loading costs to memory ...please wait");
            count++;
            content = f.readLine();
            memory_list.add(content);
            //System.out.println("data"+ content);
            position = f.getFilePointer();
        }	
        f.close(); 
        
        //System.out.println("Loading Costs File in Memory Done");
        
    }
        
    /*
    *Process the costs file and extract 
                # unprocess_skills_connections
    
    *
    */
    
    public static void process_costs (){
        String content;
        //System.out.println ("Processing costs ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
                String string_val = results[i];
                if (string_val.trim().equals("Persons Mapping".trim())){
                    process_already=true;
                    continue;	
                }       
                else{ // store unprocess costs connections 
                    if (!unprocess_costs_connections.contains(content)&& process_already==false)
                        unprocess_costs_connections.add(content);
                }
            }
        }
        //System.out.println ("Processing costs Done");
    }
    
    /* Initialize the cost connection matrix to form cost matrix
    
    */
    
    public static void initialize_costs_connections(){
	costs_connections = new double [total_persons][total_persons];
	// initialize initial connections
	//System.out.println ("Initializing costs connection metrics..");
        
        for (int i=0;i<unprocess_costs_connections.size();i++){
            String s = unprocess_costs_connections.get(i).trim();
            String result[] = s.split("=");
            String val[] = result[1].split(":");
            for (int j=0;j<val.length;j++){
                costs_connections[i][j]= (double)Double.parseDouble(val[j]);
                //System.out.print( costs_connections[i][j]+" ");
            } 
            //System.out.println(" ");
        }
        //System.out.println("Cost Matrix Size(Total Person X Total Person) = "+ costs_connections.length+" X "+ costs_connections[0].length);
        //System.out.println ("Initializing costs connection metrics Done");
   }

    /*
    Load the text file which contails the team skills set
    */
    public static int[] load_skills_to_find (String values_file) throws IOException{
        //System.out.println("load_skills_to_find .....processing");
        RandomAccessFile f = new RandomAccessFile(values_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	f.seek(0);
        ArrayList<Integer> match_idx = new ArrayList<Integer>();
	while (position < length){
            content = f.readLine();
            String results[] = content.split("=");
            String val[] = results[1].split(",");
            for (int i=0;i<val.length;i++){			
                int index = skills_list.indexOf(val[i].trim());
                //System.out.println ("Skills to search for ==> "+val[i]);
                //if (index==-1){
                    //System.out.println ("One of the skills requested does not exist...");
                    //System.exit(0);
                //} 				  
                //else{
                    //match_idx.add(index);
                    //}
  
            }	 
	    position = f.getFilePointer();
		  
        }
        f.close();		 		
        Collections.sort(match_idx); 
        skills_to_find= new int[total_skills];
        Arrays.fill(skills_to_find, 0); //put zero into all spaces
        for (int i=0;i<total_skills;i++){
            if (match_idx.contains(i)){// if match put 1 into that space
                skills_to_find[i]=1;
            }
        }
        //System.out.println("Load Skills to Find Done");
        return skills_to_find;
    }
    
    /*
    *objective Function]
    * input: random person sequence
    * output: persons who has skills/ skill
    
    */
    public static int [] objective_function_ (int arr [], int [] skills_to_find ){
        boolean consist_skills_value=false;
        int update_answer[] = new int[total_skills];
        Arrays.fill(update_answer, 0); //fill the int array by zero.

        ArrayList<Integer> trim_seq = new ArrayList<Integer>();
        String value_skills = array_sequence_to_string (skills_to_find);  //converte arr into string
        //System.out.println("I am in objective function");
        clone_skills_to_find = skills_to_find.clone();
        
	
        for (int i=0;i<arr.length;i++){
            
            consist_skills_value=false;
            if (i==0){ // for first iteration
                for (int j=0;j<total_skills;j++){
                    update_answer[j]=skills_connections[arr[i]][j];// get the skill sets of a person
                    
                }
                //System.out.println ("Current seq value in zero = "+arr[i]);
                //String s =array_sequence_to_string (update_answer);
                //System.out.println ("sill sets of current person " +arr[i]+"  = " +s); 
                //System.out.println ("Skills to find                =   "+value_skills);
                consist_skills_value=contain_skills_to_find(update_answer,clone_skills_to_find);//check the person has that specific skills set
                if (consist_skills_value){   
                    trim_seq.add(arr[i]);// if has the skill, add that person into person of interest
                }
            }
            else{ //for all iteration
                int tmp_answer[] = new int[total_skills];
                Arrays.fill(tmp_answer, 0);
                for (int j=0;j<total_skills;j++){
                          tmp_answer[j]=skills_connections[arr[i]][j];
                }
                //System.out.println ("Current seq value non zero= "+arr[i]);
                //String s =array_sequence_to_string (tmp_answer);
                //System.out.println ("Update s       = "+s); 
                //System.out.println ("Skills to find = "+value_skills); 
                consist_skills_value=contain_skills_to_find(tmp_answer,clone_skills_to_find);
                if (consist_skills_value){
                    trim_seq.add(arr[i]);
                    //System.out.println("added person*****************************************");
                    update_answer= merge_elements_(update_answer,tmp_answer);	   
                    if (complete_merge_sequence_(update_answer,skills_to_find)){
                        //System.out.println("found all################################################yah");
                        break;	 //if all skills are covered
                    }                    
                }
                //s =array_sequence_to_string (update_answer);
                //System.out.println ("Skills so far  = "+s);
            }
        } 

        	
        int trim_result[] = new int [trim_seq.size()];
        for (int i=0;i<trim_seq.size();i++){
            trim_result[i]=trim_seq.get(i);
        }
        
        return trim_result; //return the persons sequences who have required skill or skills
    }
    /*
    ******** convert array sequence into string value
    */
    public static String array_sequence_to_string (int array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Integer.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Integer.toString(array[i]);
        }
        return (sequence);
    }
    
     public static String double_array_sequence_to_string (double array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Double.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Double.toString(array[i]);
        }
        return (sequence);
    }
    //////////////////////////////////////////////////////////
    //  Check if the given sequence has at least 1 skills 
    //  that we are looking for
    //////////////////////////////////////////////////////////
    //######need to change the mecanism##############
    public static boolean contain_skills_to_find (int arr[], int clone_skills_to_find[]){
        boolean outcome = false;
        for (int x=0; x<clone_skills_to_find.length; x++){
            if (clone_skills_to_find[x]==1 && arr[x]==1){
		outcome=true;
		clone_skills_to_find[x]=0;  // to signify already covered skill
		//break;
            }
        }
        return outcome;
    }
    
    ////////////////////////////////////////////////////////////
   //    Merge elements
   ///////////////////////////////////////////////////////////
   public static int [] merge_elements_ (int arr1[],int arr2[]){ 
        int merge_array[] = new int[total_skills];
        Arrays.fill(merge_array, 0); 
        for (int x=0; x<arr1.length; x++){
            if (arr1[x]==arr2[x])
                merge_array[x]=arr1[x];
            else if (arr1[x]==0 && arr2[x]==1)
                merge_array[x]=1;//remove zero person
            else if (arr1[x]==1 && arr2[x]==0)
                merge_array[x]=1; //remove zero person
        }
        
        return merge_array;
    }
    
    //////////////////////////////////////////////////////////
    //  Check for complete merge against skills to find
    //////////////////////////////////////////////////////////
    public static boolean complete_merge_sequence_ (int arr[], int skills_to_find[]){
        boolean outcome = true;
        for (int x=0; x<skills_to_find.length; x++){
          if (skills_to_find[x]==1 && arr[x]==0){
              outcome=false;//if there are some/one skill needed
              break;
            }
        }
        return outcome;
    }
    
    /*
    public static void total_Cost(int person_of_interest[]){
        double total_cost=0;
        System.out.println("person of interest"+array_sequence_to_string(person_of_interest) );
        for(int i=0;i<person_of_interest.length;i++){
            for(int j=0;j<person_of_interest.length;j++){
                double cost = costs_connections[person_of_interest[i]][person_of_interest[j]];
                total_cost=total_cost+cost;
            }
        }
        System.out.println("total cost= "+total_cost);
    }
    */
    
    //////////////////////////////////////////////////////////////
    //   Initialize population 
    //////////////////////////////////////////////////////////////	
    public static void initialize_population(){
	int arr[];
        int task_1_Seq[];
        int task_2_Seq[];
        int task_3_Seq[];
        int task_4_Seq[];
        
        obj_value1_array = new int [population_size];        
        obj_value2_array = new double [population_size];   
        
        population = new int [population_size][total_persons];        
        population_short_seq_list = new String [population_size];

        
        for (int row=0;row<population_size;row++){
            //generate long sequence
            arr=generate_random_sequence(total_persons); //generate random sequence with random numbers between 1 to total no of person
            for (int col=0;col<total_persons;col++){
                population[row][col]= arr[col]; //put all the random long sequence into population
                //System.out.println("population ===="+arr[col]);
            }	
           
            
            
            if(row<cluster_size){            
                //get the required person who has skill/skills
                task_1_Seq = objective_function_(arr, task_1); 
                population_short_seq_list[row]=array_sequence_to_string(task_1_Seq);
                int task1_obj_person=objective_value1_(task_1_Seq);
                obj_value1_array[row]=task1_obj_person;
                double task1_obj_costs=objective_value2_(task_1_Seq);
                obj_value2_array[row]=task1_obj_costs;  // total connection cost
                
                /* //debuging
                System.out.println ("---------------------Task1-----------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task1 = "+array_sequence_to_string(task_1_Seq));
                System.out.println ("No of person task1 = "+task1_obj_person);
                System.out.println ("Costs task1 = "+task1_obj_costs);
                */
            }
            else if(row>=cluster_size && row<cluster_size*2){
                task_2_Seq = objective_function_(arr, task_2);
                population_short_seq_list[row]=array_sequence_to_string(task_2_Seq);
                int task2_obj_person=objective_value1_(task_2_Seq);
                obj_value1_array[row]=task2_obj_person;             
                double task2_obj_costs=objective_value2_(task_2_Seq);
                obj_value2_array[row]=task2_obj_costs;
                /*//debuging
                System.out.println ("---------------------Task2-----------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task2 = "+array_sequence_to_string(task_2_Seq));
                System.out.println ("No of person task2 = "+task2_obj_person);
                System.out.println ("Costs task2 = "+task2_obj_costs);
                 */   
            }
            else if(row>=(2*cluster_size) && row<(3*cluster_size)){          
                task_3_Seq = objective_function_(arr, task_3);
                population_short_seq_list[row]=array_sequence_to_string(task_3_Seq);
                int task3_obj_person=objective_value1_(task_3_Seq);
                obj_value1_array[row]=task3_obj_person; 
                double task3_obj_costs=objective_value2_(task_3_Seq);
                obj_value2_array[row]=task3_obj_costs;
                /*//debuging
                System.out.println ("---------------------Task3-----------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task3 = "+array_sequence_to_string(task_3_Seq));
                System.out.println ("No of person task3 = "+task3_obj_person);
                System.out.println ("Costs task3 = "+task3_obj_costs);
                 */
            }
            else{
                task_4_Seq = objective_function_(arr, task_4);
                population_short_seq_list[row]=array_sequence_to_string(task_4_Seq);
                int task4_obj_person=objective_value1_(task_4_Seq);
                obj_value1_array[row]=task4_obj_person;
                double task4_obj_costs=objective_value2_(task_4_Seq);
                obj_value2_array[row]=task4_obj_costs;
                /*//debuging
                System.out.println ("-------------------Task4-------------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task4 = "+array_sequence_to_string(task_4_Seq));
                System.out.println ("No of person task4 = "+task4_obj_person);
                System.out.println ("Costs task4 = "+task4_obj_costs);
                */ 
            }                                                        
        }
        
       // System.out.println("Initialization completed");
    }
    
    
    ///////////////////////////////////////////////////////////
    //   Generate random sequence 
    ////////////////////////////////////////////////////////////
    public static int [] generate_random_sequence (int dim){
        int[] ar = new int[dim];
        int d, tmp;
        Random generator = new Random();
        int[] dummy_solution_array = new int[dim];
        for (int counter=0; counter<dim;counter++){  
            dummy_solution_array [counter] = counter;// fill the array with some sequential no;
            
        }    
        // copy array from seq_arr
        ar = dummy_solution_array.clone();
        // swap with new ar with random index
        // the first index and last index must not change
        for (int i=0;i<dim-1;i++){
            d=i+(generator.nextInt()&(dim-1-i)); //generate random number between i and (dim-1-i)
            //System.out.print("generator "+ d);
            tmp=ar[i];
            ar[i]=ar[d];
            ar[d]=tmp;
        }
        //System.out.println("Random sequence completed  "+ array_sequence_to_string(ar));
        return ar;
    }
    public static int[] ensure_legal_sequence(int arr[]){
        int size = arr.length;
        ArrayList<Integer> temp_list = new ArrayList<Integer>();

        for (int i = 0; i < size; i++){

            if (arr[i] < 0){
                arr[i] = Math.abs(arr[i]);
            }

            if (arr[i] > size - 1){
                arr[i] = arr[i] % size;
            }

            if (!temp_list.contains(arr[i])){
                temp_list.add(arr[i]);
            }
        }

        int ref[] = generate_random_sequence(size);
        for (int i = 0; i < size; i++){
            if (!temp_list.contains(ref[i])){
                temp_list.add(ref[i]);
            }

            if (temp_list.size() == size){
                break;
            }
        }

        int return_arr[] = new int[temp_list.size()];
        for (int i = 0; i < size; i++){
            return_arr[i] = temp_list.get(i);
        }

        return return_arr;
    }
    
    
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the number of persons
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static int objective_value1_ (int seq[]){
        return (seq.length);
    }
	
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the connection costs
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static double objective_value2_ (int seq[]){
        double cost=0.0;	 
        for (int i=0;i<seq.length;i++){
            int row = seq[i];
            for (int j=i+1;j<seq.length;j++){
                int col =seq[j];
                cost = cost+costs_connections[row][col];
            }
	}	   
	return(cost); 
    }
    
    public static void TTA_STO(int Gen, int[] task,int t, String task_name ){
        double[] Local_Best_Cost   = new double[Gen];
        String[] Best_scores_Teams = new String[Gen];
        int[] Best_scores_Team_Size = new int[Gen];
        int[][] STO_population = new int[population_size_STO][total_persons];
        int[] obj_value1_array = new int[population_size_STO];
        double[] obj_value2_array = new double[population_size_STO];
        String[] population_short_seq_list = new String[population_size_STO];               
        //System.out.println("******************Tiki-Taka**STO************");
        int[] fitness;
        //initialize population
        for(int r=0; r<population_size_STO;r++){ //iterate population
        int[] arr= generate_random_sequence(total_persons); //generate random population
            fitness = objective_function_(arr, task);
            obj_value1_array[r]= objective_value1_(fitness);
            obj_value2_array[r]= objective_value2_(fitness);
            population_short_seq_list[r]= array_sequence_to_string(fitness);
        }
        //generate ball position
        generate_Ball_Position();
        
        for(int gen=0;gen<Gen;gen++){
            //iterate generation from here
            int [] Key_Players = get_Key_Players_STO(obj_value2_array);
            Random r = new Random(); 

            for(int row=0;row<population_size_STO;row++){//iterate population
                int bestOne= Key_Players[r.nextInt(Key_Players.length)];
                int[] best_One_seq =get_population_long_sequence(STO_population, bestOne); //get the long sequence of key player               
                int current_seq[]= get_population_long_sequence(STO_population,row);//get the current sequence
                int updated_long_seq[]=new int[total_persons];
                for (int col=0;col<total_persons;col++){
                    //update equation of 
                    //update player position
                    updated_long_seq[col]= current_seq[col]+ (int)(r.nextDouble()*C2*(ball_position[row][col]-current_seq[col]))+(int)(r.nextDouble()*C3*(best_One_seq[col]-current_seq[col]));
                    //boundary condtion or boundary managing
                    //System.out.println("update "+ updated_long_seq[col]);							 
                    update_ball_position(row, col);
                    //System.out.println(j+" = "+ updated_long_seq[j] );
                }//end col
                updated_long_seq=ensure_legal_sequence(updated_long_seq);
                STO_population[row]= updated_long_seq.clone();//update population
                int[] seq = objective_function_(get_population_long_sequence(STO_population,row), task);


                int obj_person=objective_value1_(seq);// get number of the person of interest
                double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.

                //update variables
                population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	 
                obj_value1_array[row]=obj_person; 	//no of persons
                obj_value2_array[row]=obj_costs;  // total connection cost

                //debuging
                /*
                System.out.println ("----------------------Task-1---------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence = "+array_sequence_to_string(seq));
                System.out.println ("No of person = "+obj_person);
                System.out.println ("Costs = "+obj_costs);
                */
            }//end population
            
            int local_best_index = get_index_best_cost(obj_value2_array);
            //System.out.println("index "+ local_best_index+" cost "+ obj_value2_array[local_best_index]);
            Local_Best_Cost[gen] = obj_value2_array[local_best_index];
            Best_scores_Team_Size[gen] = obj_value1_array[local_best_index];
            Best_scores_Teams[gen] = population_short_seq_list[local_best_index];
            /*
            System.out.println("***************Generation = "+ gen+"***************");
            System.out.println("***************Local result***********************");                     
            System.out.println("Best Cost = "+ Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Best_scores_Team_Size[gen]);
            */
        }//end generation
        
        ///////////get the global best of all individual task
        int     Global_Best_Gen   = get_index_best_cost(Local_Best_Cost);
        double  Global_Best_Cost  = Local_Best_Cost[Global_Best_Gen];
        String  Global_Best_scores_Teams = Best_scores_Teams[Global_Best_Gen];
        int     Global_Best_scores_Team_Size =Best_scores_Team_Size[Global_Best_Gen];
        /*
        System.out.println("##################################################");
        System.out.println("                Final Result: "+ task_name+"                   ");
        System.out.println("##################################################");
        //System.out.println("All The Local Cost"+Arrays.toString(Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Global_Best_scores_Team_Size);
        System.out.println("Minimum Cost "+ Global_Best_Cost);
        System.out.println("Found in "+ Global_Best_Gen+ " Generation");
        */
        //System.out.println(task_name + " Team Size "+Global_Best_scores_Team_Size+ " Team Cost "+Global_Best_Cost +" Convergence "+ Global_Best_Gen);
        switch(t) {
            case 1:
              STO_T1_Team_Size.add(Global_Best_scores_Team_Size);
              STO_T1_Team_Cost.add(Global_Best_Cost);
              STO_T1_Convergence.add(Global_Best_Gen);
              break;
            case 2:
              STO_T2_Team_Size.add(Global_Best_scores_Team_Size);
              STO_T2_Team_Cost.add(Global_Best_Cost);
              STO_T2_Convergence.add(Global_Best_Gen);
              break;
            case 3:
              STO_T3_Team_Size.add(Global_Best_scores_Team_Size);
              STO_T3_Team_Cost.add(Global_Best_Cost);
              STO_T3_Convergence.add(Global_Best_Gen);
              break;
            case 4:
              STO_T4_Team_Size.add(Global_Best_scores_Team_Size);
              STO_T4_Team_Cost.add(Global_Best_Cost);
              STO_T4_Convergence.add(Global_Best_Gen);
              break;
            default:
                System.out.println("Nothing Happens here ");
          }
    }
    
    /*
    Tasks defination
    */
    public static void Task1(int gen, int row, int bestOne){
        Random r = new Random(); 
        
        int[] best_One_seq =get_population_long_sequence(bestOne); //get the long sequence of key player               
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of 
            //update player position
            updated_long_seq[col]= current_seq[col]+ (int)(r.nextDouble()*C2*(ball_position[row][col]-current_seq[col]))+(int)(r.nextDouble()*C3*(best_One_seq[col]-current_seq[col]));
            //boundary condtion or boundary managing
            //System.out.println("update "+ updated_long_seq[col]);							 

            //System.out.println(j+" = "+ updated_long_seq[j] );
            update_ball_position(row,col);
        }//end col
        updated_long_seq=ensure_legal_sequence(updated_long_seq);
        population[row]= updated_long_seq.clone();//update population
        
        int[] seq = objective_function_(get_population_long_sequence(row), task_1);
            
           
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	 
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        /* //debuging
        System.out.println ("----------------------Task-1---------------------------");
        System.out.println ("Population no = "+row);
        //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs);
        */
    }
    
    public static void Task2(int gen, int row, int bestOne){
        Random r = new Random();
        
        int[] best_One_seq =get_population_long_sequence(bestOne); //get the long sequence of key player 
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of 
            //update player position
            updated_long_seq[col]= current_seq[col]+ (int)(r.nextDouble()*C2*(ball_position[row][col]-current_seq[col]))+(int)(r.nextDouble()*C3*(best_One_seq[col]-current_seq[col]));
            //boundary condtion or boundary managing
            //System.out.println("update "+ updated_long_seq[col]);
            update_ball_position(row,col);
        }
        updated_long_seq=ensure_legal_sequence(updated_long_seq);
        population[row]= updated_long_seq.clone();//update population

        int[] seq = objective_function_(get_population_long_sequence(row), task_2);
            
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	            
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        /* //debuging
        System.out.println ("----------------------Task-2---------------------------");
        System.out.println ("Population no = "+row);
        //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs);
        */
    }
    
    public static void Task3(int gen, int row, int bestOne){
        Random r = new Random();
        
        int[] best_One_seq =get_population_long_sequence(bestOne); //get the long sequence of key player 
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of 
            //update player position
            updated_long_seq[col]= current_seq[col]+ (int)(r.nextDouble()*C2*(ball_position[row][col]-current_seq[col]))+(int)(r.nextDouble()*C3*(best_One_seq[col]-current_seq[col]));
            //boundary condtion or boundary managing
            //System.out.println("update "+ updated_long_seq[col]);
            update_ball_position(row,col);
        }
        updated_long_seq=ensure_legal_sequence(updated_long_seq);
        population[row]= updated_long_seq.clone();//update population

        int[] seq = objective_function_(get_population_long_sequence(row), task_3);
            
         
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	   
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        /*//debuging
        System.out.println ("----------------------Task-3---------------------------");
        System.out.println ("Population no = "+row);
        //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs);
        */
    }
    
    public static void Task4(int gen, int row, int bestOne){
        Random r = new Random();
        
        int[] best_One_seq =get_population_long_sequence(bestOne); //get the long sequence of key player 
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of 
            //update player position
            updated_long_seq[col]= current_seq[col]+ (int)(r.nextDouble()*C2*(ball_position[row][col]-current_seq[col]))+(int)(r.nextDouble()*C3*(best_One_seq[col]-current_seq[col]));
            //boundary condtion or boundary managing
            //System.out.println("update "+ updated_long_seq[col]);
            update_ball_position(row,col);
        }
        updated_long_seq=ensure_legal_sequence(updated_long_seq);
        population[row]= updated_long_seq.clone();//update population

        int[] seq = objective_function_(get_population_long_sequence(row), task_4);
            
         
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	   
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        /* //debuging
        System.out.println ("----------------------Task-4---------------------------");
        System.out.println ("Population no = "+row);
        System.out.println ("Long sequence = "+array_sequence_to_string(seq));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs); 
        */
    }  
 
    public static int get_index_best_cost(double [] cost  ){	   
	int idx=0;
	double best_cost=Double.MAX_VALUE;	   
	for (int i=0;i<cost.length;i++){
            if (cost[i]<best_cost){
                best_cost=cost[i];
                idx=i;
            }
	}
        
	return idx;
    }
    
    //////////////////////////////////////////////////////////////
    //   Get the ith population long sequence
    //////////////////////////////////////////////////////////////	
    public static int [] get_population_long_sequence (int idx){
        int arr[]=new int[total_persons];
	   
	for (int col=0;col<total_persons;col++)
	    arr[col]=population[idx][col];
	
	return (arr);
    }
    public static int [] get_population_long_sequence (int[][] population, int idx){
        int arr[]=new int[total_persons];
	   
	for (int col=0;col<total_persons;col++)
	    arr[col]=population[idx][col];
	
	return (arr);
    }
    /*
    ****provide the best score 
    ****update the best scores
    ****update the global scores
    */
    public static int get_index_best_cost(double [] cost, int start, int end  ){	   
	int idx=0;
	double best_cost=Double.MAX_VALUE;	   
	for (int i=start;i<end;i++){
            if (cost[i]<best_cost){
                best_cost=cost[i];
                idx=i;
            }
	}
        
	return idx;
    }
    public static int get_index_worst_cost(double [] cost, int start, int end){
        int idx=0;
        double worst_cost=Double.MIN_VALUE;
        for (int i=start;i<end;i++){
            if (cost[i]>worst_cost){
                worst_cost=cost[i];
                idx=i;
            }
        }
        
        return idx;
    }  
    /*
    ***Tikitaka algorithum for team formation problem
    */
    public static void TikiTaka(int Generation){
        Task1_Local_Best_Cost   = new double[Generation];
        Task1_Best_scores_Teams = new String[Generation];
        Task1_Best_scores_Teams_No = new int[Generation];
        
        Task2_Local_Best_Cost =new double[Generation];
        Task2_Best_scores_Teams = new String[Generation];
        Task2_Best_scores_Teams_No = new int[Generation];
        
        Task3_Local_Best_Cost =new double[Generation];
        Task3_Best_scores_Teams = new String[Generation];
        Task3_Best_scores_Teams_No = new int[Generation];
        
        Task4_Local_Best_Cost =new double[Generation];
        Task4_Best_scores_Teams = new String[Generation];
        Task4_Best_scores_Teams_No = new int[Generation];
        
        Random r=new Random();
        //System.out.println("@@@@@@@@@@@@@@@@@@Tiki-Taka@@@@@@@@@@@@@@@@@@");
        
        tikiTaka_Initialization(); //initialize tiki taka by initializing ball positon, players position and key players
        //get a key player randomly from key players list
        int gen=0;        
        while(gen<Generation){
            //System.out.println("#####################################################");
            //System.out.println("##############"+"Generation "+ gen+"#################");
            get_Key_Players(); 
            for(int row=0;row<population_size;row++){                
                if(row<cluster_size){
                    int h = r.nextInt(no_of_key_players);
                    int Task1_key_player = Task1_Key_Players_indeces[h];
                    Task1(gen, row, Task1_key_player);
                }
                else if(row>=cluster_size && row<cluster_size*2){
                    int h = r.nextInt(no_of_key_players);
                    int Task2_key_player = Task2_Key_Players_indeces[h];
                    Task2(gen,row,Task2_key_player);
                }
                else if(row>=2*cluster_size && row<cluster_size*3){
                    int h = r.nextInt(no_of_key_players);
                    int Task3_key_player = Task3_Key_Players_indeces[h];
                    Task3(gen, row,Task3_key_player);
                }
                else{
                    int h = r.nextInt(no_of_key_players);
                    int Task4_key_player = Task4_Key_Players_indeces[h];
                    Task4(gen, row,Task4_key_player);
                }

                }//end of row
            //update local best cost, team members, member number
            int task1_local_best_index  =get_index_best_cost(obj_value2_array, 0,cluster_size);
            Task1_Local_Best_Cost[gen]  = obj_value2_array[task1_local_best_index];
            Task1_Best_scores_Teams[gen]= population_short_seq_list[task1_local_best_index];
            Task1_Best_scores_Teams_No[gen]  = obj_value1_array[task1_local_best_index];
            
            int task2_local_best_index= get_index_best_cost(obj_value2_array, cluster_size,2*cluster_size);
            Task2_Local_Best_Cost[gen]= obj_value2_array[task2_local_best_index];
            Task2_Best_scores_Teams[gen]= population_short_seq_list[task2_local_best_index];
            Task2_Best_scores_Teams_No[gen]  = obj_value1_array[task2_local_best_index];
            
            int task3_local_best_index= get_index_best_cost(obj_value2_array, 2*cluster_size,3*cluster_size);
            Task3_Local_Best_Cost[gen]= obj_value2_array[task3_local_best_index];
            Task3_Best_scores_Teams[gen]= population_short_seq_list[task3_local_best_index];
            Task3_Best_scores_Teams_No[gen]  = obj_value1_array[task3_local_best_index];
            
            int task4_local_best_index= get_index_best_cost(obj_value2_array, 3*cluster_size,4*cluster_size);
            Task4_Local_Best_Cost[gen]= obj_value2_array[task4_local_best_index];
            Task4_Best_scores_Teams[gen]= population_short_seq_list[task4_local_best_index];
            Task4_Best_scores_Teams_No[gen]  = obj_value1_array[task4_local_best_index];
            
            
            /*
            System.out.println("***************Generation = "+ gen+"***************");
            System.out.println("***************Local result***********************");
            
            System.out.println("****************Task 1******************************");                        
            System.out.println("Best Cost = "+ Task1_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task1_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task1_Best_scores_Teams_No[gen]);
            
            System.out.println("*****************Task 2*****************************");
            System.out.println("Best Cost = "+ Task2_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task2_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task2_Best_scores_Teams_No[gen]);
            
            System.out.println("********************Task 3**************************");
            System.out.println("Best Cost = "+ Task3_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task3_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task3_Best_scores_Teams_No[gen]);
            
            System.out.println("******************Task 4****************************");
            System.out.println("Best Cost = "+ Task4_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task4_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task4_Best_scores_Teams_No[gen]);
            System.out.println(" ");
            System.out.println(" ");
            System.out.println("******************************************************");
            */
            
             gen++;  
        } //end gen 
        
        ///////////get the global best of all individual task
        int     Task1_Global_Best_Gen   = get_index_best_cost(Task1_Local_Best_Cost);
        double  Task1_Global_Best_Cost  = Task1_Local_Best_Cost[Task1_Global_Best_Gen];
        String  Task1_Global_Best_scores_Teams = Task1_Best_scores_Teams[Task1_Global_Best_Gen];
        int     Task1_Global_Best_scores_Teams_No =Task1_Best_scores_Teams_No[Task1_Global_Best_Gen];
        
        int     Task2_Global_Best_Gen   = get_index_best_cost(Task2_Local_Best_Cost);
        double  Task2_Global_Best_Cost  = Task2_Local_Best_Cost[Task2_Global_Best_Gen];
        String  Task2_Global_Best_scores_Teams = Task2_Best_scores_Teams[Task2_Global_Best_Gen];
        int     Task2_Global_Best_scores_Teams_No =Task2_Best_scores_Teams_No[Task2_Global_Best_Gen];
        
        int     Task3_Global_Best_Gen   = get_index_best_cost(Task3_Local_Best_Cost);
        double  Task3_Global_Best_Cost  = Task3_Local_Best_Cost[Task3_Global_Best_Gen];
        String  Task3_Global_Best_scores_Teams = Task3_Best_scores_Teams[Task3_Global_Best_Gen];
        int     Task3_Global_Best_scores_Teams_No =Task3_Best_scores_Teams_No[Task3_Global_Best_Gen];
        
        int     Task4_Global_Best_Gen   = get_index_best_cost(Task4_Local_Best_Cost);
        double  Task4_Global_Best_Cost  = Task4_Local_Best_Cost[Task4_Global_Best_Gen];
        String  Task4_Global_Best_scores_Teams = Task4_Best_scores_Teams[Task4_Global_Best_Gen];
        int     Task4_Global_Best_scores_Teams_No =Task4_Best_scores_Teams_No[Task4_Global_Best_Gen];
        /*
        System.out.println("MTO Task 1: " + " Team Size "+Task1_Global_Best_scores_Teams_No+ " Team Cost "+Task1_Global_Best_Cost +" Convergence "+ Task1_Global_Best_Gen);
        System.out.println("MTO Task 2: " + " Team Size "+Task2_Global_Best_scores_Teams_No+ " Team Cost "+Task2_Global_Best_Cost +" Convergence "+ Task2_Global_Best_Gen);
        System.out.println("MTO Task 3: " + " Team Size "+Task3_Global_Best_scores_Teams_No+ " Team Cost "+Task3_Global_Best_Cost +" Convergence "+ Task3_Global_Best_Gen);
        System.out.println("MTO Task 4: " + " Team Size "+Task4_Global_Best_scores_Teams_No+ " Team Cost "+Task4_Global_Best_Cost +" Convergence "+ Task4_Global_Best_Gen);
        */
        
        MTO_T1_Team_Size.add(Task1_Global_Best_scores_Teams_No);
        MTO_T1_Team_Cost.add(Task1_Global_Best_Cost);
        MTO_T1_Convergence.add(Task1_Global_Best_Gen);
        
        MTO_T2_Team_Size.add(Task2_Global_Best_scores_Teams_No);
        MTO_T2_Team_Cost.add(Task2_Global_Best_Cost);
        MTO_T2_Convergence.add(Task2_Global_Best_Gen);
        
        MTO_T3_Team_Size.add(Task3_Global_Best_scores_Teams_No);
        MTO_T3_Team_Cost.add(Task3_Global_Best_Cost);
        MTO_T3_Convergence.add(Task3_Global_Best_Gen);
        
        MTO_T4_Team_Size.add(Task4_Global_Best_scores_Teams_No);
        MTO_T4_Team_Cost.add(Task4_Global_Best_Cost);
        MTO_T4_Convergence.add(Task4_Global_Best_Gen);
        
        
        
        /*
        //System.out.println("##################################################");
        System.out.println("                Final Result: MTO  Task 1                   ");
        System.out.println("##################################################");
        //System.out.println("All The Local Cost"+Arrays.toString(Task1_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task1_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task1_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task1_Global_Best_Cost);
        System.out.println("Found in "+ Task1_Global_Best_Gen+ " Generation");
        
        //System.out.println("##################################################");
        System.out.println("                Final Result:MTO Task 2                   ");
        System.out.println("##################################################");
        //System.out.println("All The Local Cost"+Arrays.toString(Task2_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task2_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task2_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task2_Global_Best_Cost);
        System.out.println("Found in "+ Task2_Global_Best_Gen+ " Generation");
        
        //System.out.println("##################################################");
        System.out.println("                Final Result: Task 3                   ");
        System.out.println("##################################################");
        //System.out.println("All The Local Cost"+Arrays.toString(Task3_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task3_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task3_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task3_Global_Best_Cost);
        System.out.println("Found in "+ Task3_Global_Best_Gen+ " Generation");
        
        //System.out.println("##################################################");
        System.out.println("                Final Result: Task 4                   ");
        System.out.println("##################################################");
        //System.out.println("All The Local Cost"+Arrays.toString(Task4_Local_Best_Cost));
        System.out.println("Best Team in all Generation " + Task4_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task4_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task4_Global_Best_Cost);
        System.out.println("Found in "+ Task4_Global_Best_Gen+ " Generation");
         */    
        }
        
    
    public static void tikiTaka_Initialization(){
        //generate players position
        initialize_population(); // initialization and evaluation of the population
        generate_Ball_Position(); // generating ball position
        //get_Key_Players(); //get the best players
        
    }
    public static void generate_Ball_Position(){
        //System.out.println("Generating random Ball Position");
        ball_position= new int[population_size][total_persons];
        for(int j=0;j<population_size;j++){
            Random r= new Random();
            for(int i=0;i<total_persons;i++){
                ball_position[j][i]= r.nextInt(total_persons-1);   
            }
        }
        //System.out.println("ball position " + Arrays.toString(ball_position));
        //System.out.println("length " + ball_position.length);
        //System.out.println("Ball position Generated ");
    }
    public static int[] get_splited_Int_array(int start_Index, int Ending_Index, int [] data){
        int [] dummy=new int[population_size/total_task];
        int p=0;
        for(int i= start_Index; i<Ending_Index;i++){            
            dummy[p]= data[i];
            p++;
        }
        return dummy;
    }
    
    public static double[] get_splited_Double_array(int start_Index, int Ending_Index, double [] data){

        double [] dummy=new double[population_size/total_task ];
        int p=0;
        for(int i= start_Index; i<Ending_Index;i++){
            
            dummy[p]= data[i];
            //System.out.println("int "+ i);
            p++;
        }
        return dummy;
    }
    
    private static void get_Key_Players() {
        sortedIndex ax= new sortedIndex();
        
        double [] Task1_costs=get_splited_Double_array(0,cluster_size, obj_value2_array);
        //System.out.println("task1   "+ Arrays.toString(Task1_costs));
        Task1_Key_Players_indeces= new int[no_of_key_players]; //create the bucket
        Task1_Key_Players_indeces = ax.sortedValue(Task1_costs, no_of_key_players);
        //System.out.println("Key players " + Arrays.toString(Task1_Key_Players_indeces));
        
        
        double [] Task2_costs=get_splited_Double_array(cluster_size,2*cluster_size, obj_value2_array);
        //System.out.println("task2   "+ Arrays.toString(Task2_costs));
        Task2_Key_Players_indeces= new int[no_of_key_players]; //create the bucket
        Task2_Key_Players_indeces = ax.sortedValue(Task2_costs, no_of_key_players);        
        //Update the index based on actual indexing of obj_Value2 array
        for(int i=0;i<Task2_Key_Players_indeces.length;i++){
            Task2_Key_Players_indeces[i]=Task2_Key_Players_indeces[i]+cluster_size;
        }
        //System.out.println("Key players " + Arrays.toString(Task2_Key_Players_indeces));
        
        
        double [] Task3_costs=get_splited_Double_array(2*cluster_size,3*cluster_size, obj_value2_array);
        //System.out.println("task3   "+ Arrays.toString(Task3_costs));
        Task3_Key_Players_indeces= new int[no_of_key_players]; //create the bucket
        Task3_Key_Players_indeces = ax.sortedValue(Task3_costs, no_of_key_players);
        //Update the index based on actual indexing of obj_Value2 array
        for(int i=0;i<Task3_Key_Players_indeces.length;i++){
            Task3_Key_Players_indeces[i]=Task3_Key_Players_indeces[i]+2*cluster_size;
        }
        //System.out.println("Key players " + Arrays.toString(Task3_Key_Players_indeces));
        
        double [] Task4_costs=get_splited_Double_array(3*cluster_size,4*cluster_size, obj_value2_array);
        //System.out.println("task4   "+ Arrays.toString(Task4_costs));
        Task4_Key_Players_indeces= new int[no_of_key_players]; //create the bucket
        Task4_Key_Players_indeces = ax.sortedValue(Task4_costs, no_of_key_players);
        //Update the index based on actual indexing of obj_Value2 array
        for(int i=0;i<Task4_Key_Players_indeces.length;i++){
            Task4_Key_Players_indeces[i]=Task4_Key_Players_indeces[i]+3*cluster_size;
        }
        //System.out.println("Key players " + Arrays.toString(Task4_Key_Players_indeces));                              
    }
    
    private static int[] get_Key_Players_STO(double[] cost) {
        sortedIndex ax1= new sortedIndex();
        
        double [] Task1_costs= cost.clone();
        //System.out.println("task1   "+ Arrays.toString(Task1_costs));
        int[] Key_Players_indeces= new int[no_of_key_players]; //create the bucket
        Key_Players_indeces = ax1.sortedValue(Task1_costs, no_of_key_players);
        //System.out.println("Key players " + Arrays.toString(Task1_Key_Players_indeces));
        return Key_Players_indeces;
    }
    
    private static void update_ball_position(int row, int col) {
        Random t = new Random();
        double r_p = t.nextDouble();
        int new_ball_position=0;
        int next_row=0;
        //System.out.println(" position " + row+" "+ col);
        if(row >population_size-2){
            next_row=0;
        }
        else{
            next_row= row+1;
        }
        //System.out.println(" next position " + next_row+" "+ col+ " ball "+ ball_position[next_row][col]);
        if(r_p>Prob_Loss){
            //System.out.println("old ball position "+ b[index]);
            //System.out.println("pos1= "+ ball_position[index]+" pos2= "+ ball_position[next_index]);
            new_ball_position = randomOfTwoNumbers(ball_position[row][col],ball_position[next_row][col])+ ball_position[row][col];
            //b[index]=new_ball_position;   
            //System.out.println("new_ball_position 1 "+new_ball_position);
        }
        else{
            //System.out.println("old ball position "+ b[index]);
            //System.out.println("pos1= "+ ball_position[index]+" pos2= "+ ball_position[next_index]);
            new_ball_position = (int) (ball_position[row][col]-(C1+t.nextDouble())*(ball_position[row][col]-ball_position[next_row][col]));
            //b[index]=new_ball_position;
            //System.out.println("new_ball_position 2 "+new_ball_position);
        }
        //boundary condition
        if(new_ball_position>total_persons-1){
            new_ball_position = (new_ball_position % (total_persons-1));
            ball_position[row][col]= new_ball_position;
        }
        else if(new_ball_position<0){
            new_ball_position=-(new_ball_position%(total_persons-1));
            ball_position[row][col]= new_ball_position;
        }
        else{
            ball_position[row][col]= new_ball_position;
        }
        //System.out.println("Updated Ball position " + ball_position[row][col]);
    }
    /*
    *provide random of two unknown double numbers
    */
    public static int randomOfTwoNumbers(int x, int y){
        Random ram= new Random();
        int output;
        //System.out.println("difference "+ (x-y));
        if(x>y){
            output = (int)(ram.nextDouble()*(x-y)) + y;
            //System.out.println("1st condition "+ output);
        }
        else{


            output = (int)(ram.nextDouble()*(y-x)) + x;
            //System.out.println("2nd condition " +output);
        }
        return output;
    }

    
}
