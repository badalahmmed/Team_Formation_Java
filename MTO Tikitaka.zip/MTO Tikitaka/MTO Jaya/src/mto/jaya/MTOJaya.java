/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mto.jaya;
  
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author badal
 */
public class MTOJaya {
    static ArrayList<String> memory_list = new ArrayList<String>(); //memory list for data loading
    static ArrayList<String> skills_list = new ArrayList<String>(); //unique skills list in dataset
    static ArrayList<String> persons_list = new ArrayList<String>(); //unique person list in dataset
    static ArrayList<String> unprocess_skills_connections = new ArrayList<String>();
    static ArrayList<String> unprocess_costs_connections = new ArrayList<String>();
    
    static int        total_persons; //total no of person in dataset
    static int        total_skills; //total no of unique skill in dataset
    static int        count_fitness_evaluation=0;
    static int        population_size=400; //population size for optimization algo
    static int        division = 5;
    static int        Generation;
    static double     Global_Best;
    
    static int [][]   skills_connections; // skills connection array for all people
    static double[][] costs_connections;  //cost connection array between everyone
    static int []     skills_to_find;     // skills that we have to be looking
    static int []     clone_skills_to_find; //for data handlinf dummy variable
    
    //task related variables
    static int total_task=4;
    static int [] task_1;
    static int [] task_2;
    static int [] task_3;
    static int [] task_4;
    
    
    
    static int best_idx_value_in_cluster_ [] = new int [division]; // stor best index value of a cluster into system
    // Population array
    static int[][]   population; //store population long sequence
    
    //store population of person of interest/nshort sequence
    static String[]  population_short_seq_list;  
    
    
    //store no of person of interest
    static int []    obj_value1_array; 
    
    
    //store cost connection between person of interest
    static double []   obj_value2_array;  
    
    
    private static double[]  Task1_Local_Best_Cost;
    private static String [] Task1_Best_scores_Teams;
    private static int []    Task1_Best_scores_Teams_No;

    
    private static double[]  Task2_Local_Best_Cost;
    private static String [] Task2_Best_scores_Teams;
    private static int []    Task2_Best_scores_Teams_No;
    
    private static double[] Task3_Local_Best_Cost;
    private static String [] Task3_Best_scores_Teams;
    private static int []    Task3_Best_scores_Teams_No;
    
    private static double[] Task4_Local_Best_Cost;
    private static String [] Task4_Best_scores_Teams;
    private static int []    Task4_Best_scores_Teams_No;
    
    
    
    static int[] Best_team_No;
    static boolean Best_Team;
    static String Best_Team_Formation;
    static double Best_Cost;
    static int Person_Number;
    //tikitaka parameters and veraibles
    static int[] ball_position;
    static int no_of_key_players= 5; // 10% of population size
    static int[] Key_Players_indeces;
    static double Prob_Loss =0.2;
    static double C1 = 1.75;
    static double C2 = 1.25;
    static double C3 = 2.50;
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args)throws IOException {
        //load data into system and initialize systems
        String x="E:\\Optimization related\\Team formation Code\\data\\ConnectionCost_ExtractedSkill_Staff_Expertise_DataSet\\";
        
        load_skills_in_memory(x+"ExtractedSkill_Staff_Expertise_Data.txt"); 
        process_skills();
        initialize_skills_connections();
        load_costs_in_memory(x+"ConnectionCost_Staff_Expertise_Data.txt");
        process_costs();
        initialize_costs_connections();

        //Task-1
        task_1 =load_skills_to_find(x+"Required skills 20_1.txt");
        System.out.println("skills task 1: "+ Arrays.toString(task_1));
        
        //Task-2
        task_2 =load_skills_to_find(x+"Required skills 20_2.txt");
        System.out.println("skills task 2: "+ Arrays.toString(task_2));
        
        //Task-3
        task_3 =load_skills_to_find(x+"Required skills 20_3.txt");
        System.out.println("skills task 3: "+ Arrays.toString(task_3));
        //Task-4
        task_4 =load_skills_to_find(x+"Required skills 20_4.txt");
        System.out.println("skills task 4: "+ Arrays.toString(task_4));
        
        ////////

        initialize_population();
        
       
        
        
        //Jaya algorithm
        
        Generation=200;
        jaya(Generation);
        
    }
    /*
    * load the skills file into memory for processing
    */
    public static void load_skills_in_memory (String skills_file) throws FileNotFoundException, IOException{
        try (RandomAccessFile f = new RandomAccessFile(skills_file,"r")) {
            long length = f.length();
            long position = 0;
            String content;
            int count=0;
            System.out.println ("Loading skills file in memory => "+skills_file);
            // rewind file to position 0
            f.seek(0);
            memory_list.clear();
            System.out.println("File Length"+ length);
            System.out.println();
            
            while (position < length){
                //System.out.println("while loop");
                if (count%5==0){
                    System.out.println ("Count = ["+count+"] Loading skills to memory ...please wait");
                }
                count++;
                content = f.readLine();
                memory_list.add(content);
                //System.out.println("text"+ content);
                position = f.getFilePointer();
            }
        } 
        System.out.println("Load Skills in Memory Done");
	}
    
    /*
    *Process the skill file and extract 
                # no of total_persons
                # no of total_skills
                # persons_list
                # skills_list
                # unprocess_skills_connections

    *
    */
    public static void process_skills () {
	String content;
	System.out.println ("Processing Skills ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
		String string_val = results[i];
                if (string_val.trim().equals("Total Persons".trim())){  
                    total_persons=Integer.parseInt(results[1]);
                    
                    process_already=true;
		}
		else if (string_val.trim().equals("Total Skills".trim())){  
                    total_skills=Integer.parseInt(results[1]);
                    process_already=true;
		}
		else if (string_val.trim().equals("Persons Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                        persons_list.add(results2[j]);
                        //System.out.println ("Adding person => "+results2[j]);
                    }
                    process_already=true;		
                }      
		else if (string_val.trim().equals("Skills Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                            skills_list.add(results2[j]); 
                            //System.out.println ("Adding skill => "+results2[j]);
                    }
                            process_already=true;
                } 
		else{ // store unprocess skills connections 
                    if (!unprocess_skills_connections.contains(content)&& process_already==false){
                        unprocess_skills_connections.add(content);
                    }
                }
            }	
        }
        /* For debugning 
        System.out.println("Total Persons = " + total_persons+"****************" );
        for(int i=0;i<persons_list.size();i++){
          System.out.println(i+" "+persons_list.get(i));  
        }
        */
        System.out.println("Total Skills " + total_skills +"********************");
         for(int i=0;i<skills_list.size();i++){
          System.out.println(i+" "+skills_list.get(i));  
        }
        
        System.out.println("Process Skill Processing Done.");
    }
    
    /*
    *Initialize skills connection or create skills connection Matrix into 2D array
    */
    public static void initialize_skills_connections(){	  
	skills_connections = new int [total_persons][total_skills];
	// initialize initial connections
	//System.out.println ("Initializing Skills Connection Metrics..");
        for (int row=0;row<total_persons;row++){
            for (int col=0;col<total_skills;col++){
                skills_connections[row][col]=0; 
            }
        }
        //System.out.println ("Unprocess connections from skills file => "+unprocess_skills_connections.size()); 
        for (int i=0;i<unprocess_skills_connections.size();i++){
            String s = unprocess_skills_connections.get(i).trim();
            String result[] = s.split("=");
            String val[] = result[1].split(":");
            for (int j=0;j<val.length;j++){
                skills_connections[i][j]= (int)Integer.parseInt(val[j]);
                //System.out.println("Skill connection matric"+ skills_connections[i][j]);
            }   
        }
             
        
        //System.out.println("Skill Connection Matrix Size(Total person X Total unique skills) = "+skills_connections.length+"x"+skills_connections[0].length );
        //System.out.println ("Initialize Skills Connection Metrics Done.");
		   
    }
    
    
    /*
    * load the skills file into memory for processing
    */
    public static void load_costs_in_memory (String costs_file)throws IOException{
        System.out.println("Loading Costs File in Memory");
	RandomAccessFile f = new RandomAccessFile(costs_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	int count=0;
	System.out.println ("Loading costs file in memory => "+costs_file);
        // rewind file to position 0
        f.seek(0);
	memory_list.clear();
        while (position < length){
            if (count%5==0)
            System.out.println ("Count = ["+count+"] Loading costs to memory ...please wait");
            count++;
            content = f.readLine();
            memory_list.add(content);
            //System.out.println("data"+ content);
            position = f.getFilePointer();
        }	
        f.close(); 
        
        System.out.println("Loading Costs File in Memory Done");
        
    }
        
    /*
    *Process the costs file and extract 
                # unprocess_skills_connections
    
    *
    */
    
    public static void process_costs (){
        String content;
        System.out.println ("Processing costs ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
                String string_val = results[i];
                if (string_val.trim().equals("Persons Mapping".trim())){
                    process_already=true;
                    continue;	
                }       
                else{ // store unprocess costs connections 
                    if (!unprocess_costs_connections.contains(content)&& process_already==false)
                        unprocess_costs_connections.add(content);
                }
            }
        }
        System.out.println ("Processing costs Done");
    }
    
    /* Initialize the cost connection matrix to form cost matrix
    
    */
    
    public static void initialize_costs_connections(){
	costs_connections = new double [total_persons][total_persons];
	// initialize initial connections
	System.out.println ("Initializing costs connection metrics..");
        
        for (int i=0;i<unprocess_costs_connections.size();i++){
            String s = unprocess_costs_connections.get(i).trim();
            String result[] = s.split("=");
            String val[] = result[1].split(":");
            for (int j=0;j<val.length;j++){
                costs_connections[i][j]= (double)Double.parseDouble(val[j]);
                //System.out.print( costs_connections[i][j]+" ");
            } 
            //System.out.println(" ");
        }
        System.out.println("Cost Matrix Size(Total Person X Total Person) = "+ costs_connections.length+" X "+ costs_connections[0].length);
        System.out.println ("Initializing costs connection metrics Done");
   }

    /*
    Load the text file which contails the team skills set
    */
    public static int[] load_skills_to_find (String values_file) throws IOException{
        System.out.println("load_skills_to_find .....processing");
        RandomAccessFile f = new RandomAccessFile(values_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	f.seek(0);
        ArrayList<Integer> match_idx = new ArrayList<Integer>();
	while (position < length){
            content = f.readLine();
            String results[] = content.split("=");
            String val[] = results[1].split(",");
            for (int i=0;i<val.length;i++){			
                int index = skills_list.indexOf(val[i].trim());
                System.out.println ("Skills to search for ==> "+val[i]);
                if (index==-1){
                    System.out.println ("One of the skills requested does not exist...");
                    System.exit(0);
                } 				  
                else{
                    match_idx.add(index);
                    }
  
            }	 
	    position = f.getFilePointer();
		  
        }
        f.close();		 		
        Collections.sort(match_idx); 
        skills_to_find= new int[total_skills];
        Arrays.fill(skills_to_find, 0); //put zero into all spaces
        for (int i=0;i<total_skills;i++){
            if (match_idx.contains(i)){// if match put 1 into that space
                skills_to_find[i]=1;
            }
        }
        System.out.println("Load Skills to Find Done");
        return skills_to_find;
    }
    
    /*
    *objective Function]
    * input: random person sequence
    * output: persons who has skills/ skill
    
    */
    public static int [] objective_function_ (int arr [], int [] skills_to_find ){
        boolean consist_skills_value=false;
        int update_answer[] = new int[total_skills];
        Arrays.fill(update_answer, 0); //fill the int array by zero.

        ArrayList<Integer> trim_seq = new ArrayList<Integer>();
        String value_skills = array_sequence_to_string (skills_to_find);  //converte arr into string
        //System.out.println("I am in objective function");
        clone_skills_to_find = skills_to_find.clone();
        
	
        for (int i=0;i<arr.length;i++){
            
            consist_skills_value=false;
            if (i==0){ // for first iteration
                for (int j=0;j<total_skills;j++){
                    update_answer[j]=skills_connections[arr[i]][j];// get the skill sets of a person
                    
                }
                //System.out.println ("Current seq value in zero = "+arr[i]);
                //String s =array_sequence_to_string (update_answer);
                //System.out.println ("sill sets of current person " +arr[i]+"  = " +s); 
                //System.out.println ("Skills to find                =   "+value_skills);
                consist_skills_value=contain_skills_to_find(update_answer,clone_skills_to_find);//check the person has that specific skills set
                if (consist_skills_value){   
                    trim_seq.add(arr[i]);// if has the skill, add that person into person of interest
                }
            }
            else{ //for all iteration
                int tmp_answer[] = new int[total_skills];
                Arrays.fill(tmp_answer, 0);
                for (int j=0;j<total_skills;j++){
                          tmp_answer[j]=skills_connections[arr[i]][j];
                }
                //System.out.println ("Current seq value non zero= "+arr[i]);
                //String s =array_sequence_to_string (tmp_answer);
                //System.out.println ("Update s       = "+s); 
                //System.out.println ("Skills to find = "+value_skills); 
                consist_skills_value=contain_skills_to_find(tmp_answer,clone_skills_to_find);
                if (consist_skills_value){
                    trim_seq.add(arr[i]);
                    //System.out.println("added person*****************************************");
                    update_answer= merge_elements_(update_answer,tmp_answer);	   
                    if (complete_merge_sequence_(update_answer,skills_to_find)){
                        //System.out.println("found all################################################yah");
                        break;	 //if all skills are covered
                    }                    
                }
                //s =array_sequence_to_string (update_answer);
                //System.out.println ("Skills so far  = "+s);
            }
        } 

        	
        int trim_result[] = new int [trim_seq.size()];
        for (int i=0;i<trim_seq.size();i++){
            trim_result[i]=trim_seq.get(i);
        }
        
        return trim_result; //return the persons sequences who have required skill or skills
    }
    /*
    ******** convert array sequence into string value
    */
    public static String array_sequence_to_string (int array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Integer.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Integer.toString(array[i]);
        }
        return (sequence);
    }
    
     public static String double_array_sequence_to_string (double array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Double.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Double.toString(array[i]);
        }
        return (sequence);
    }
    //////////////////////////////////////////////////////////
    //  Check if the given sequence has at least 1 skills 
    //  that we are looking for
    //////////////////////////////////////////////////////////
    //######need to change the mecanism##############
    public static boolean contain_skills_to_find (int arr[], int clone_skills_to_find[]){
        boolean outcome = false;
        for (int x=0; x<clone_skills_to_find.length; x++){
            if (clone_skills_to_find[x]==1 && arr[x]==1){
		outcome=true;
		clone_skills_to_find[x]=0;  // to signify already covered skill
		//break;
            }
        }
        return outcome;
    }
    
    ////////////////////////////////////////////////////////////
   //    Merge elements
   ///////////////////////////////////////////////////////////
   public static int [] merge_elements_ (int arr1[],int arr2[]){ 
        int merge_array[] = new int[total_skills];
        Arrays.fill(merge_array, 0); 
        for (int x=0; x<arr1.length; x++){
            if (arr1[x]==arr2[x])
                merge_array[x]=arr1[x];
            else if (arr1[x]==0 && arr2[x]==1)
                merge_array[x]=1;//remove zero person
            else if (arr1[x]==1 && arr2[x]==0)
                merge_array[x]=1; //remove zero person
        }
        
        return merge_array;
    }
    
    //////////////////////////////////////////////////////////
    //  Check for complete merge against skills to find
    //////////////////////////////////////////////////////////
    public static boolean complete_merge_sequence_ (int arr[], int skills_to_find[]){
        boolean outcome = true;
        for (int x=0; x<skills_to_find.length; x++){
          if (skills_to_find[x]==1 && arr[x]==0){
              outcome=false;//if there are some/one skill needed
              break;
            }
        }
        return outcome;
    }
    
    /*
    public static void total_Cost(int person_of_interest[]){
        double total_cost=0;
        System.out.println("person of interest"+array_sequence_to_string(person_of_interest) );
        for(int i=0;i<person_of_interest.length;i++){
            for(int j=0;j<person_of_interest.length;j++){
                double cost = costs_connections[person_of_interest[i]][person_of_interest[j]];
                total_cost=total_cost+cost;
            }
        }
        System.out.println("total cost= "+total_cost);
    }
    */
    
    //////////////////////////////////////////////////////////////
    //   Initialize population 
    //////////////////////////////////////////////////////////////	
    public static void initialize_population(){
	int arr[];
        int task_1_Seq[];
        int task_2_Seq[];
        int task_3_Seq[];
        int task_4_Seq[];
        
        obj_value1_array = new int [population_size];        
        obj_value2_array = new double [population_size];                       
        population = new int [population_size][total_persons];
        
        population_short_seq_list = new String [population_size];

        
        for (int row=0;row<population_size;row++){
            //generate long sequence
            arr=generate_random_sequence(total_persons); //generate random sequence with random numbers between 1 to total no of person
            for (int col=0;col<total_persons;col++){
                population[row][col]= arr[col]; //put all the random long sequence into population
                //System.out.println("population ===="+arr[col]);
            }	
           
            int cluster_size = population_size/total_task;
            
            if(row<cluster_size){            
                //get the required person who has skill/skills
                task_1_Seq = objective_function_(arr, task_1); 
                population_short_seq_list[row]=array_sequence_to_string(task_1_Seq);
                int task1_obj_person=objective_value1_(task_1_Seq);
                obj_value1_array[row]=task1_obj_person;
                double task1_obj_costs=objective_value2_(task_1_Seq);
                obj_value2_array[row]=task1_obj_costs;  // total connection cost
                
                //debuging
                System.out.println ("---------------------Task1-----------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task1 = "+array_sequence_to_string(task_1_Seq));
                System.out.println ("No of person task1 = "+task1_obj_person);
                System.out.println ("Costs task1 = "+task1_obj_costs);
            }
            else if(row>=cluster_size && row<cluster_size*2){
                task_2_Seq = objective_function_(arr, task_2);
                population_short_seq_list[row]=array_sequence_to_string(task_2_Seq);
                int task2_obj_person=objective_value1_(task_2_Seq);
                obj_value1_array[row]=task2_obj_person;             
                double task2_obj_costs=objective_value2_(task_2_Seq);
                obj_value2_array[row]=task2_obj_costs;
                //debuging
                System.out.println ("---------------------Task2-----------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task2 = "+array_sequence_to_string(task_2_Seq));
                System.out.println ("No of person task2 = "+task2_obj_person);
                System.out.println ("Costs task2 = "+task2_obj_costs);
                    
            }
            else if(row>=(2*cluster_size) && row<(3*cluster_size)){          
                task_3_Seq = objective_function_(arr, task_3);
                population_short_seq_list[row]=array_sequence_to_string(task_3_Seq);
                int task3_obj_person=objective_value1_(task_3_Seq);
                obj_value1_array[row]=task3_obj_person; 
                double task3_obj_costs=objective_value2_(task_3_Seq);
                obj_value2_array[row]=task3_obj_costs;
                //debuging
                System.out.println ("---------------------Task3-----------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task3 = "+array_sequence_to_string(task_3_Seq));
                System.out.println ("No of person task3 = "+task3_obj_person);
                System.out.println ("Costs task3 = "+task3_obj_costs);
                 
            }
            else{
                task_4_Seq = objective_function_(arr, task_4);
                population_short_seq_list[row]=array_sequence_to_string(task_4_Seq);
                int task4_obj_person=objective_value1_(task_4_Seq);
                obj_value1_array[row]=task4_obj_person;
                double task4_obj_costs=objective_value2_(task_4_Seq);
                obj_value2_array[row]=task4_obj_costs;
                //debuging
                System.out.println ("-------------------Task4-------------------------------");
                System.out.println ("Population no = "+row);
                System.out.println ("Long sequence = "+array_sequence_to_string(arr));
                System.out.println ("Short sequence task4 = "+array_sequence_to_string(task_4_Seq));
                System.out.println ("No of person task4 = "+task4_obj_person);
                System.out.println ("Costs task4 = "+task4_obj_costs);
                 
            }                                                        
        }
        
        System.out.println("Initialization completed");
    }
    
    
    ///////////////////////////////////////////////////////////
    //   Generate random sequence 
    ////////////////////////////////////////////////////////////
    public static int [] generate_random_sequence (int dim){
        int[] ar = new int[dim];
        int d, tmp;
        Random generator = new Random();
        int[] dummy_solution_array = new int[dim];
        for (int counter=0; counter<dim;counter++){  
            dummy_solution_array [counter] = counter;// fill the array with some sequential no;
            
        }    
        // copy array from seq_arr
        ar = dummy_solution_array.clone();
        // swap with new ar with random index
        // the first index and last index must not change
        for (int i=0;i<dim-1;i++){
            d=i+(generator.nextInt()&(dim-1-i)); //generate random number between i and (dim-1-i)
            //System.out.print("generator "+ d);
            tmp=ar[i];
            ar[i]=ar[d];
            ar[d]=tmp;
        }
        //System.out.println("Random sequence completed  "+ array_sequence_to_string(ar));
        return ar;
    }
    
    
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the number of persons
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static int objective_value1_ (int seq[]){
        return (seq.length);
    }
	
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the connection costs
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static double objective_value2_ (int seq[]){
        double cost=0.0;	 
        for (int i=0;i<seq.length;i++){
            int row = seq[i];
            for (int j=i+1;j<seq.length;j++){
                int col =seq[j];
                cost = cost+costs_connections[row][col];
            }
	}	   
	return(cost); 
    }
    
    public static int[] get_splited_Int_array(int start_Index, int Ending_Index, int [] data){
        int [] dummy=new int[population_size/total_task];
        for(int i= start_Index; i<Ending_Index;i++){
            dummy[i]= data[i];
        }
        return dummy;
    }
    
    public static double[] get_splited_Double_array(int start_Index, int Ending_Index, double [] data){
        double [] dummy=new double[population_size/total_task];
        for(int i= start_Index; i<Ending_Index;i++){
            dummy[i]= data[i];
        }
        return dummy;
    }
    /*
    Tasks defination
    */
    public static void Task1(int gen, int row, int idx_best, int idx_worst){
        Random r = new Random(); 
        
        int best_long_seq[] = get_population_long_sequence(idx_best);//get the best score sequence
        int worst_long_seq[] = get_population_long_sequence(idx_worst);////get the worst score sequence
        
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of jawa
            updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));


            //boundary condtion or boundary managing
            if (updated_long_seq[col]>total_persons-1){
                updated_long_seq[col]=updated_long_seq[col]-total_persons;
            }
            if (updated_long_seq[col]<0){
                updated_long_seq[col]=total_persons+updated_long_seq[col];
            }								 

            //System.out.println(j+" = "+ updated_long_seq[j] );
            population[row][col]= updated_long_seq[col];//update population
        }//end col
        int[] seq = objective_function_(get_population_long_sequence(row), task_1);
            
           
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	 
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        //debuging
        System.out.println ("----------------------Task-1---------------------------");
        System.out.println ("Population no = "+row);
        //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs);
    }
    
    public static void Task2(int gen, int row, int idx_best, int idx_worst){
        Random r = new Random();
        
        int best_long_seq[] = get_population_long_sequence(idx_best);//get the best score sequence              
        int worst_long_seq[] = get_population_long_sequence(idx_worst);////get the worst score sequence
        
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of jawa
            updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));


            //boundary condtion or boundary managing
            if (updated_long_seq[col]>total_persons-1){
                updated_long_seq[col]=updated_long_seq[col]-total_persons;
            }
            if (updated_long_seq[col]<0){
                updated_long_seq[col]=total_persons+updated_long_seq[col];
            }								 

            //System.out.println(j+" = "+ updated_long_seq[j] );
            population[row][col]= updated_long_seq[col];//update population
        }//end col
        int[] seq = objective_function_(get_population_long_sequence(row), task_2);
            
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	            
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        //debuging
        System.out.println ("----------------------Task-2---------------------------");
        System.out.println ("Population no = "+row);
        //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs);
    }
    
    public static void Task3(int gen, int row, int idx_best, int idx_worst){
        Random r = new Random();
        
        int best_long_seq[] = get_population_long_sequence(idx_best);//get the best score sequence        
        int worst_long_seq[] = get_population_long_sequence(idx_worst);////get the worst score sequence
        
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of jawa
            updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));


            //boundary condtion or boundary managing
            if (updated_long_seq[col]>total_persons-1){
                updated_long_seq[col]=updated_long_seq[col]-total_persons;
            }
            if (updated_long_seq[col]<0){
                updated_long_seq[col]=total_persons+updated_long_seq[col];
            }								 

            //System.out.println(j+" = "+ updated_long_seq[j] );
            population[row][col]= updated_long_seq[col];//update population
        }//end col
        int[] seq = objective_function_(get_population_long_sequence(row), task_3);
            
         
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	   
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        //debuging
        System.out.println ("----------------------Task-3---------------------------");
        System.out.println ("Population no = "+row);
        //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs);
    }
    
    public static void Task4(int gen, int row, int idx_best, int idx_worst){
        Random r = new Random();
        
        int best_long_seq[] = get_population_long_sequence(idx_best);//get the best score sequence
        int worst_long_seq[] = get_population_long_sequence(idx_worst);////get the worst score sequence
        
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of jawa
            updated_long_seq[col]=current_seq[col]+(int)(r.nextDouble()*(best_long_seq[col]-current_seq[col])) 
                                - (int)(r.nextDouble()*(worst_long_seq[col]-current_seq[col]));


            //boundary condtion or boundary managing
            if (updated_long_seq[col]>total_persons-1){
                updated_long_seq[col]=updated_long_seq[col]-total_persons;
            }
            if (updated_long_seq[col]<0){
                updated_long_seq[col]=total_persons+updated_long_seq[col];
            }								 

            //System.out.println(j+" = "+ updated_long_seq[j] );
            population[row][col]= updated_long_seq[col];//update population
        }//end col
        int[] seq = objective_function_(get_population_long_sequence(row), task_4);
            
         
        int obj_person=objective_value1_(seq);// get number of the person of interest
        double obj_costs=objective_value2_(seq); //get the total connection cost of the person of interest.
        
        //update variables
        population_short_seq_list[row]=array_sequence_to_string(seq);//put the person of interest into short population	   
        obj_value1_array[row]=obj_person; 	//no of persons
        obj_value2_array[row]=obj_costs;  // total connection cost
        
        //debuging
        System.out.println ("----------------------Task-4---------------------------");
        System.out.println ("Population no = "+row);
        //System.out.println ("Long sequence = "+array_sequence_to_string(arr));
        //System.out.println ("Short sequence = "+array_sequence_to_string(seq));
        System.out.println ("No of person = "+obj_person);
        System.out.println ("Costs = "+obj_costs); 
    }
    
    
    
    /*
    **Jaya algorithum implimentation
    */
    public static void jaya(int generation){
        Task1_Local_Best_Cost   = new double[Generation];
        Task1_Best_scores_Teams = new String[Generation];
        Task1_Best_scores_Teams_No = new int[Generation];
        
        Task2_Local_Best_Cost =new double[Generation];
        Task2_Best_scores_Teams = new String[Generation];
        Task2_Best_scores_Teams_No = new int[Generation];
        
        Task3_Local_Best_Cost =new double[Generation];
        Task3_Best_scores_Teams = new String[Generation];
        Task3_Best_scores_Teams_No = new int[Generation];
        
        Task4_Local_Best_Cost =new double[Generation];
        Task4_Best_scores_Teams = new String[Generation];
        Task4_Best_scores_Teams_No = new int[Generation];
        
        initialize_population();
        
        int gen=0;
        while(gen < generation){
            System.out.println("");
            System.out.println("");
            System.out.println("Generation "+ gen );
            int cluster_size=population_size/total_task;
            //////Task1
            //best calculatio
            int Task1_idx_best =  get_index_best_cost(obj_value2_array, 0,cluster_size );//get the best score index           
            int Task1_idx_worst = get_index_worst_cost(obj_value2_array, 0,cluster_size);//get the worst score index                       
            
            /////task2
            int Task2_idx_best =  get_index_best_cost(obj_value2_array, cluster_size,2*cluster_size );//get the best score index            
            int Task2_idx_worst = get_index_worst_cost(obj_value2_array, cluster_size, 2*cluster_size);//get the worst score index            
            
            /////task3
            int Task3_idx_best =  get_index_best_cost(obj_value2_array, 2*cluster_size,3*cluster_size );//get the best score index
            int Task3_idx_worst = get_index_worst_cost(obj_value2_array, 2*cluster_size, 3*cluster_size);//get the worst score index            ///Task 4
            
            /////task4
            int Task4_idx_best =  get_index_best_cost(obj_value2_array, 3*cluster_size,4*cluster_size );//get the best score index
            int Task4_idx_worst = get_index_worst_cost(obj_value2_array, 3*cluster_size, 4*cluster_size);//get the worst score index           
            
            //System.out.println("Population printing");
            for(int row=0;row<population_size;row++){ 
                
                if(row<cluster_size){
                    Task1(gen, row, Task1_idx_best, Task1_idx_worst);
                }
                else if(row>=cluster_size && row<cluster_size*2){
                    Task2(gen,row,Task2_idx_best, Task2_idx_worst);
                }
                else if(row>=2*cluster_size && row<cluster_size*3){
                    Task3(gen, row,Task3_idx_best, Task3_idx_worst);
                }
                else{
                    Task4(gen, row,Task4_idx_best, Task4_idx_worst);
                }
                
            }
                        
            //update local best cost, team members, member number
            int task1_local_best_index  =get_index_best_cost(obj_value2_array, 0,cluster_size);
            Task1_Local_Best_Cost[gen]  = obj_value2_array[task1_local_best_index];
            Task1_Best_scores_Teams[gen]= population_short_seq_list[task1_local_best_index];
            Task1_Best_scores_Teams_No[gen]  = obj_value1_array[task1_local_best_index];
            
            int task2_local_best_index= get_index_best_cost(obj_value2_array, cluster_size,2*cluster_size);
            Task2_Local_Best_Cost[gen]= obj_value2_array[task2_local_best_index];
            Task2_Best_scores_Teams[gen]= population_short_seq_list[task2_local_best_index];
            Task2_Best_scores_Teams_No[gen]  = obj_value1_array[task2_local_best_index];
            
            int task3_local_best_index= get_index_best_cost(obj_value2_array, 2*cluster_size,3*cluster_size);
            Task3_Local_Best_Cost[gen]= obj_value2_array[task3_local_best_index];
            Task3_Best_scores_Teams[gen]= population_short_seq_list[task3_local_best_index];
            Task3_Best_scores_Teams_No[gen]  = obj_value1_array[task3_local_best_index];
            
            int task4_local_best_index= get_index_best_cost(obj_value2_array, 3*cluster_size,4*cluster_size);
            Task4_Local_Best_Cost[gen]= obj_value2_array[task4_local_best_index];
            Task4_Best_scores_Teams[gen]= population_short_seq_list[task4_local_best_index];
            Task4_Best_scores_Teams_No[gen]  = obj_value1_array[task4_local_best_index];
            
            
            
            System.out.println("***************Generation = "+ gen+"***************");
            System.out.println("***************Local result***********************");
            
            System.out.println("****************Task 1******************************");                        
            System.out.println("Best Cost = "+ Task1_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task1_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task1_Best_scores_Teams_No[gen]);
            
            System.out.println("*****************Task 2*****************************");
            System.out.println("Best Cost = "+ Task2_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task2_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task2_Best_scores_Teams_No[gen]);
            
            System.out.println("********************Task 3**************************");
            System.out.println("Best Cost = "+ Task3_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task3_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task3_Best_scores_Teams_No[gen]);
            
            System.out.println("******************Task 4****************************");
            System.out.println("Best Cost = "+ Task4_Local_Best_Cost[gen]);
            System.out.println("Best Team = "+Task4_Best_scores_Teams[gen] );
            System.out.println("Number of Persons = "+ Task4_Best_scores_Teams_No[gen]);
            System.out.println(" ");
            System.out.println(" ");
            System.out.println("******************************************************");
            
            gen++;
        }
        ///////////get the global best of all individual task
        int     Task1_Global_Best_Gen   = get_index_best_cost(Task1_Local_Best_Cost);
        double  Task1_Global_Best_Cost  = Task1_Local_Best_Cost[Task1_Global_Best_Gen];
        String  Task1_Global_Best_scores_Teams = Task1_Best_scores_Teams[Task1_Global_Best_Gen];
        int     Task1_Global_Best_scores_Teams_No =Task1_Best_scores_Teams_No[Task1_Global_Best_Gen];
        
        int     Task2_Global_Best_Gen   = get_index_best_cost(Task2_Local_Best_Cost);
        double  Task2_Global_Best_Cost  = Task2_Local_Best_Cost[Task2_Global_Best_Gen];
        String  Task2_Global_Best_scores_Teams = Task2_Best_scores_Teams[Task2_Global_Best_Gen];
        int     Task2_Global_Best_scores_Teams_No =Task2_Best_scores_Teams_No[Task2_Global_Best_Gen];
        
        int     Task3_Global_Best_Gen   = get_index_best_cost(Task3_Local_Best_Cost);
        double  Task3_Global_Best_Cost  = Task3_Local_Best_Cost[Task3_Global_Best_Gen];
        String  Task3_Global_Best_scores_Teams = Task3_Best_scores_Teams[Task3_Global_Best_Gen];
        int     Task3_Global_Best_scores_Teams_No =Task3_Best_scores_Teams_No[Task3_Global_Best_Gen];
        
        int     Task4_Global_Best_Gen   = get_index_best_cost(Task4_Local_Best_Cost);
        double  Task4_Global_Best_Cost  = Task4_Local_Best_Cost[Task4_Global_Best_Gen];
        String  Task4_Global_Best_scores_Teams = Task4_Best_scores_Teams[Task4_Global_Best_Gen];
        int     Task4_Global_Best_scores_Teams_No =Task4_Best_scores_Teams_No[Task4_Global_Best_Gen];
        
        
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 1                   ");
        System.out.println("##################################################");
        System.out.println("Best Team in all Generation " + Task1_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task1_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task1_Global_Best_Cost);
        System.out.println("Found in "+ Task1_Global_Best_Gen+ " Generation");
        
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 2                   ");
        System.out.println("##################################################");
        System.out.println("Best Team in all Generation " + Task2_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task2_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task2_Global_Best_Cost);
        System.out.println("Found in "+ Task2_Global_Best_Gen+ " Generation");
        
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 3                   ");
        System.out.println("##################################################");
        System.out.println("Best Team in all Generation " + Task3_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task3_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task3_Global_Best_Cost);
        System.out.println("Found in "+ Task3_Global_Best_Gen+ " Generation");
        
        System.out.println("##################################################");
        System.out.println("                Final Result: Task 4                   ");
        System.out.println("##################################################");
        System.out.println("Best Team in all Generation " + Task4_Global_Best_scores_Teams);
        System.out.println("Person No In the Team "+ Task4_Global_Best_scores_Teams_No);
        System.out.println("Minimum Cost "+ Task4_Global_Best_Cost);
        System.out.println("Found in "+ Task4_Global_Best_Gen+ " Generation");
    }
    public static int get_index_best_cost(double [] cost  ){	   
	int idx=0;
	double best_cost=Double.MAX_VALUE;	   
	for (int i=0;i<cost.length;i++){
            if (cost[i]<best_cost){
                best_cost=cost[i];
                idx=i;
            }
	}
        
	return idx;
    }
    
    //////////////////////////////////////////////////////////////
    //   Get the ith population long sequence
    //////////////////////////////////////////////////////////////	
    public static int [] get_population_long_sequence (int idx){
        int arr[]=new int[total_persons];
	   
	for (int col=0;col<total_persons;col++)
	    arr[col]=population[idx][col];
	
	return (arr);
    }
    /*
    ****provide the best score 
    ****update the best scores
    ****update the global scores
    */
    public static int get_index_best_cost(double [] cost, int start, int end  ){	   
	int idx=0;
	double best_cost=Double.MAX_VALUE;	   
	for (int i=start;i<end;i++){
            if (cost[i]<best_cost){
                best_cost=cost[i];
                idx=i;
            }
	}
        
	return idx;
    }
    public static int get_index_worst_cost(double [] cost, int start, int end){
        int idx=0;
        double worst_cost=Double.MIN_VALUE;
        for (int i=start;i<end;i++){
            if (cost[i]>worst_cost){
                worst_cost=cost[i];
                idx=i;
            }
        }
        
        return idx;
    }  
}