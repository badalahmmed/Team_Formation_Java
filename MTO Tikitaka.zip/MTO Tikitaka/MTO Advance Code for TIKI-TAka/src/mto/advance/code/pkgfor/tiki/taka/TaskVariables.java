/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mto.advance.code.pkgfor.tiki.taka;

/**
 *
 * @author badal
 */
public class TaskVariables {
    private int task_no;
    private int[] task;
    private int start_index;
    private int ending_index;
    private int[] Task_key_players;
    
    
    public void TaskVariables(int tsk_no,int[] tsk,int strt_index,int ending_idex, int[] Tsk_key_players){
        task_no=tsk_no;
        task=tsk;
        start_index=strt_index;
        ending_index=ending_idex;
        Task_key_players=Tsk_key_players;
    }
    public int getTask_No(){
        return task_no;
    }
    public int[] getTask(){
        return task;
    }
    public int getStartIndex(){
        return start_index;        
    }
    public int getEndingIndex(){
        return ending_index;
    }
    public int[] getKeyPlayers(){
        return Task_key_players;
    }
    
    
    
    
    
    
    
    
}
