/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mto.advance.code.pkgfor.tiki.taka;


import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author badal
 */
public class MTO_TIKITAKA {
    static ArrayList<String> memory_list = new ArrayList<String>(); //memory list for data loading
    static ArrayList<String> skills_list = new ArrayList<String>(); //unique skills list in dataset
    static ArrayList<String> persons_list = new ArrayList<String>(); //unique person list in dataset
    static ArrayList<String> unprocess_skills_connections = new ArrayList<String>();
    static ArrayList<String> unprocess_costs_connections = new ArrayList<String>();
    
    static int        total_persons; //total no of person in dataset
    static int        total_skills; //total no of unique skill in dataset
    static int        population_size=100; //population size for optimization algo
    static int        Generation;
    
    
    static int [][]   skills_connections; // skills connection array for all people
    static double[][] costs_connections;  //cost connection array between everyone
    static int []     skills_to_find;     // skills that we have to be looking
    static int []     clone_skills_to_find; //for data handlinf dummy variable
    
    //task related variables    
    static ArrayList<String> Task_path = new ArrayList< String>();
    static ArrayList<int []> Task_list = new ArrayList< int []>();
    static int total_task=3;
    static int cluster_size = population_size/total_task;
 
    // Population array
    static int[][]   population; //store population long sequence
    static int[][]   population_STO; //store population long sequence
    //store population of person of interest/nshort sequence
    static String[]  population_short_seq_list;  
    static String[]  population_short_seq_list_STO;  
    //store no of person of interest
    static int []    obj_value1_array; 
    //store cost connection between person of interest
    static double []   obj_value2_array;  
    static int []    obj_value1_array_STO; 
    //store cost connection between person of interest
    static double []   obj_value2_array_STO;  
    //local best values storage
    private static double[][] Local_Best_cost;
    private static String [][] Local_Best_team;
    private static int [][] Local_Best_team_Member_No;
    
    //global best values storage
    private static double[] Global_Best_cost;
    private static String [] Global_Best_team;
    private static int [] Global_Best_team_Member_No;
    private static int [] Converge_Generation;
    
    //tikitaka parameters and veraibles
    static int[] ball_position;
    static int no_of_key_players= 2; // 10% of population size
    static ArrayList<int[]> Key_players_list = new ArrayList<>();

    static double Prob_Loss =0.2;
    
    //initial good result
    static double C1 = 1.6;
    static double C2 = 2.1;
    static double C3 = 2.1;
    
    
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        
        //program_Initialization();
        //initialize__STO_population(Task_list.get(0));
        
        
        long starttime = System.currentTimeMillis();
        program_Initialization();
        Generation=30;
        TikiTaka_MTO(Generation);
        long endtime = System.currentTimeMillis();
        double total_time= (endtime-starttime);
        System.out.println("total time"+ total_time);
      
        //System.out.println("total persons "+ total_persons);
        //System.out.println("Total skills "+ total_skills );
        
    
        
        //TikiTaka(Generation);
       
        //Instant end = Instant.now();
        //Duration timeElapsed = Duration.between(start, end); 
        
        //System.out.println("total time = " + timeElapsed);  
        
    }
    public static void program_Initialization()throws IOException{
        String basic_path= "E:\\Optimization related\\Team formation Code\\data\\ConnectionCost_ExtractedSkill_Staff_Expertise_DataSet\\";
        //load data into system and initialize systems
        load_skills_in_memory(basic_path+"ExtractedSkill_Staff_Expertise_Data.txt"); 
        
        process_skills();
        initialize_skills_connections();
        load_costs_in_memory(basic_path+"ConnectionCost_Staff_Expertise_Data.txt");
        process_costs();
        initialize_costs_connections();
        
        //load task path into the system
        load_tasks_path(basic_path); 
        load_tasks(4);
        
    }
    /*
    ***Load task path into the system
    */
    public static void load_tasks_path(String basic_path){
        // 5 skills set
        //String path1 = basic_path + "Required skills 5_1.txt";
        //String path2 = basic_path + "Required skills 5_2.txt";
        //String path3 = basic_path + "Required skills 5_3.txt";
        //String path4 = basic_path + "Required skills 5_4.txt";
        //String path5 = basic_path + "Required skills 5_5.txt";
        
        //10 Skills set
        //String path6  = basic_path+"Required skills 10_1.txt";
        //String path7  = basic_path+"Required skills 10_2.txt";
        //String path8  = basic_path+"Required skills 10_3.txt";
        //String path9  = basic_path+"Required skills 10_4.txt";
        //String path10 = basic_path+"Required skills 10_5.txt";  
        
          //15 skills set
        //String path11=basic_path+"Required skills 15_1.txt";
        //String path12=basic_path+"Required skills 15_2.txt";
        //String path13=basic_path+"Required skills 15_3.txt";
        //String path14=basic_path+"Required skills 15_4.txt";
 
        //20 skills set
        String path15=basic_path+"Required skills 20_1.txt";
        String path16=basic_path+"Required skills 20_2.txt";
        String path17=basic_path+"Required skills 20_3.txt";
        String path18=basic_path+"Required skills 20_4.txt";
        
        
        //Task_path.add(path1);
        //Task_path.add(path2);
        //Task_path.add(path3);
        //Task_path.add(path4);
        //Task_path.add(path5);
        
        //Task_path.add(path6);
        //Task_path.add(path7);
        //Task_path.add(path8);
        //Task_path.add(path9);
        //Task_path.add(path10);
        
        //Task_path.add(path11);
        //Task_path.add(path12);
        //Task_path.add(path13);
        //Task_path.add(path14);
        
        Task_path.add(path15);
        Task_path.add(path16);
        Task_path.add(path17);
        Task_path.add(path18);
    }
    
    /*
    ***Load task list into the system as an arraylist
    */
    public static void load_tasks(int number_of_task)throws IOException{
        for(int i=0;i<number_of_task;i++){
        int [] task =load_skills_to_find(Task_path.get(i));
        //System.out.println("#################TASK = "+ i+ "   Added");
        //System.out.println("file name"+Task_path.get(i) );
        //System.out.println("skills task 1: "+ Arrays.toString(task));
        Task_list.add(task);     
        }      
    }
    
    /*
    * load the skills file into memory for processing
    */
    public static void load_skills_in_memory (String skills_file) throws FileNotFoundException, IOException{
        try (RandomAccessFile f = new RandomAccessFile(skills_file,"r")) {
            long length = f.length();
            long position = 0;
            String content;
            int count=0;
            //System.out.println ("Loading skills file in memory => "+skills_file);
            // rewind file to position 0
            f.seek(0);
            memory_list.clear();
            //System.out.println("File Length"+ length);
            //System.out.println();
            
            while (position < length){
                //System.out.println("while loop");
                if (count%5==0){
                    //System.out.println ("Count = ["+count+"] Loading skills to memory ...please wait");
                }
                count++;
                content = f.readLine();
                memory_list.add(content);
                //System.out.println("text"+ content);
                position = f.getFilePointer();
            }
        } 
        System.out.println("Load Skills in Memory Done");
    }
    
    /*
    *Process the skill file and extract 
                # no of total_persons
                # no of total_skills
                # persons_list
                # skills_list
                # unprocess_skills_connections

    *
    */
    public static void process_skills () {
	String content;
	//System.out.println ("Processing Skills ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
		String string_val = results[i];
                if (string_val.trim().equals("Total Persons".trim())){  
                    total_persons=Integer.parseInt(results[1]);
                    
                    process_already=true;
		}
		else if (string_val.trim().equals("Total Skills".trim())){  
                    total_skills=Integer.parseInt(results[1]);
                    process_already=true;
		}
		else if (string_val.trim().equals("Persons Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                        persons_list.add(results2[j]);
                        //System.out.println ("Adding person => "+results2[j]);
                    }
                    process_already=true;		
                }      
		else if (string_val.trim().equals("Skills Mapping".trim())){
                    String results2[]=results[1].split(",");
                    for (int j=0;j<results2.length;j++){
                            skills_list.add(results2[j]); 
                            //System.out.println ("Adding skill => "+results2[j]);
                    }
                            process_already=true;
                } 
		else{ // store unprocess skills connections 
                    if (!unprocess_skills_connections.contains(content)&& process_already==false){
                        unprocess_skills_connections.add(content);
                    }
                }
            }	
        }
        /* For debugning 
        System.out.println("Total Persons = " + total_persons+"****************" );
        for(int i=0;i<persons_list.size();i++){
          System.out.println(i+" "+persons_list.get(i));  
        }
        
        //System.out.println("Total Skills " + total_skills +"********************");
         for(int i=0;i<skills_list.size();i++){
            System.out.println(i+" "+skills_list.get(i));  
        }
        */
        //System.out.println("Process Skill Processing Done.");
    }
    
    /*
    *Initialize skills connection or create skills connection Matrix into 2D array
    */
public static void initialize_skills_connections(){	  
	skills_connections = new int [total_persons][total_skills];
	// initialize initial connections
	//System.out.println ("Initializing Skills Connection Metrics..");
        for (int row=0;row<total_persons;row++){
            for (int col=0;col<total_skills;col++){
                skills_connections[row][col]=0; 
            }
        }
        //System.out.println ("Unprocess connections from skills file => "+unprocess_skills_connections.size()); 
        for (int i=0;i<unprocess_skills_connections.size();i++){
            String s = unprocess_skills_connections.get(i).trim();
            String result[] = s.split("=");
            String val[] = result[1].split(":");
            for (int j=0;j<val.length;j++){
                skills_connections[i][j]= (int)Integer.parseInt(val[j]);
                //System.out.println("Skill connection matric"+ skills_connections[i][j]);
            }   
        }
             
        
        //System.out.println("Skill Connection Matrix Size(Total person X Total unique skills) = "+skills_connections.length+"x"+skills_connections[0].length );
        //System.out.println ("Initialize Skills Connection Metrics Done.");
		   
    }
    
    
    /*
    * load the skills file into memory for processing
    */
    public static void load_costs_in_memory (String costs_file)throws IOException{
        //System.out.println("Loading Costs File in Memory");
	RandomAccessFile f = new RandomAccessFile(costs_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	int count=0;
	//System.out.println ("Loading costs file in memory => "+costs_file);
        // rewind file to position 0
        f.seek(0);
	memory_list.clear();
        while (position < length){
            if (count%5==0)
            //System.out.println ("Count = ["+count+"] Loading costs to memory ...please wait");
            count++;
            content = f.readLine();
            memory_list.add(content);
            //System.out.println("data"+ content);
            position = f.getFilePointer();
        }	
        f.close();         
        //System.out.println("Loading Costs File in Memory Done");   
    }
        
    /*
    *Process the costs file and extract 
                # unprocess_skills_connections
    
    *
    */
    
    public static void process_costs (){
        String content;
        //System.out.println ("Processing costs ... ");
        for(int idx=0;idx<memory_list.size();idx++){
            content = memory_list.get(idx);
            boolean process_already=false;
            // parse all the data for processing
            String results[] = content.split("=");
            for (int i=0;i<results.length;i++){
                String string_val = results[i];
                if (string_val.trim().equals("Persons Mapping".trim())){
                    process_already=true;
                    continue;	
                }       
                else{ // store unprocess costs connections 
                    if (!unprocess_costs_connections.contains(content)&& process_already==false)
                        unprocess_costs_connections.add(content);
                }
            }
        }
        //System.out.println ("Processing costs Done");
    }
    
    /* Initialize the cost connection matrix to form cost matrix
    
    */
    
    public static void initialize_costs_connections(){
	costs_connections = new double [total_persons][total_persons];
	// initialize initial connections
	//System.out.println ("Initializing costs connection metrics..");
        
        for (int i=0;i<unprocess_costs_connections.size();i++){
            String s = unprocess_costs_connections.get(i).trim();
            String result[] = s.split("=");
            String val[] = result[1].split(":");
            for (int j=0;j<val.length;j++){
                costs_connections[i][j]= (double)Double.parseDouble(val[j]);
                //System.out.print( costs_connections[i][j]+" ");
            } 
            //System.out.println(" ");
        }
        //System.out.println("Cost Matrix Size(Total Person X Total Person) = "+ costs_connections.length+" X "+ costs_connections[0].length);
        //System.out.println ("Initializing costs connection metrics Done");
   }

    /*
    Load the text file which contails the team skills set
    */
    public static int[] load_skills_to_find (String values_file) throws IOException{
        //System.out.println("load_skills_to_find .....processing");
        RandomAccessFile f = new RandomAccessFile(values_file,"rw");
        long length = f.length();
        long position = 0;
        String content;
	f.seek(0);
        ArrayList<Integer> match_idx = new ArrayList<Integer>();
	while (position < length){
            content = f.readLine();
            String results[] = content.split("=");
            String val[] = results[1].split(",");
            for (int i=0;i<val.length;i++){			
                int index = skills_list.indexOf(val[i].trim());
                //System.out.println ("Skills to search for ==> "+val[i]);
                if (index==-1){
                    //System.out.println ("One of the skills requested does not exist...");
                    System.exit(0);
                } 				  
                else{
                    match_idx.add(index);
                    }
            }	 
	    position = f.getFilePointer();	  
        }
        f.close();		 		
        Collections.sort(match_idx); 
        skills_to_find= new int[total_skills];
        Arrays.fill(skills_to_find, 0); //put zero into all spaces
        for (int i=0;i<total_skills;i++){
            if (match_idx.contains(i)){// if match put 1 into that space
                skills_to_find[i]=1;
            }
        }
        //System.out.println("Load Skills to Find Done");
        return skills_to_find;
    }
    
    /*
    *objective Function]
    * input: random person sequence
    * output: persons who has skills/ skill
    */
    public static int [] objective_function_ (int arr [], int [] skills_to_find ){
        boolean consist_skills_value=false;
        int update_answer[] = new int[total_skills];
        Arrays.fill(update_answer, 0); //fill the int array by zero.

        ArrayList<Integer> trim_seq = new ArrayList<Integer>();
        String value_skills = array_sequence_to_string (skills_to_find);  //converte arr into string
        //System.out.println("I am in objective function");
        clone_skills_to_find = skills_to_find.clone();
        for (int i=0;i<arr.length;i++){ 
            consist_skills_value=false;
            if (i==0){ // for first iteration
                for (int j=0;j<total_skills;j++){
                    update_answer[j]=skills_connections[arr[i]][j];// get the skill sets of a person     
                }
                //System.out.println ("Current seq value in zero = "+arr[i]);
                //String s =array_sequence_to_string (update_answer);
                //System.out.println ("sill sets of current person " +arr[i]+"  = " +s); 
                //System.out.println ("Skills to find                =   "+value_skills);
                consist_skills_value=contain_skills_to_find(update_answer,clone_skills_to_find);//check the person has that specific skills set
                if (consist_skills_value){   
                    trim_seq.add(arr[i]);// if has the skill, add that person into person of interest
                }
            }
            else{ //for all iteration
                int tmp_answer[] = new int[total_skills];
                Arrays.fill(tmp_answer, 0);
                for (int j=0;j<total_skills;j++){
                          tmp_answer[j]=skills_connections[arr[i]][j];
                }
                //System.out.println ("Current seq value non zero= "+arr[i]);
                //String s =array_sequence_to_string (tmp_answer);
                //System.out.println ("Update s       = "+s); 
                //System.out.println ("Skills to find = "+value_skills); 
                consist_skills_value=contain_skills_to_find(tmp_answer,clone_skills_to_find);
                if (consist_skills_value){
                    trim_seq.add(arr[i]);
                    //System.out.println("added person*****************************************");
                    update_answer= merge_elements_(update_answer,tmp_answer);	   
                    if (complete_merge_sequence_(update_answer,skills_to_find)){
                        //System.out.println("found all################################################yah");
                        break;	 //if all skills are covered
                    }                    
                }
                //s =array_sequence_to_string (update_answer);
                //System.out.println ("Skills so far  = "+s);
            }
        } 	
        int trim_result[] = new int [trim_seq.size()];
        for (int i=0;i<trim_seq.size();i++){
            trim_result[i]=trim_seq.get(i);
        } 
        return trim_result; //return the persons sequences who have required skill or skills
    }
    
    
    
    
    public static int[] ensure_legal_sequence(int arr[]){
        int size = arr.length;
        ArrayList<Integer> temp_list = new ArrayList<Integer>();

        for (int i = 0; i < size; i++){

            if (arr[i] < 0){
                arr[i] = Math.abs(arr[i]);
            }

            if (arr[i] > size - 1){
                arr[i] = arr[i] % size;
            }

            if (!temp_list.contains(arr[i])){
                temp_list.add(arr[i]);
            }
        }

        int ref[] = generate_random_sequence(size);
        for (int i = 0; i < size; i++){
            if (!temp_list.contains(ref[i])){
                temp_list.add(ref[i]);
            }

            if (temp_list.size() == size){
                break;
            }
        }

        int return_arr[] = new int[temp_list.size()];
        for (int i = 0; i < size; i++){
            return_arr[i] = temp_list.get(i);
        }

        return return_arr;
    }
    /*
    ******** convert array sequence into string value
    */
    public static String array_sequence_to_string (int array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Integer.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Integer.toString(array[i]);
        }
        return (sequence);
    }
    
        /*
    ******** convert double array sequence into string value
    */
    public static String double_array_sequence_to_string (double array []){
        String sequence="";
        for (int i=0;i<array.length;i++){
            if (i<array.length-1)// for last item
                sequence=sequence+Double.toString(array[i])+"-";
            else //for all item
                sequence=sequence+Double.toString(array[i]);
        }
        return (sequence);
    }
    //////////////////////////////////////////////////////////
    //  Check if the given sequence has at least 1 skills 
    //  that we are looking for
    //////////////////////////////////////////////////////////
    //######need to change the mecanism##############
    public static boolean contain_skills_to_find (int arr[], int clone_skills_to_find[]){
        boolean outcome = false;
        for (int x=0; x<clone_skills_to_find.length; x++){
            if (clone_skills_to_find[x]==1 && arr[x]==1){
		outcome=true;
		clone_skills_to_find[x]=0;  // to signify already covered skill
		//break;
            }
        }
        return outcome;
    }
    
    ////////////////////////////////////////////////////////////
   //    Merge elements
   ///////////////////////////////////////////////////////////
   public static int [] merge_elements_ (int arr1[],int arr2[]){ 
        int merge_array[] = new int[total_skills];
        Arrays.fill(merge_array, 0); 
        for (int x=0; x<arr1.length; x++){
            if (arr1[x]==arr2[x])
                merge_array[x]=arr1[x];
            else if (arr1[x]==0 && arr2[x]==1)
                merge_array[x]=1;//remove zero person
            else if (arr1[x]==1 && arr2[x]==0)
                merge_array[x]=1; //remove zero person
        }
        return merge_array;
    }
    
    //////////////////////////////////////////////////////////
    //  Check for complete merge against skills to find
    //////////////////////////////////////////////////////////
    public static boolean complete_merge_sequence_ (int arr[], int skills_to_find[]){
        boolean outcome = true;
        for (int x=0; x<skills_to_find.length; x++){
          if (skills_to_find[x]==1 && arr[x]==0){
              outcome=false;//if there are some/one skill needed
              break;
            }
        }
        return outcome;
    }
    
    /*
    ***Update task dependent varaibles
    */
    public static void Update_Task_Varaible(int row, int[] task, int task_no){
        int [] Seq = objective_function_(get_population_long_sequence(row), task); 
        population_short_seq_list[row]=array_sequence_to_string(Seq);
        int obj_person=objective_value1_(Seq);
        obj_value1_array[row]=obj_person;
        double obj_cost=objective_value2_(Seq);
        obj_value2_array[row]=obj_cost;  // total connection cost
        
        /*//debuging
        System.out.println ("---------------------Task"+ task_no+ "-----------------------------");
        System.out.println ("Population no = "+row);
        System.out.println ("Long sequence = "+array_sequence_to_string(get_population_long_sequence(row)));
        System.out.println ("Short sequence task1 = "+array_sequence_to_string(Seq));
        System.out.println ("No of person task1 = "+obj_person);
        System.out.println ("Costs task1 = "+obj_cost);
        */
    }
    
    //////////////////////////////////////////////////////////////
    //   Initialize population 
    //////////////////////////////////////////////////////////////	
    public static void initialize__MTO_population(){
	int arr[];
        obj_value1_array = new int [population_size];        
        obj_value2_array = new double [population_size];   
        
        population = new int [population_size][total_persons];        
        population_short_seq_list = new String [population_size];
 
        for (int row=0;row<population_size;row++){
            //generate long sequence
            arr=generate_random_sequence(total_persons); //generate random sequence with random numbers between 1 to total no of person
            for (int col=0;col<total_persons;col++){
                population[row][col]= arr[col]; //put all the random long sequence into population
                //System.out.println("population ===="+arr[col]);
            }	
            if(row<cluster_size){            
                //get the required person who has skill/skills
                Update_Task_Varaible(row, Task_list.get(0),0);
                
            }
            else if(row>=cluster_size && row<cluster_size*2){
                Update_Task_Varaible(row, Task_list.get(1),1);
                    
            }
            else if(row>=(2*cluster_size) && row<(3*cluster_size)){          
                Update_Task_Varaible(row, Task_list.get(2),2);     
            }
            else if(row>=3*cluster_size && row<4*cluster_size){
                Update_Task_Varaible(row, Task_list.get(3),3);
                    
            }
            else if(row>=(4*cluster_size) && row<5*cluster_size){          
                Update_Task_Varaible(row, Task_list.get(4),4);     
            }
            else if(row>=5*cluster_size && row<6*cluster_size){
                Update_Task_Varaible(row, Task_list.get(5),5);
                    
            }
            else if(row>=(6*cluster_size) && row<7*cluster_size){          
                Update_Task_Varaible(row, Task_list.get(6),6);     
            }
            else if(row>=7*cluster_size && row<8*cluster_size){
                Update_Task_Varaible(row, Task_list.get(7),7);
                    
            }
            else if(row>=(8*cluster_size) && row<(9*cluster_size)){          
                Update_Task_Varaible(row, Task_list.get(8),8);     
            }
            else if(row>=9*cluster_size && row<10*cluster_size){
                Update_Task_Varaible(row, Task_list.get(9),9);
                    
            }
            else if(row>=(10*cluster_size) && row<(11*cluster_size)){          
                Update_Task_Varaible(row, Task_list.get(10),10);     
            }
            else if(row>=11*cluster_size && row<12*cluster_size){
                Update_Task_Varaible(row, Task_list.get(11),11);        
            }                                                           
        }        
        //System.out.println("Initialization completed");
    }
    public static void initialize__STO_population(int[] task){
	int arr[];
        //int[] fitness = new int[population_size];
        population_STO = new int[population_size][total_persons];
        obj_value1_array_STO = new int [population_size];        
        obj_value2_array_STO = new double [population_size];          
        population_short_seq_list_STO = new String[population_size];
 
        for (int row=0;row<population_size;row++){
            //generate long sequence
            arr=generate_random_sequence(total_persons);
            int[] fitness = objective_function_(arr, task);
            population_STO[row]= arr.clone();
            obj_value1_array_STO[row]= objective_value1_(fitness);
            obj_value2_array_STO[row]= objective_value2_(fitness);
            population_short_seq_list_STO[row]=array_sequence_to_string(fitness);
            //System.out.println(row+" Pop: "+ Arrays.toString(population_STO[row]));
        }
        //System.out.println("TS: "+ Arrays.toString(obj_value1_array_STO));
        //System.out.println("TC: "+ Arrays.toString(obj_value2_array_STO));
        //System.out.println("Tm:"+ Arrays.toString(population_short_seq_list_STO));
    }
    
    ///////////////////////////////////////////////////////////
    //   Generate random sequence 
    ////////////////////////////////////////////////////////////
    public static int [] generate_random_sequence (int dim){
        int[] ar = new int[dim];
        int d, tmp;
        Random generator = new Random();
        int[] dummy_solution_array = new int[dim];
        for (int counter=0; counter<dim;counter++){  
            dummy_solution_array [counter] = counter;// fill the array with some sequential no;            
        }    
        // copy array from seq_arr
        ar = dummy_solution_array.clone();
        // swap with new ar with random index
        // the first index and last index must not change
        for (int i=0;i<dim-1;i++){
            d=i+(generator.nextInt()&(dim-1-i)); //generate random number between i and (dim-1-i)
            //System.out.print("generator "+ d);
            tmp=ar[i];
            ar[i]=ar[d];
            ar[d]=tmp;
        }
        //System.out.println("Random sequence completed  "+ array_sequence_to_string(ar));
        return ar;
    }
    
    
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the number of persons
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static int objective_value1_ (int seq[]){
        return (seq.length);
    }
	
    //////////////////////////////////////////////////////////////
    // Calculate  objective value in terms the connection costs
    // only meaningful after objective function call
    /////////////////////////////////////////////////////////////
    public static double objective_value2_ (int seq[]){
        double cost=0.0;	 
        for (int i=0;i<seq.length;i++){
            int row = seq[i];
            for (int j=i+1;j<seq.length;j++){
                int col =seq[j];
                cost = cost+costs_connections[row][col];
            }
	}	   
	return(cost); 
    }
    
    
    /*
    Tasks defination
    */
    public static void Task( int [] task,int task_number, int row, int bestOne){
        Random r = new Random(); 
        
        int[] best_One_seq =get_population_long_sequence(bestOne); //get the long sequence of key player               
        int current_seq[]= get_population_long_sequence(row);//get the current sequence
        
        int updated_long_seq[]=new int[total_persons];
        
        for (int col=0;col<total_persons;col++){
            //update equation of 
            //update player position
            updated_long_seq[col]= current_seq[col]+ (int)(r.nextDouble()*C2*(ball_position[col]-current_seq[col]))+(int)(r.nextDouble()*C3*(best_One_seq[col]-current_seq[col]));
            //boundary condtion or boundary managing
            //System.out.println("update "+ updated_long_seq[col]);

           
            //System.out.println(j+" = "+ updated_long_seq[j] );
            
        }//end col
        updated_long_seq = ensure_legal_sequence(updated_long_seq);
        population[row]= updated_long_seq.clone();//update population
        Update_Task_Varaible(row, task, task_number);
    }
    
 
    public static int get_index_best_cost(double [] cost  ){	   
	int idx=0;
	double best_cost=Double.MAX_VALUE;	   
	for (int i=0;i<cost.length;i++){
            if (cost[i]<best_cost){
                best_cost=cost[i];
                idx=i;
            }
	}        
	return idx;
    }
    
    //////////////////////////////////////////////////////////////
    //   Get the ith population long sequence
    //////////////////////////////////////////////////////////////	
    public static int [] get_population_long_sequence (int idx){
        int arr[]=new int[total_persons];
	   
	for (int col=0;col<total_persons;col++)
	    arr[col]=population[idx][col];	
	return (arr);
    }
    /*
    ****provide the best score 
    ****update the best scores
    ****update the global scores
    */
    public static int get_index_best_cost(double [] cost, int start, int end  ){	   
	int idx=0;
	double best_cost=Double.MAX_VALUE;	   
	for (int i=start;i<end;i++){
            if (cost[i]<best_cost){
                best_cost=cost[i];
                idx=i;
            }
	}        
	return idx;
    }
    public static int get_index_worst_cost(double [] cost, int start, int end){
        int idx=0;
        double worst_cost=Double.MIN_VALUE;
        for (int i=start;i<end;i++){
            if (cost[i]>worst_cost){
                worst_cost=cost[i];
                idx=i;
            }
        }
        return idx;
    }  
    /*
    ********TTA Single task optimizer STO
    */
    public static void TikiTaka_STO(int Generation, int[] task){
        
        double[] Local_Best_cost = new double[Generation];
        String[] Local_Best_team= new String[Generation];
        int[] Local_Best_team_Size = new int[Generation];
        
        Random r=new Random();
        //System.out.println("@@@@@@@@@@@@@@@@@@Tiki-Taka@@@@@@@@@@@@@@@@@@");
        initialize__STO_population(task);
       //get a key player randomly from key players list
        int[] key_players = get_Key_Players_STO(); //get the best players
        int gen=0;        
        while(gen<Generation){
            //System.out.println("#####################################################");
            //System.out.println("##############"+"Generation "+ gen+"#################");
            get_Key_Players(); 
            for(int row=0;row<population_size;row++){                
                if(row<cluster_size){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(0);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(0);
                    Task(task, 0, row, key_player);
                }
                
                }//end of row
            //update local best cost, team members, member number

            for(int t=0;t<total_task;t++){
                int task_local_best_index  =get_index_best_cost(obj_value2_array, (t)*cluster_size,(t+1)*cluster_size);    
                Local_Best_cost[t][gen]             = obj_value2_array[task_local_best_index];
                Local_Best_team[t][gen]             = population_short_seq_list[task_local_best_index];
                Local_Best_team_Member_No[t][gen]   = obj_value1_array[task_local_best_index];
            }
            
            System.out.println("***************Generation = "+ gen+"***************");
            System.out.println("***************Local result***********************");
            
            for(int i=0;i<total_task;i++){
            System.out.println("****************Task "+i+"******************************");                        
            System.out.println("Best Cost = "+ Local_Best_cost[i][gen]);
            System.out.println("Best Team = "+Local_Best_team[i][gen] );
            System.out.println("Number of Persons = "+ Local_Best_team_Member_No[i][gen]);
            System.out.println("******************************************************");
            
            }
            
             gen++;  
        } //end gen 
        
        ///////////get the global best of all individual task
        for(int tt=0;tt<total_task;tt++){
            int task_global_best_gen= get_index_best_cost(Local_Best_cost[tt]);
            Global_Best_cost[tt] = Local_Best_cost[tt][task_global_best_gen];
            Global_Best_team[tt]=Local_Best_team[tt][task_global_best_gen];
            Global_Best_team_Member_No[tt]=Local_Best_team_Member_No[tt][task_global_best_gen];
            Converge_Generation[tt]=task_global_best_gen;
        }

       for(int tsk=0;tsk<total_task;tsk++){
           
        System.out.println("##################################################");
        System.out.println("                Final Result: Task "+ tsk+"                    ");
        System.out.println("##################################################");
        System.out.println("All The Local Cost"+Arrays.toString(Local_Best_cost[tsk]));
        System.out.println("Best Team in all Generation " + Global_Best_team[tsk]);
        
        System.out.println("Person No In the Team "+ Global_Best_team_Member_No[tsk]);
        System.out.println("Minimum Cost "+ Global_Best_cost[tsk]);
        System.out.println("Found in "+ Converge_Generation[tsk]+ " Generation");
        System.out.println("Task = "+ tsk+",Team size="+Global_Best_team_Member_No[tsk]+",team cost="+Global_Best_cost[tsk]+",G="+Converge_Generation[tsk]);     
       }
        
    }

        
    
    
    
    /*
    ***Tikitaka algorithum for team formation problem
    */
    public static void TikiTaka_MTO(int Generation){
        
        Local_Best_cost = new double[total_task][Generation];
        Local_Best_team= new String[total_task][Generation];
        Local_Best_team_Member_No = new int [total_task][Generation];
        
        Global_Best_cost= new double[total_task] ;
        Global_Best_team= new String[total_task];
        Global_Best_team_Member_No= new int[total_task];
        Converge_Generation= new int[total_task];
        Random r=new Random();
        //System.out.println("@@@@@@@@@@@@@@@@@@Tiki-Taka@@@@@@@@@@@@@@@@@@");
        
        tikiTaka_Initialization(); //initialize tiki taka by initializing ball positon, players position and key players
        //get a key player randomly from key players list
        get_Key_Players(); //get the best players
        int gen=0;        
        while(gen<Generation){
            //System.out.println("#####################################################");
            //System.out.println("##############"+"Generation "+ gen+"#################");
            get_Key_Players(); 
            for(int row=0;row<population_size;row++){                
                if(row<cluster_size){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(0);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(0);
                    Task(task, 0, row, key_player);
                }
                else if(row>=cluster_size && row<cluster_size*2){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(1);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(1);
                    Task(task,1,row,key_player);
                }
                else if(row>=2*cluster_size && row<cluster_size*3){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(2);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(2);
                    Task(task,2,row,key_player);
                }
                else if(row>=3*cluster_size && row<cluster_size*4){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(3);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(3);
                    Task(task,3,row,key_player);
                }
                else if(row>=4*cluster_size && row<cluster_size*5){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(4);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(4);
                    Task(task,4,row,key_player);
                }
                else if(row>=5*cluster_size && row<cluster_size*6){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(5);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(5);
                    Task(task,5,row,key_player);
                }
                else if(row>=6*cluster_size && row<cluster_size*7){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(6);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(6);
                    Task(task,6,row,key_player);
                }
                else if(row>=7*cluster_size && row<cluster_size*8){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(7);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(7);
                    Task(task,7,row,key_player);
                }
                else if(row>=8*cluster_size && row<cluster_size*9){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(8);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(8);
                    Task(task,8,row,key_player);
                }
                else if(row>=9*cluster_size && row<cluster_size*10){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(9);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(9);
                    Task(task,9,row,key_player);
                }
                else if(row>=10*cluster_size && row<cluster_size*11){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(10);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(10);
                    Task(task,10,row,key_player);
                }
                else if(row>=11*cluster_size && row<cluster_size*12){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(11);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(11);
                    Task(task,11,row,key_player);
                }

                }//end of row
            //update local best cost, team members, member number

            for(int t=0;t<total_task;t++){
                int task_local_best_index  =get_index_best_cost(obj_value2_array, (t)*cluster_size,(t+1)*cluster_size);    
                Local_Best_cost[t][gen]             = obj_value2_array[task_local_best_index];
                Local_Best_team[t][gen]             = population_short_seq_list[task_local_best_index];
                Local_Best_team_Member_No[t][gen]   = obj_value1_array[task_local_best_index];
            }
            
            System.out.println("***************Generation = "+ gen+"***************");
            System.out.println("***************Local result***********************");
            
            for(int i=0;i<total_task;i++){
            System.out.println("****************Task "+i+"******************************");                        
            System.out.println("Best Cost = "+ Local_Best_cost[i][gen]);
            System.out.println("Best Team = "+Local_Best_team[i][gen] );
            System.out.println("Number of Persons = "+ Local_Best_team_Member_No[i][gen]);
            System.out.println("******************************************************");
            
            }
            
             gen++;  
        } //end gen 
        
        ///////////get the global best of all individual task
        for(int tt=0;tt<total_task;tt++){
            int task_global_best_gen= get_index_best_cost(Local_Best_cost[tt]);
            Global_Best_cost[tt] = Local_Best_cost[tt][task_global_best_gen];
            Global_Best_team[tt]=Local_Best_team[tt][task_global_best_gen];
            Global_Best_team_Member_No[tt]=Local_Best_team_Member_No[tt][task_global_best_gen];
            Converge_Generation[tt]=task_global_best_gen;
        }

       for(int tsk=0;tsk<total_task;tsk++){
           
        System.out.println("##################################################");
        System.out.println("                Final Result: Task "+ tsk+"                    ");
        System.out.println("##################################################");
        System.out.println("All The Local Cost"+Arrays.toString(Local_Best_cost[tsk]));
        System.out.println("Best Team in all Generation " + Global_Best_team[tsk]);
        
        System.out.println("Person No In the Team "+ Global_Best_team_Member_No[tsk]);
        System.out.println("Minimum Cost "+ Global_Best_cost[tsk]);
        System.out.println("Found in "+ Converge_Generation[tsk]+ " Generation");
        System.out.println("Task = "+ tsk+",Team size="+Global_Best_team_Member_No[tsk]+",team cost="+Global_Best_cost[tsk]+",G="+Converge_Generation[tsk]);     
       }
        
    }
        
    
    public static void tikiTaka_Initialization(){
        //generate players position
        initialize__MTO_population(); // initialization and evaluation of the population
        generate_Ball_Position(); // generating ball position         
    }
    public static void generate_Ball_Position(){
        //System.out.println("Generating random Ball Position");
        ball_position= new int[total_persons];
        Random r= new Random();
        for(int i=0;i<total_persons;i++){
            ball_position[i]= r.nextInt(total_persons-1);   
        }
        //System.out.println("ball position " + Arrays.toString(ball_position));
        //System.out.println("length " + ball_position.length);
        //System.out.println("Ball position Generated ");
    }
    public static int[] get_splited_Int_array(int start_Index, int Ending_Index, int [] data){
        int [] dummy=new int[population_size/total_task];
        int p=0;
        for(int i= start_Index; i<Ending_Index;i++){            
            dummy[p]= data[i];
            p++;
        }
        return dummy;
    }
    
    public static double[] get_splited_Double_array(int start_Index, int Ending_Index, double [] data){

        double [] dummy=new double[population_size/total_task ];
        int p=0;
        for(int i= start_Index; i<Ending_Index;i++){
            dummy[p]= data[i];
            //System.out.println("int "+ i);
            p++;
        }
        return dummy;
    }
    
    private static void get_Key_Players() {
        sortedIndex ax= new sortedIndex();
        int[] Key_Players_indeces = new int[no_of_key_players];
        
        for(int i=0;i<total_task;i++){            
            double [] Task_costs=get_splited_Double_array(i*cluster_size,(i+1)*cluster_size, obj_value2_array);
            Key_Players_indeces = ax.sortedValue(Task_costs, no_of_key_players);           
            for(int j=0;j<Key_Players_indeces.length;j++){
                Key_Players_indeces[j]=Key_Players_indeces[j]+i*cluster_size;
            }
            Key_players_list.add(Key_Players_indeces);
            //System.out.println("key players " + Arrays.toString(Key_players_list.get(i)));
        }                          
    }
    private static int[] get_Key_Players_STO() {
        sortedIndex ax= new sortedIndex();
        int[] Key_Players_indeces = new int[no_of_key_players];
        Key_Players_indeces = ax.sortedValue(obj_value2_array_STO, no_of_key_players);           
        return Key_Players_indeces;
        }                          
    
    private static void update_ball_position(int index, double C1) {
        Random t = new Random();
        double r_p = t.nextDouble();
        //System.out.println("r_p = "+ r_p);
        int next_index;
        if(index == total_persons-1){
            next_index=0;
        }
        else{
            next_index=index+1;
        }
        //System.out.println("index " + index);
        //System.out.println("ramdom "+ r_p);
        int new_ball_position=0;
        if(r_p>Prob_Loss){
            new_ball_position = randomOfTwoNumbers(ball_position[index],ball_position[next_index])+ ball_position[index];
        }
        else{
            new_ball_position = (int) (ball_position[index]-(C1+t.nextDouble())*(ball_position[index]-ball_position[next_index]));
        }
        //boundary condition
        if(new_ball_position>total_persons){
            new_ball_position = (new_ball_position % total_persons);
            ball_position[index]= new_ball_position;
        }
        else if(new_ball_position<0){
            new_ball_position=-(new_ball_position%total_persons);
            ball_position[index]= new_ball_position;
        }
        else{
            ball_position[index]= new_ball_position;
        }
        //System.out.println("Updated Ball position " + ball_position[index]);
    }
    /*
    *provide random of two unknown double numbers
    */
    public static int randomOfTwoNumbers(int x, int y){
        Random ram= new Random();
        int output;
        //System.out.println("difference "+ (x-y));
        if(x>y){
            output = (int)(ram.nextDouble()*(x-y)) + y;
            //System.out.println("1st condition "+ output);
        }
        else{
            output = (int)(ram.nextDouble()*(y-x)) + x;
            //System.out.println("2nd condition " +output);
        }
        return output;
    }
    
    public static void jaya_MTO(int Generation){
        
        Local_Best_cost = new double[total_task][Generation];
        Local_Best_team= new String[total_task][Generation];
        Local_Best_team_Member_No = new int [total_task][Generation];
        
        Global_Best_cost= new double[total_task] ;
        Global_Best_team= new String[total_task];
        Global_Best_team_Member_No= new int[total_task];
        Converge_Generation= new int[total_task];
        Random r=new Random();
        System.out.println("@@@@@@@@@@@@@@@@@@ Jaya@@@@@@@@@@@@@@@@@@");
        

        int gen=0;        
        while(gen<Generation){
            System.out.println("#####################################################");
            System.out.println("##############"+"Generation "+ gen+"#################");
            get_Key_Players(); 
            for(int row=0;row<population_size;row++){                
                if(row<cluster_size){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(0);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(0);
                    Task(task, 0, row, key_player);
                }
                else if(row>=cluster_size && row<cluster_size*2){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(1);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(1);
                    Task(task,1,row,key_player);
                }
                else if(row>=2*cluster_size && row<cluster_size*3){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(2);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(2);
                    Task(task,2,row,key_player);
                }
                else if(row>=3*cluster_size && row<cluster_size*4){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(3);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(3);
                    Task(task,3,row,key_player);
                }
                else if(row>=4*cluster_size && row<cluster_size*5){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(4);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(4);
                    Task(task,4,row,key_player);
                }
                else if(row>=5*cluster_size && row<cluster_size*6){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(5);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(5);
                    Task(task,5,row,key_player);
                }
                else if(row>=6*cluster_size && row<cluster_size*7){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(6);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(6);
                    Task(task,6,row,key_player);
                }
                else if(row>=7*cluster_size && row<cluster_size*8){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(7);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(7);
                    Task(task,7,row,key_player);
                }
                else if(row>=8*cluster_size && row<cluster_size*9){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(8);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(8);
                    Task(task,8,row,key_player);
                }
                else if(row>=9*cluster_size && row<cluster_size*10){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(9);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(9);
                    Task(task,9,row,key_player);
                }
                else if(row>=10*cluster_size && row<cluster_size*11){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(10);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(10);
                    Task(task,10,row,key_player);
                }
                else if(row>=11*cluster_size && row<cluster_size*12){
                    int h = r.nextInt(no_of_key_players);
                    int[] key_players = Key_players_list.get(11);
                    int key_player= key_players[h];
                    int[] task= Task_list.get(11);
                    Task(task,11,row,key_player);
                }

                }//end of row
            //update local best cost, team members, member number

            for(int t=0;t<total_task;t++){
                int task_local_best_index  =get_index_best_cost(obj_value2_array, (t)*cluster_size,(t+1)*cluster_size);    
                Local_Best_cost[t][gen]             = obj_value2_array[task_local_best_index];
                Local_Best_team[t][gen]             = population_short_seq_list[task_local_best_index];
                Local_Best_team_Member_No[t][gen]   = obj_value1_array[task_local_best_index];
            }

            System.out.println("***************Generation = "+ gen+"***************");
            System.out.println("***************Local result***********************");
            
            for(int i=0;i<total_task;i++){
            System.out.println("****************Task "+i+"******************************");                        
            System.out.println("Best Cost = "+ Local_Best_cost[i][gen]);
            System.out.println("Best Team = "+Local_Best_team[i][gen] );
            System.out.println("Number of Persons = "+ Local_Best_team_Member_No[i][gen]);
            System.out.println("******************************************************");
            }
             gen++;  
        } //end gen 
        
        ///////////get the global best of all individual task
        for(int tt=0;tt<total_task;tt++){
            int task_global_best_gen= get_index_best_cost(Local_Best_cost[tt]);
            Global_Best_cost[tt] = Local_Best_cost[tt][task_global_best_gen];
            Global_Best_team[tt]=Local_Best_team[tt][task_global_best_gen];
            Global_Best_team_Member_No[tt]=Local_Best_team_Member_No[tt][task_global_best_gen];
            Converge_Generation[tt]=task_global_best_gen;
        }

       for(int tsk=0;tsk<total_task;tsk++){
        System.out.println("##################################################");
        System.out.println("                Final Result: Task "+ tsk+"                    ");
        System.out.println("##################################################");
        System.out.println("All The Local Cost"+Arrays.toString(Local_Best_cost[tsk]));
        System.out.println("Best Team in all Generation " + Global_Best_team[tsk]);
        System.out.println("Person No In the Team "+ Global_Best_team_Member_No[tsk]);
        System.out.println("Minimum Cost "+ Global_Best_cost[tsk]);
        System.out.println("Found in "+ Converge_Generation[tsk]+ " Generation");
        
       }
        
    }

}

